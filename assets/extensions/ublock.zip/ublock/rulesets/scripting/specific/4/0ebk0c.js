/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// jpn-1

const argsList = [{"a":"#right div[align=\"center\"] > table[border=\"0\"],\na[href=\"/adcookie.php\"],\np.“hidden-print”"},{"a":"p[style^=\"min-height: 320px;\"]"},{"a":".billboard__pr"},{"a":"#bottom_overlay_area,\ndiv[class^=\"ADD\"]"},{"a":"div[style*=\"height:250px;\"]"},{"a":".ad__bit,\n.article__billboard__video__container,\ndiv[class*=\"ad__container\"]"},{"a":"#maintitle_ad"},{"a":".entry-content > div[style=\"margin:0;padding:5px;font-size:14px;word-break: break-all;\"]"},{"a":".item[style],\ndiv[style^=\"width:1290px; height:280px\"]"},{"a":"#entry-list > div.entry-block:first-child,\n.side-02 > div.widget > div.textwidget > div.widget"},{"a":"td[rowspan=\"4\"][valign=\"top\"][nowrap=\"\"][align=\"left\"]"},{"a":"#text-50,\ndiv[class^=\"gads-space\"]"},{"a":".news-list-ad"},{"a":".plugin-message,\n.t_b[style^=\"font-weight:bold;font-size:16px;line-height:24px;background-color:#f5f5f5\"]"},{"a":"#links"},{"a":".text > a[href^=\"https://amzn.\"],\nimg[src*=\"amazon-adsystem\"] + br + a"},{"a":"#links-left > span[style=\"font-size:x-small;\"],\n.blogbody > div.text > a[href^=\"https://amzn.to\"][target=\"_blank\"],\n.blogbody > div.text > a[href^=\"https://www.amazon.co.jp\"][target=\"_blank\"]"},{"a":"#ads_fieldOuter,\n#g_floating_tag_zone,\n#recommend_ad,\ndd + table[cellspacing=\"0\"][cellpadding=\"0\"][border=\"0\"],\ndiv[style^=\"width:300px; height:250px\"]"},{"a":"#bnr1,\n#bnrSuperbannerBottom,\n#pc-campaign-appeal-01,\n#premiumPanel"},{"a":"#headerad_banner"},{"a":"center > table[width=\"935\"][height=\"100\"][cellpadding=\"10\"][bgcolor=\"peru\"],\nspan[style=\"display:block;margin:5px 0 0 0;padding:0;text-align:center;\"]"},{"a":"table[style=\" FONT-SIZE: 18px\"][bgcolor=\"#ffffff\"][width=\"800\"][height=\"400\"],\ntable[style=\"FONT-SIZE: 12px\"][bordercolor=\"#ffccff\"][width=\"800\"][height=\"220\"],\ntd[valign=\"middle\"][width=\"800\"] > strong:first-child > font[color=\"#ff0000\"]:only-child"},{"a":".ds.first"},{"a":"#sub div.column-inner-2 > br,\n#sub div.column-inner-2 > table[border=\"0\"]"},{"a":".wp-block-wp-quads-adds,\namp-iframe"},{"a":"#right_folder > div.textwidget > a[rel^=\"nofollow\"] > img"},{"a":".banner3"},{"a":"#text-67,\n.stickyunit"},{"a":"#popup_area,\n.p-side-banner-lists"},{"a":"#amgatti_sk-3,\n#pc_text-80,\n#pc_text-94"},{"a":".widget_text.ad"},{"a":"#down-articles > div.textwidget,\n#mybox > div.textwidget:first-child"},{"a":"td[style=\"background-color: #ffffff; text-align: center; border: 1px solid #ffffff; height: 65px;\"][colspan=\"3\"]"},{"a":"p[style*=\"color:#333; text-align:center;\"]"},{"a":"br + center:last-child"},{"a":".ad-headerBottom"},{"a":"#pc_all_footer,\ndiv[style^=\"width:350px;height:290px;\"]"},{"a":"#cntAreaR > div[style=\"border:1px solid #ccc;margin-bottom:10px;\"],\n#pc_all_inarticle,\n#pc_right_1st,\n#pc_right_2nd,\n.header-bn"},{"a":"a[data-atag-id]"},{"a":".junk-ad-body,\n.nva-center,\nli.hidden-sm > a[href^=\"https:\"][target=\"_blank\"]"},{"a":"#pc_text-19,\n#pc_text-23,\niframe.lazyloaded[width=\"728\"][height=\"90\"]"},{"a":"#side-fix,\ndiv[style$=\"height:280px;\"]"},{"a":"#adexchange,\n.ad-bnr,\n.related,\nul > li.block-pr"},{"a":"a[href^=\"https://click.linksynergy.com/fs-bin/click\"],\na[href^=\"https://contents.fc2.com/aff.php\"]"},{"a":"div[class^=\"bg_ad_\"]"},{"a":"#is_w_area,\n.__isboostReturnAd"},{"a":".adDown"},{"a":"#amabox,\n#main > div.custom-html-widget > div.pc-first,\n.ad8"},{"a":"#header-r,\n#st-headerbox,\n#text-27,\n#text-54"},{"a":"#widget-under-sns-buttons"},{"a":".extendedwopts-show,\ndiv[style^=\"width:336px;height:280px\"]"},{"a":".single-gallery-ad-hol-block,\n.webcg-1030,\n.webcg-ad1,\ndiv[id^=\"sub-top_2nd\"]"},{"a":".entry-content > table[style=\"border-style: none;\"][border=\"1\"]"},{"a":"#media_image-10,\na[href^=\"https://www.banggood.com/\"],\ndiv[style=\"padding:20px 0px;\"] > center"},{"a":".ads-native"},{"a":".contentes_banner_2,\n.contents_ads_relation,\n.top_bottom_banner_box"},{"a":".monthly_popular_wrap,\n.top_rss_side_ad"},{"a":"#third > div.plugin-memo:first-child,\n.adad"},{"a":".hentry > .kizi-under-box:first-child"},{"a":".hentry div[style=\"text-align:center;\"]"},{"a":".topAdsenseArea"},{"a":".banner-yoko"},{"a":"#navi_recommend,\ndiv[id$=\"_ads\"]"},{"a":"#body > table:last-child"},{"a":"#secondary > div.widget_execphp,\n#text-34,\n.free-area_after-cont > div.widget_custom_html,\n.free-area_before-title > div.widget_execphp"},{"a":"#LeftAdBox > div.MenuBox:last-child,\n#ListPartner,\n#NaviTab_Ad,\n.MenuBox[style=\"padding: 5px; min-height: 280px;\"],\n.PaddingTop10Bottom10[style=\"margin-bottom:5px; display: flex;\"],\ndiv[id^=\"ad_\"][id$=\"_top\"]"},{"a":".MarginTop10Bottom10[style=\"height: 90px;\"]"},{"a":".ad[style^=\"min-width: 300px\"],\n.ad[style^=\"width:300px; height:250px\"],\n.ad[style^=\"width:310px; height:250px\"],\ndiv[id][style=\"width:300px;height:600px;\"],\ndiv[style^=\"min-width: 640px\"],\ndiv[style^=\"width:600px; height:200px\"]"},{"a":".conteiner__main > div[style=\"line-height:1; border-bottom:1px solid #ccc; padding:8px;\"],\n.conteiner__main > div[style=\"min-width:686px;min-height:557px;\"],\n.page_hedding,\n.vr2_aside__area > div[style^=\"width:300px;min-height:\"],\n.vr2_bnrlist,\n.vr2_page_hedding,\n.vr2_pickuplist__item,\n.vr2_prlist,\ndiv[style^=\"min-width:300px;min-height:250px\"],\ndiv[style^=\"width:100%;min-height:250px;text-align:center;\"]"},{"a":"#secondary > div.embed-responsive,\n#secondary > div.small,\n#secondary > video.w-100"},{"a":"#bigup2,\n#fuji-fns,\n#wrap_banner_billboard,\n.gf-slot-728,\n.pr_contents,\n[class*=\"banner_type_\"],\nbody > div#curtain + div.container[id],\ndiv[style^=\"border:1px solid #CCC;width:300px;margin:\"]"},{"a":".wrap_pr_300_sky"},{"a":".fixed-bottom,\ndiv[class^=\"my-ad\"]"},{"a":"div[id^=\"im-\"][style=\"min-height: 90px; margin-bottom: 1rem;\"],\ndiv[style$=\"min-height:250px;\"]"},{"a":".ad_3rec,\n.container_top_widget"},{"a":"#footer > .pr"},{"a":".widget > a[href][target=\"_blank\"] > img"},{"a":".gad_pc"},{"a":".sidebar > section[id^=\"custom_html-\"],\nbody .my_adslotd"},{"a":".article > div.no_print.mt10,\n.side_adarea1"},{"a":"#ad-double-rectangle"},{"a":"#ad_banner_widesky,\n#ad_rudel_1,\n#ad_rudel_2,\n#advertisement_amazon,\n#nav_2 > div[style=\"margin-bottom: 10px;\"],\n#toContents + div[style=\"margin-bottom: 20px;\"]"},{"a":"#ad-box3"},{"a":".b-r--before-site-content,\ndiv[style=\"min-height: 280px;\"]"},{"a":".author + div.archive,\n.single > p[style=\"margin-bottom:10px;\"]"},{"a":"div[style=\"text-align:center;background-color:#000000;color:#FFFFFF\"],\ndiv[style=\"width:160px;margin-right:-175px;float:left;\"] > div[style=\"margin-top:10px;text-align:center;\"]:last-of-type,\ndiv[style=\"width:466px;background:#000000;color:#FFFFFF;text-align:center\"]"},{"a":"#p-SponsoredLink,\ndiv[style=\"font-size: 11px;\"]"},{"a":".bottompr,\n.toppr,\n.videobottompr320x100"},{"a":"body > div[style=\"text-align: center;\"]"},{"a":".adspc,\n[class^=\"sponsor\"]"},{"a":".nearby > li:last-child:not([class])"},{"a":".ads_pc_rectangle,\n.flux_ad_overlay"},{"a":".article__content > h3.module__heading,\n.side--right > section.module--free,\n[class*=\"spad_\"]"},{"a":"div[id^=\"1\"][style*=\"height\"][style*=\"width\"],\ndiv[style^=\"margin:0 auto;height:\"][style$=\"px;\"]"},{"a":"a[href=\"https://tomari.org/uri/amazon.html\"]"},{"a":"div[class^=\"adsense_article_\"]"},{"a":".side_category + aside"},{"a":".left_main > a,\n.sample_block"},{"a":"div[id^=\"omc_ad_widget\"]"},{"a":".full-right-col"},{"a":"#myinvidad,\n#thbss > div > a[onclick][title=\"CLOSE\"]"},{"a":"div[style=\"text-align:center\"]"},{"a":"#popup-container"},{"a":".l-sidebar > aside.widget_block"},{"a":"span#ad"},{"a":".normal-sidebar a[href^=\"https://www.amazon.co.jp/gp/\"]"},{"a":".sidebar2.sidebar.col-sm-3,\n.widget_sponsored_area"},{"a":"#ad_html,\n#new_ad_html"},{"a":".foogallery"},{"a":".posts-under-2"},{"a":"#headerafficode"},{"a":"#preview_dispAffi"},{"a":"#col3"},{"a":"#execphp-4"},{"a":".post_content > table[style=\"border-collapse: collapse; width: 100%;\"]"},{"a":"p > a[target=\"_blank\"] > img"},{"a":"#ufw_1"},{"a":".ads_za"},{"a":".side-column > .add-container"},{"a":"#player-container,\n.a-d-block,\n.set_height_250,\ndiv[id][style^=\"position: absolute;  z-index: 12345;width: 100%; height: 100%; left: 0;  top: 0;background: gold;\"]"},{"a":".aasc.center > iframe[class*=\"lazyload\"],\n.col-sm-4 > [style=\"text-align:center;height:282px;overflow:visible!important;\"],\n.post_list[style=\"min-height:572px;max-width:1200px!important\"],\ndiv[style*=\"min-height\"]:not([class])"},{"a":"#container > div[style=\"margin:0 auto;margin-top:2px;min-height:95px;text-align:center;\"],\n#sub > div.column-inner > div.column-inner-2 > div[style=\"text-align:center;\"],\n#sub a[href^=\"https://www.amazon.co.jp/gp/\"],\n.article-outer-3 > #article-options,\ndiv[style=\"width:100%;height:300px;\"]"},{"a":"#prs"},{"a":".p-table__contents--full.u-pt30vw-down-md"},{"a":".u-dib"},{"a":".adArticleSideTop300x250,\n.adHomeSideTop300x250"},{"a":"#bottomNbox,\n.wide_adbox"},{"a":".ad-banner:not([data-name=\"single-related-posts\"])"},{"a":".post > .section-in > div[align=\"center\"],\n.post > .section-in > table"},{"a":"div[id^=\"gpt-ad\"]"},{"a":"div[class^=\"fluct-unit\"]"},{"a":".pr_link"},{"a":"div[style=\"width: 970px; margin: 0 auto 30px;\"]"},{"a":".ad-common_pc-ranking"},{"a":".c-ranking--type-b,\niframe.yahoo"},{"a":".my-adspace"},{"a":".row > div[class^=\"col-md-\"] > div[style^=\"text-align:center;margin-bottom:\"] > table[border=\"0\"]"},{"a":".bnr_wd_wrap"},{"a":"div[class^=\"gptad\"]"},{"a":".footer-ads-recipe"},{"a":"#dmm_comic_latest"},{"a":"#txtPr > span"},{"a":".home-featured-ad,\n.poplayer"},{"a":".adcopy2 > a"},{"a":"div[style^=\"max-width: 1000px; width: 90%; height: 400px;\"]"},{"a":".lala-common-ad"},{"a":"div[class^=\"style_ad\"],\ndiv[class^=\"style_under_toc_ads\"]"},{"a":"#top-ad1-wrapper,\ndiv[id^=\"broadcast-content-ad\"],\nsection[id^=\"common-content-top-ad\"],\nsection[id^=\"top-sidebar-ad\"]"},{"a":".adframe-container"},{"a":".video-plugin-skip-button"},{"a":"div[class=\"col-sm-12\"] > font[color]"},{"a":".brand_panel"},{"a":"#side-fixed"},{"a":"div[style^=\"text-align:center;width:336px\"]"},{"a":"#the-content > hr:last-of-type,\n#the-content > p > a[href^=\"https://hb.afl.rakuten.co.jp/\"],\n#the-content > p > a[href^=\"https://px.a8.net/svt/ejp?\"]"},{"a":"div[style=\"width:100%;background-color:#000;\"]"},{"a":"#product"},{"a":".widget-below-sns-buttons,\na[href=\"https://chatreze.net/article/mamisc/\"],\na[href^=\"https://al.dmm.co.jp/\"]"},{"a":".ggle-ad"},{"a":"#sidebar > p.mg_b_5[style],\ndiv[style=\"width: 300px !important; height: 250px !important;margin-bottom:20px;\"],\np[style=\"margin-top: 80px;\"]"},{"a":".tes_wrap"},{"a":".c307ad"},{"a":".modal_mo"},{"a":".entry-content > p > a[href^=\"https://al.dmm.co.jp/\"],\n.entry-content > p > a[href^=\"https://happymail.co.jp\"],\n.entry-content > p > a[href^=\"https://wlink.golden-gateway.com\"]"},{"a":".sideBlock:first-child"},{"a":"#text-html-widget-2,\n.dspace-block,\n.wpap-tpl,\ndiv[style*=\"min-height\"][style*=\"height: auto\"]"}];

const hostnamesMap = new Map([["privatter.net",0],["ruigo.quus.net",1],["rakuten-sec.net",2],["rankingoo.net",3],["relazo.net",4],["renote.net",5],["rocomotion.net",6],["roshutu-shuuti.net",7],["rubese.net",8],["sabuibo.net",9],["sagaoz.net",10],["sbapp.net",11],["news.searchina.net",12],["helloprojects.seesaa.net",13],["my0nio.seesaa.net",[14,15]],["oto-suu.seesaa.net",14],["sadironman.seesaa.net",16],["jbbs.shitaraba.net",17],["shufoo.net",18],["s.shufoo.net",19],["i-bbs.sijex.net",20],["silky-love.net",21],["sk2ch.net",22],["ske48matome.net",23],["smatu.net",24],["solomon-review.net",25],["spoen.net",26],["sqool.net",27],["studyhacker.net",28],["sumahoinfo.net",29],["sundaygamer.net",30],["takamaru1219.net",31],["english.talk-sense.net",32],["talknews.net",33],["taruo.net",34],["tennis365.net",35],["amigo.tennis365.net",36],["news.tennis365.net",37],["toaru-web.net",38],["tokyomotion.net",39],["totoneko.net",40],["toushichannel.net",41],["toyokeizai.net",42],["travel-nippon.net",43],["tvjapan.net",44],["twivideo.net",45],["twtimez.net",46],["umamusume.net",47],["vapejp.net",48],["vip-jikkyo.net",49],["warotanien.net",50],["webcg.net",51],["wikinis.net",52],["win-tab.net",53],["with2.net",54],["wood-museum.net",55],["world-fusigi.net",56],["worldfn.net",57],["xn--cbkxbyfwj.net",58],["xn--o9jx06gxedxziu2np5bluqts8d30r.net",59],["yoheim.net",60],["youravhost.net",61],["yugalab.net",62],["yugioh-wiki.net",63],["zekamashi.net",64],["zyuken.net",65],["chu.zyuken.net",66],["hochi.news",67],["kahoku.news",68],["kumin.news",69],["gigafile.nu",70],["choosar.gigafile.nu",71],["shortener.gigafile.nu",72],["wiki.yjsnpi.nu",73],["dougle.one",74],["teams.one",75],["rallys.online",76],["live-events.a-jp.org",77],["androplus.org",78],["benricho.org",79],["chomanga.org",80],["erogamescape.dyndns.org",81],["favolog.org",82],["ieeebd.org",83],["johndoeblog.org",84],["kabegami.jpn.org",85],["kaworu.jpn.org",86],["loveh.org",87],["stanok-chel.ru",87],["nekonikoban.org",88],["news-us.org",89],["postmap.org",90],["refind2ch.org",91],["bnewg.sokuho.org",92],["syosetu.org",93],["tomari.org",94],["hinode.pics",95],["bokunokanojo.pink",96],["sexywars.pink",97],["eigo.plus",98],["javshare.pro",99],["cndata.jpg4.pw",100],["dateplus.red",101],["shop-flashka.ru",102],["hedgehog.ryukyu",103],["maguro.2ch.sc",104],["geek.sc",105],["share-videos.se",106],["embed.share-videos.se",107],["adseek.site",[108,109]],["fig-memo-r18.site",[108,114]],["animemaruwakari.site",110],["bokumato.site",111],["ero-mag.site",[112,113]],["anianierosuki.work",[112,152]],["phuot.site",115],["vimv.site",116],["zabuu.site",117],["vague.style",118],["7mmtv.sx",119],["coron.tech",120],["connect.coron.tech",121],["jump.x0.to",122],["mag.digle.tokyo",123],["movie.digle.tokyo",124],["elog.tokyo",125],["game-news.tokyo",126],["hanako.tokyo",127],["l-media.tokyo",128],["web.playerapp.tokyo",129],["urbanlife.tokyo",130],["rakko.tools",131],["corriente.top",132],["reminder.top",133],["times.abema.tv",134],["best-hit.tv",135],["i.best-hit.tv",136],["cazual.tv",137],["cchan.tv",138],["delishkitchen.tv",139],["erovideon.tv",140],["hamazo.tv",141],["hpav.tv",142],["ikora.tv",143],["javmix.tv",144],["lala.tv",145],["mamadays.tv",146],["ohen.tv",147],["wav.tv",148],["jpshowbiz.us",149],["2ch.vet",150],["abstractpainting.work",151],["efootball.work",153],["glossary.work",154],["rorriiianime.work",155],["tkgstrator.work",156],["ukemi-no-kiwami.work",157],["4thsight.xyz",158],["k3su.xyz",159],["shico.xyz",160],["theav.xyz",161],["wazaari.xyz",162],["xn--8uqt3cty5bwwbwwh.xyz",163],["hamakore.yokohama",164],["socom.yokohama",165]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
