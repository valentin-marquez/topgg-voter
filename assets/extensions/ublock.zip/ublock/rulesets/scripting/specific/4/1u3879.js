/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// ind-0

const argsList = [{"a":"a[href*=\"utm_medium=banner\"]"},{"a":".tds-button"},{"a":"#myModal1"},{"a":".advert-single"},{"a":".e3lan img"},{"a":".container-bn"},{"a":"a[href*=\"CrystalSoapLK\"],\na[href*=\"kandos.lk\"]"},{"a":".widget_custom_html:not(#custom_html-7)"},{"a":".besides-slider-right"},{"a":"#ads_hide"},{"a":"#ads_hide img"},{"a":".fixed-banner,\n.main-ad-half"},{"a":"#headerright"},{"a":"#openModal1"},{"a":".wpb_text_column.tagdiv-type"},{"a":"#block-views-ads-display-inner-block"},{"a":"#big-banner,\n#custom_html-3 img"},{"a":"#topbanneer,\n.mbs"},{"a":".region-banner"},{"a":"#custom-ads-2,\n#main_middle_right_advert"},{"a":"figure .prettyphoto"},{"a":"img[target]"},{"a":"div[data-embed-button=\"embed_advertisement\"]"},{"a":"a[href*=\"adroll.com\"]"},{"a":".block-block:not(#block-block-13)"},{"a":".top-ads-block"},{"a":".popupCloseButton,\ndiv[class^=\"advertise_space\"]"},{"a":".widget_block:not(#block-3)"},{"a":"#banner_header_728"},{"a":".add-space"},{"a":".content-inner h4"},{"a":".td-main-content-wrap .td-a-rec img"},{"a":".addVertise,\ndiv[class*=\"sgpb-popup\"]"},{"a":".fadInleft_ads"},{"a":".Add img"},{"a":"#left-top-holder,\n.ad-left-holder"},{"a":"#right-holder"},{"a":"#body_ad,\n.ad728-top,\ndiv[class^=\"ad-block\"]"},{"a":".wpb_content_element > .wpb_wrapper"},{"a":"#media_image-1,\n.footer-right-widget"},{"a":".elementor-widget-text-editor"},{"a":"img[alt=\"weblogs\"]:not([src*=\"coronavirus_up\"])"},{"a":".lnw-ad"},{"a":".ft-advert"},{"a":"#panel-38-0-1-1,\n.vmagazine-lite-medium-rectangle-ad"},{"a":".mom_contet_e3lanat"},{"a":".elementor-element-4f2ae98,\n.elementor-element-e9b9b10"},{"a":".Ad-Section,\n.google-ads-banner"},{"a":".MR300250"},{"a":"img[alt=\"meghna\"],\nsection.text-center"},{"a":".lrads"},{"a":".av_block"},{"a":"#spc-ads,\n.ti-ads"},{"a":".advertisement-single-float,\n.onads"},{"a":"div[style*=\"padding: 15px 0px; background-color: gray;\"]"},{"a":".dk_only,\n.mob_only,\n.pj-ad-card"},{"a":".td-main-content-wrap .tdm_block"},{"a":"section.widget_media_image:not(#media_image-2)"},{"a":".flexslider-eid"},{"a":"a[href*=\"target=\"]"},{"a":".top_ads_home"},{"a":".single_page_ad"},{"a":"#penci_custom_html-3"},{"a":"#media_image-32"},{"a":".logo-banner .pull-right"},{"a":".add_2_part"},{"a":"#HTML42,\na[href*=\"facebook.com\"] > img,\na[href*=\"goo.gl/\"] > img"},{"a":"a[href*=\"reviewmaster.info\"]"},{"a":"#splide24,\n.post-sidebar-area,\n.slider-below-ads"},{"a":".td-footer-wrapper aside.widget_text img,\n.td-ss-main-sidebar > .widget_text"},{"a":"#home_row .widget_media_image,\n.entry-content p img"},{"a":".stretched_link,\nimg + aside.sidebar"},{"a":"[alt*=\" ad\"]"},{"a":".Amain,\n.R300100"},{"a":".home-featured-boxes,\n.widget_block img:not([src*=\"stop-war.jpg\"])"},{"a":"div[id^=\"vijay-\"]"},{"a":"#adOrGretings"},{"a":"#after-ad,\n#before-ad,\n.Image"},{"a":".sidebar > .widget_media_image"},{"a":".ad3,\n.ad4,\n.spad"},{"a":"#bxnzmefcd-3"},{"a":".news247_ads_banner_widget"},{"a":".d-ad,\ndiv[class*=\"banner\"]"},{"a":"#mvp-side-wrap .widget_media_image"},{"a":".DADD"},{"a":".advt-widget"},{"a":"#layerslider_1"},{"a":".code-block-15 div:nth-child(3),\n.code-block:not(.code-block-15),\n.wp-image-31222,\n.wp-image-3732"},{"a":"#common_top_right_1,\n#mid_level_3_after,\ndiv:has(> .adsbygoogle)"},{"a":"#secondary .widget_block img"},{"a":".addCenter"},{"a":"div[id^=\"AS_O_LHS_\"] > div:nth-child(-1n+6)"},{"a":"#metaslider_widget-6"},{"a":".adSlides,\na[href*=\"niet.uk\"] img"},{"a":".home_add"},{"a":".custom-ads-row,\ndiv[style^=\"width: 728px; height: 90px;\"]"},{"a":"#block-46,\n#block-47"},{"a":".td-a-rec img:not([src*=\"Whatsapp-Strip-scaled-\"])"},{"a":".vv_advst"},{"a":"div[id^=\"vision-\"]"},{"a":"[class*=\"  ad-\"]"},{"a":".breaking-news-area.mt-15"},{"a":".addc img"},{"a":".adda"},{"a":".top-right-ads"},{"a":".single-wrapper-details-sidebar .widget_media_image img:not(.wp-image-212460),\n.widget_media_image > img,\n.widget_sow-editor"},{"a":"div[aria-label*=\"-Advt-\"],\ndiv[aria-label*=\".gif\"],\ndiv[aria-label=\"27.jpg\"],\ndiv[aria-label=\"30.jpg\"],\ndiv[aria-label=\"31.jpg\"],\ndiv[aria-label=\"Auction \"],\ndiv[aria-label=\"Banner-2.jpg\"],\ndiv[aria-label=\"Inder Lyn-19 June 2020-2.jpg\"],\ndiv[aria-label^=\"HSB-\"],\ndiv[aria-label^=\"Love-Punjab-\"],\ndiv[aria-label^=\"Mandy-Gur\"],\nnav + div"},{"a":".slides"},{"a":".blog-sidebar .widget_custom_html"},{"a":"#author-bio-widget-1"},{"a":".header-wraper .fullwidthabanner"},{"a":"section[data-id=\"9a0f91e\"]"},{"a":"#secondary section.widget_block"},{"a":".entry-content > p img:only-child"},{"a":"body > .container > .row:first-child > div:last-child"},{"a":"#attachment_10957,\n#attachment_11499,\n#attachment_11653,\n#attachment_12010,\n#attachment_12428,\n#attachment_12691,\n#attachment_12880,\n#attachment_12945,\n#attachment_13381,\n#attachment_13529,\n#attachment_13539,\n#attachment_13549,\n#attachment_13929,\n#attachment_14460,\n#attachment_15074,\n#attachment_15085,\n#attachment_15191,\n#attachment_16388,\n#attachment_16691,\n#attachment_17141,\n#attachment_17329"},{"a":"#right-sidebar .widget_sp_image"},{"a":"#topleftAd,\n#toprightAd"},{"a":".adver_banner,\n.theiaStickySidebar .ml-slider"},{"a":".header-subscription"},{"a":".single_featured_slide"},{"a":".addd_banner"},{"a":"a[href*=\"waltonbd.com\"]"},{"a":"div[class*=\" ad-slot-\"]"},{"a":".bannertopimg,\n.bannertopimg2"},{"a":".vc_custom_1546328500609"},{"a":".chand-before-content_5,\n.chand-widget,\n.widget_viral_advertisement"},{"a":".t-out-span"},{"a":".single_dtails img,\nfigure.wp-block-embed"},{"a":".banner-muni-add"},{"a":".d-flex,\niframe[style*=\"height: 90px\"]"},{"a":"div[class*=\"bnner\"]"},{"a":".ad-ticker-right,\n.entry-content [data-position]"},{"a":".advertise_part"},{"a":".yvdo"},{"a":".roadblockpopup,\n.seithigalad"},{"a":".zja"},{"a":".wpb_wrapper aside.widget_media_image"},{"a":".code-block > img,\nfigure.wpb_wrapper"},{"a":".mySlideBox,\na[href*=\"?ref=\"]"},{"a":"a[target=\"_blank\"] > img"},{"a":".vc_raw_html:not(.tdi_128)"},{"a":".header_adv"},{"a":"#widget_sp_image-3,\n#widget_sp_image-7,\n.bwp_gallery,\n.sidebar-right"},{"a":"#thumbs,\n.add_inner_news,\n.news-add"},{"a":".logoright"},{"a":"#module_03_ads300x250"}];

const hostnamesMap = new Map([["reporter.live",0],["trendingnewshindi.live",1],["ada.lk",[2,3]],["lankadeepa.lk",2],["alayadivembuweb.lk",4],["colombotamil.lk",5],["rni.news",5],["divaina.lk",6],["giraya.lk",7],["lknews.lk",8],["nethgossip.lk",9],["nethnews.lk",10],["newsfirst.lk",11],["newsview.lk",12],["saaravita.lk",13],["smartlady.lk",14],["subasetha.lk",15],["tamilcnn.lk",16],["thamilan.lk",17],["vaaramanjari.lk",18],["valampurii.lk",19],["voiceofmedia.lk",20],["wijeya.lk",21],["truecopythink.media",22],["24ghanta.net",23],["andhrabhoomi.net",24],["aperata.net",25],["bonikbarta.net",26],["channeltoday.net",27],["cinesnacks.net",28],["cnibd.net",29],["crimenewsbd.net",30],["dainikchattogram.net",31],["dainikpurbokone.net",32],["dakhal.net",33],["deshergarjan.net",34],["edainikazadi.net",[35,36]],["edainikpurbokone.net",35],["eenadu.net",37],["everesttimes.net",38],["goodmorningindia.net",[39,40]],["himalipatrika.com.np",40],["kuppilan.net",41],["lankanewsweb.net",42],["mathagal.net",43],["muznews.net",44],["mymarathi.net",45],["namastenri.net",46],["natunsomoy.net",47],["nellaionline.net",48],["tutyonline.net",[48,73]],["news24bd.net",49],["newsdoor.net",50],["ourbiratnagar.net",51],["ourislam24.net",52],["ournewsbd.net",53],["patradoot.net",54],["prajavani.net",55],["ratdinnews.net",56],["sabkikhabar.net",57],["sahilonline.net",58],["sharebiz.net",59],["shomoynews.net",60],["songkalpo.net",61],["soninews.net",62],["starbanglanews.net",63],["sylhetprotidin24.net",64],["sylhetview24.net",65],["tamilarul.net",66],["tamilserialtoday-247.net",67],["telugutimes.net",68],["thebharatnews.net",69],["theeditors.net",70],["timenewsbd.net",71],["tollywood.net",72],["update24.net",74],["vijayavani.net",75],["weeklysonarbangla.net",76],["yarldevinews.net",77],["yuvabrigade.net",78],["alorkantho24.news",79],["amankishaan.news",80],["bangla24x7.news",81],["banglamail.news",82],["channelindia.news",83],["eyenews.news",84],["indiaspeaks.news",85],["kalpa.news",86],["kannadi.news",87],["kathir.news",88],["kelopravah.news",89],["liveindia.news",90],["livevns.news",91],["npg.news",92],["odhikar.news",93],["sylhettoday24.news",94],["sylhetview24.news",95],["tcp24.news",96],["vasundharadeep.news",97],["vishwavani.news",98],["visiontimes.news",99],["yoyocial.news",100],["yuvabharat.news",101],["motivatenews.com.np",102],["pokharapatra.com.np",103],["radiokanchan.com.np",104],["tibrakhabar.com.np",105],["punjabiherald.co.nz",106],["sadeaalaradio.co.nz",107],["dailynewsj.online",108],["massnews.online",109],["metroplus.online",110],["muznews.online",111],["newshunter.online",112],["newswings.online",113],["steelcity.online",114],["up80.online",115],["emulyankan.org",116],["janamsakshi.org",117],["khabrainabhitak.org",118],["krishakjagat.org",119],["nagarprabha.org",120],["nationalduniya.org",121],["nbs24.org",122],["sathyadeepam.org",123],["valvainews.org",124],["changetv.press",125],["chandrikadaily.qa",126],["notebook.today",127],["ab71.tv",128],["abcnepal.tv",129],["dbcnews.tv",130],["livetimes.tv",131],["news24bd.tv",132],["news71.tv",133],["news71bangla.tv",134],["ns7.tv",135],["probashibangla.tv",136],["ptcnews.tv",137],["samajbad.tv",138],["somoynews.tv",139],["sylheterjanapad.tv",140],["worldpunjabi.tv",141],["banglapost.co.uk",142],["despardesweekly.co.uk",143],["europemalayali.co.uk",144],["weeklydesh.co.uk",145],["tharunaya.us",146]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
