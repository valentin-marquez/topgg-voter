/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// ita-0

const argsList = [{"a":".discount-block,\ndiv[data-wt-name=\"widget-prodotti-migliori\"]"},{"a":".gs_carousel_swiper"},{"a":".widget_ubm-banners-rotation"},{"a":"div[style=\"height:250px;\"]"},{"a":"#topBannerCarousel"},{"a":".button"},{"a":".article_amazon_end,\n.banner_sponsor"},{"a":".action-box"},{"a":".acquista-esterno"},{"a":".banner-right,\n.bottmAdd"},{"a":".card"},{"a":"div[style=\"overflow: hidden; height: 50px; width: 210px; margin: auto;\"]"},{"a":"div[style*=\"min-height: 300px;\"],\ndiv[style*=\"width: 728px; height: 90px;\"]"},{"a":"div[style=\"overflow: hidden; height: 40px; width: 336px; margin: auto;\"],\ndiv[style=\"padding: 0px 0px 6px 0px; min-width:160px; width: auto; min-height: 600px;\"],\ndiv[style=\"padding: 0px 0px 6px 0px; width:160px; min-height: 600px;\"]"},{"a":".ad-box"},{"a":".vce-featured-header-background"},{"a":".banner-mid,\n.referral-small"},{"a":"#sp-testata"},{"a":".tdi_108_886,\n.wpls-logo-showcase-slider-wrp"},{"a":".goriz-widget"},{"a":"#sponsorizzato"},{"a":".wpb_gallery"},{"a":".laluc-widget,\ndiv[id^=\"laluc-\"]"},{"a":".vc_custom_1621492912685"},{"a":".widget_media_image"},{"a":".banner-top-left,\n.banner-top-right,\n.content-banner-right"},{"a":"img[width=\"300\"][height=\"252\"],\nimg[width=\"300\"][height=\"289\"],\nimg[width=\"300\"][height=\"90\"],\nimg[width=\"315\"][height=\"150\"]"},{"a":"#Banner"},{"a":".bn-header"},{"a":".no_pop"},{"a":".alert.alert-success"},{"a":"div[id^=\"article-desk-after-header-ad_\"],\ndiv[id^=\"article-desk-before-footer-ad_\"]"},{"a":"div[style=\"width: 300px; height: 260px; margin-top: 10px;\"]"},{"a":"#nwg"},{"a":".carte-post-1"},{"a":".banner_tab380"},{"a":".bannerh,\n.mh-footer"},{"a":".wp-block-product-on-sale"},{"a":"#wn-insurance-quote-editor"},{"a":".ziobox"},{"a":"#skin_link_dx,\n#skin_link_sx,\n.skin_link_top"},{"a":"#text-31"},{"a":".hijau"},{"a":".primobanner-320,\n.widget_realty_widget,\nAMP-IMG[width=\"320\"][height=\"50\"],\nimg[height=\"300\"][width=\"250\"]"},{"a":".post-div-banner-sp-medium"},{"a":".slide-image"},{"a":"a[href*=\"//altadefinizione-4k-ita.php\"]"},{"a":"a[href*=\"//streaming-ita.php\"],\na[href*=\"/scaricare-film.php\"]"},{"a":"a[href*=\"/streaming-gratis.php\"]"},{"a":".bbtn"},{"a":"div[id^=\"tribu-\"]"},{"a":".socia-adlabel"},{"a":".guardasingle"},{"a":"#fpub-popup"},{"a":"div[style=\"width:970px; height:250px; margin:20px auto; float:left;\"]"},{"a":"a[href*=\"/scar.php\"]"},{"a":"iframe[style*=\"z-index: 2147483647\"]"},{"a":"#banner2"},{"a":".big_box"},{"a":".elementor-element-e5738ed"},{"a":".tdi_118,\n.tdi_144"},{"a":".pull-left,\n.pull-right"},{"a":".box-tva,\n.news-sponsorizzate"},{"a":"#sezpartnercommerciali,\n.partner2"},{"a":"a[href^=\"https://www.aliperme.it/\"]"},{"a":".navbar-purina-red"},{"a":".pre_footer"},{"a":".publis-bottom"},{"a":"#leader-left2"},{"a":".widget-banner-container"},{"a":"#panel-2-4-3-1,\n#panel-2-4-3-3"},{"a":".container-ads,\n.container-skin"},{"a":".banner_single_top"},{"a":"a[href^=\"https://iptv01.tw/\"]"},{"a":".hp__banner"},{"a":"a[href*=\"/HD/\"]"},{"a":".other_link2"},{"a":".guarda"},{"a":".client_logos,\n.home_sponsor,\n.inner_left_top"}];

const hostnamesMap = new Map([["quotidiano.net",0],["cittafuture.quotidiano.net",1],["radiodigione.net",2],["risorsedidattiche.net",3],["sardegnalive.net",4],["scaricarelibri.net",5],["scozia.net",6],["selectra.net",7],["sololibri.net",8],["solovela.net",9],["tuttoandroid.net",10],["tuttocagliari.net",11],["tuttocalciatori.net",12],["tuttonapoli.net",13],["tvdream.net",14],["uscatanzaro.net",15],["viversano.net",16],["youtg.net",17],["fiorentina.news",18],["goriziaoggi.news",19],["ildubbio.news",20],["itvonline.news",21],["laluce.news",22],["pangea.news",23],["subito.news",24],["torresette.news",25],["umbriaoggi.news",26],["direttagol.one",27],["giornal.one",28],["filmpertutti.onl",29],["pagare.online",30],["aleteia.org",31],["incircolo.altervista.org",32],["anteritalia.org",33],["carteprepagate.org",34],["fidaf.org",35],["filmforlife.org",36],["fitnesspalestra.org",37],["guidaviaggi.org",38],["ilmigliore.org",39],["iovivoaroma.org",40],["lamiavitainvaligia.org",41],["mathadvantage.org",42],["nursetimes.org",43],["sslazio.org",44],["unimondo.org",45],["altadefinizione01.page",46],["filmstreaming.page",47],["piratestreaming.page",48],["altadefinizione4k.tv",[48,55]],["guardaserie.skin",49],["tribunapoliticaweb.sm",50],["gas.social",51],["ilgeniodellostreaming.to",52],["1web.tv",53],["adessoin.tv",54],["animelove.tv",56],["cataniapubblica.tv",57],["ilcaffe.tv",58],["ilsalottodelcalcio.tv",59],["jamma.tv",60],["lostrillone.tv",61],["montagna.tv",62],["msmotor.tv",63],["padovasport.tv",64],["petpassion.tv",65],["pisachannel.tv",66],["prendiporno.tv",67],["pupia.tv",68],["supertennis.tv",69],["tgtourism.tv",70],["tiburno.tv",71],["tutto.tv",72],["calcio.tw",73],["vaticannews.va",74],["ilgeniodellostreaming.vin",75],["eurostreaming.vote",76],["eurostreaming.voto",77],["umbria.webcam",78]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
