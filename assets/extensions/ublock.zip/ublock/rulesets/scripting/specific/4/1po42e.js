/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// vie-1

const argsList = [{"a":".widget_media_image.widget_block.widget,\nimg.wp-image-1283,\nimg.wp-image-1285"},{"a":"#match-child-1,\n#quangcaopc,\n.banner-link,\n.block-catfish.text-center.d-lg-none.d-block,\n.container.mt-1,\n.container>ul,\n.d-lg-flex.d-none.sub-menu,\n.logo-cnt>.d-lg-none.d-block,\n.menu-cuoc-one88,\n.menu-top-nha-cai,\n.mt-5.d-lg-none.d-block.pb-2.text-center,\n.offer,\n.pl-lg-0.col-xl-4,\n.row.d-none,\n.sk_balloon,\n.widget-offers__list,\na.btn-odds[rel=\"nofollow\"],\ndiv.d-lg-none.d-block:nth-of-type(3)"},{"a":".top-mobile-banner"},{"a":"#itro_popup"},{"a":".banner-top-box"},{"a":"#position_full_top_banner_pc,\n.window_popup"},{"a":"#newmenu + div>div[style]"},{"a":".button-dangkyngay"},{"a":".afw-topbanner"},{"a":"#adm-slot-7234"},{"a":"#banner3double"},{"a":".box-ads-bar"},{"a":"div[id^=\"adsWeb\"]"},{"a":".BT-Ads,\n.qc-inner,\ndiv.qc_TC_Chap_Middle,\ndiv[id^=\"qc_M_\"],\ndiv[style*=\"position: fixed;\"]"},{"a":".bgadmtoptotal"},{"a":".bannertop"},{"a":".top-right-col-ads"},{"a":".my_responsive_add,\n.titleBar + *,\n[class1=\"my_responsive_add\"]"},{"a":"#csnplayerads,\n.detail_lyric_1 div[style=\"text-align: right;\"]"},{"a":"#background_bg_link,\n#maiContent>div>div.colLt>aside,\n.bnr,\n.cate-24h-foot-box-adv-view-news > .row > .col-6:first-child,\nDIV[class=\"banner-LR\"],\ndiv.pos-rel:has(a[rel=\"nofollow sponsored\"])"},{"a":".admicro"},{"a":".top-header"},{"a":"#onefootball,\n.top_page"},{"a":"#subiz_wrapper,\n.ad-embed"},{"a":".features-r"},{"a":"#bannerMasthead,\n#desktop-home-top-page,\n#dta_inpage_wrapper,\n#dtads_inpage_wrapper,\n#mobile-home-middle-1,\n#mobile-home-middle-2,\n#mobile-home-top-page,\n#mobile-top-page"},{"a":".widget_media_image.widget"},{"a":".banner-cs"},{"a":".banner-top-main,\n.baohaiquan_bottom_970x250"},{"a":".top-advertisment"},{"a":"._ning_outer"},{"a":"#Adsv,\n.right-banner>a[title]"},{"a":".__ads_click"},{"a":"#BannerAdv"},{"a":"#gallery-2,\n.hd-cate-wrap,\n.home-qc-wrap,\n.home-sec-right .widget_media_image,\n.noname-left"},{"a":".columns-widget .col-right"},{"a":".chapter-content .min-h-\\[275px\\]"},{"a":".Advs_adv-components__1nBNS.Advs_adv-300x250__2eyhC.Advs_no-content__RWwW2,\n.HotTagGlobal_fixed-height__1f50i"},{"a":".box_ads_d"},{"a":".exp_qc_share"},{"a":".c-banner"},{"a":".warp-banner-vip"},{"a":".sidebar>div[style]"},{"a":"#div-ub-docbao"},{"a":"#ouibounce-modal,\ndiv[id^=\"adsbg\"]"},{"a":"#widget-12"},{"a":"#widget-11,\n#widget-16,\n.mainContent>a[rel]"},{"a":".banr-Rt,\n.banrpstn"},{"a":"#myElementz,\n.bannerinfooter"},{"a":".LRBanner"},{"a":".bg_allpopupss,\n.bgal_popndungalal,\n.bn1,\n.bn2,\n.box_baiviet_dexuat,\n.box_quangcao_mobile_320x50,\n.box_text_qc"},{"a":"#tubia"},{"a":"#admzone57"},{"a":".ads-right1,\n.adv-row"},{"a":".adx-zone,\n.underlay"},{"a":".khw-ads-wrapper.clearfix"},{"a":"#qcRight,\n.banner-advertisements"},{"a":".banner-bottom-menu,\n.popup-bg,\n.showpop,\n[href*=\"bit.ly\"]"},{"a":".qc-benphai,\n.qc-bentrai"},{"a":"[class^=\"size\"]"},{"a":"#adrightsecondx,\n#adrightspecial,\n#adrightspeciallinks,\n#adsrighttop,\n#adsuggestion"},{"a":".advertTop,\n.hsdn > li:has(.adsbygoogle),\n.module_plugins"},{"a":".notice-content"},{"a":".khw-adk14-wrapper"},{"a":"[id^=\"adv\"]"},{"a":".quang_cao_pc_right_hoc_tap"},{"a":".advHolder"},{"a":".ads_shortcode"},{"a":".admicro_top"},{"a":"#tdi_129"},{"a":".sponsor-zone"},{"a":"div[id^=\"ads_\"]"},{"a":"#box-affiliate"},{"a":"#top-adv"},{"a":".bannerchuyenmuc,\n.show-qc-home,\n.show_qc"},{"a":".baseHtml.noticeContent"},{"a":"#popup_center"},{"a":"div[style=\"text-align:center;margin-top:0px;margin-bottom:0px;\"]"},{"a":".banner-ads-home,\n.banner-in"},{"a":"div[class^=\"adv-\"]"},{"a":".ads-970x280"},{"a":"#mobi-top,\n#pc-top,\n.d-flex.justify-content-between>div>div.d-flex.justify-content-around.mt-4"},{"a":"#myCarousel,\n.banner-boder-zoom"},{"a":".modal-di__button-wrapper,\n.sam-slot"},{"a":"[id^=\"admzone\"]"},{"a":".ads-general-banner"},{"a":".LeftFloatBanner,\n.RightFloatBanner,\n.ads_top_left"},{"a":".ads-gg-top,\n.container + .col-xs-12.content_wrap,\n.content>.content>.content,\n.wrap-single>.pagination.text-center"},{"a":".block:has(.block-container > .block-body > a[href]),\n.block:has(.block-container > .block-body > ins)"},{"a":".asd-headt,\n.super-masthead,\n[class*=\"box-home\"]"},{"a":"div[class$=\"_ads\"],\ndiv[data-id=\"2\"]"},{"a":".ads_660x90,\n[class^=\"ads_\"]"},{"a":".bannerTOP1,\n.pc.bannerAuto"},{"a":"div[id^=\"adsMobile\"]"},{"a":".fyi"},{"a":".ads-common-box"},{"a":".p-body-pageContent>table[style=\"width:100%;display:inline-block;background: #fff;\"]"},{"a":".in-article-promo,\n.jsx-3569995709,\n.micro,\n.middle-comment-promotion,\n.pro-container,\n.promo-container,\ndiv[style=\"width:300px;height:250px\"],\ndiv[style=\"width:300px;height:600px\"],\ndiv[style=\"width:320px;height:100px\"]"},{"a":".container .desktopjszone,\n.mobilejszone"},{"a":"#header-ads-full,\n.ads-responsive,\n[id^=\"ads-\"]"},{"a":"#LeaderBoardTop,\n#admbackground,\n#adsMainFooter,\n.Mobile_Masthead_TTO_Wrapper,\n.adm-bot,\n.box-qad,\n.section__r-vietlot,\n.wrapper-ads-mb"},{"a":".clearfix.adregion,\n.visible-md.header-banners"},{"a":".bannerqc,\n[class^=\"sticky-top\"],\n[href*=\"/default/template/\"],\n[href*=\"hungthinhcorp.com.vn\"],\n[href*=\"vietcombank.com.vn\"]"},{"a":".Flagrow-Ads-under-header"},{"a":".vfs_banner"},{"a":"#headerProxy,\n.rightleftads"},{"a":"#vmcad_sponsor_middle_content,\n.box-adv,\n.mb-20.col-right-ads,\n.vmcadszone"},{"a":".zone--ad"},{"a":"section.mar20:nth-of-type(2),\nsection.mar20:nth-of-type(4)"},{"a":"#banner-dai-bottom,\n#banner-dai-top"},{"a":".v-element>.v-responsive,\ndiv.message--post"},{"a":".ads-top-wrap"},{"a":".bf-3-primary-column-size.bs-vc-sidebar-column.vc_col-sm-3.vc_column_container.bs-vc-column.wpb_column>.wpb_wrapper.bs-vc-wrapper"},{"a":".wrapper-adv"},{"a":"#banner1ab,\n#banner2ab"},{"a":".ad_by_yellowpages,\n.banner_add"},{"a":"#Zingnews_SiteHeader,\n#site-header,\n.znews-banner"},{"a":"#ballon_right"},{"a":".odds-button,\n.odds-button2"}];

const hostnamesMap = new Map([["vietphims.tv",0],["xoilac52.tv",1],["phim18hd.us",2],["phimmoi.vip",3],["24hmoney.vn",4],["2banh.vn",5],["2game.vn",6],["blog.abit.vn",7],["afamily.vn",8],["sport5.vn",8],["m.afamily.vn",9],["autodaily.vn",10],["xehay.vn",[10,114]],["baodansinh.vn",11],["baodauthau.vn",12],["tienphong.vn",[12,93,94]],["blogtruyen.vn",13],["cafebiz.vn",14],["cafef.vn",15],["ttvn.toquoc.vn",15],["careerlink.vn",16],["chap.vn",17],["chiasenhac.vn",18],["24h.com.vn",19],["autopro.com.vn",20],["baohaugiang.com.vn",21],["bongda.com.vn",22],["congan.com.vn",23],["daklak24h.com.vn",24],["dantri.com.vn",25],["ecci.com.vn",26],["fptshop.com.vn",27],["haiquanonline.com.vn",28],["nld.com.vn",29],["tapchikientruc.com.vn",30],["thanhtra.com.vn",31],["thoidai.com.vn",32],["petrotimes.vn",32],["thuongtruong.com.vn",33],["thuysanvietnam.com.vn",34],["trithuc24h.com.vn",35],["truyenchu.com.vn",36],["voh.com.vn",37],["congluan.vn",[38,39]],["giadinhonline.vn",39],["nongnghiep.vn",39],["congly.vn",40],["dangtinbatdongsan.vn",41],["realty.vn",[41,78]],["danviet.vn",42],["docbao.vn",43],["download.vn",44],["gamevui.vn",[44,54]],["kienthucykhoa.edu.vn",45],["plus.edu.vn",46],["eva.vn",47],["fshare.vn",48],["game24h.vn",49],["game8.vn",50],["gameio.vn",51],["gamek.vn",52],["gametv.vn",53],["genk.vn",55],["giaoducthoidai.vn",56],["vnews.gov.vn",57],["plus.gtv.vn",58],["helpex.vn",59],["hoatieu.vn",60],["hosocongty.vn",61],["hrspring.vn",62],["kenh14.vn",63],["kinhtedothi.vn",64],["minhngoc.net.vn",64],["vn-z.vn",64],["zingnews.vn",[64,116]],["lazi.vn",65],["luatvietnam.vn",66],["lucloi.vn",67],["muare.vn",68],["muaxegiatot.vn",69],["kienthuc.net.vn",70],["phunumoi.net.vn",71],["nhipcaudautu.vn",71],["nghesiviet.vn",72],["nhacdj.vn",73],["nhatrangclub.vn",[74,75]],["raovatbienhoa.vn",75],["olug.vn",76],["phapluatplus.vn",77],["reatimes.vn",79],["rung.vn",80],["saostar.vn",81],["sharecode.vn",82],["softonic.vn",83],["soha.vn",84],["startalk.vn",85],["stockbiz.vn",86],["tamlinh247.vn",87],["techrum.vn",88],["thanhnien.vn",89],["thethao247.vn",90],["thethaovanhoa.vn",91],["thitruongtaichinhtiente.vn",92],["tinnhanhchungkhoan.vn",94],["tiin.vn",95],["timdaily.vn",96],["tinhte.vn",97],["tintucvietnam.vn",98],["truyenfull.vn",99],["tuoitre.vn",100],["tuyengiao.vn",101],["tvphapluat.vn",102],["v4u.vn",103],["vietfones.vn",104],["vietnamgsm.vn",105],["vietnamnet.vn",106],["vietnamplus.vn",107],["vietq.vn",108],["viettelstore.vn",109],["voz.vn",110],["vtvgiaitri.vn",111],["vungoctuan.vn",112],["webthethao.vn",113],["yellowpages.vn",115],["truyenqk.work",117],["plvb.xyz",118]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
