/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// irn-0

const argsList = [{"a":"#ContentPlaceHolder1_divBanner"},{"a":"[class*=\"text_ads\"]"},{"a":".list,\n.t-adv,\ndiv.post:nth-of-type(2)"},{"a":".header-mdh,\n.pull-right.zm-post-lay-a-area"},{"a":".ad-mobile-none,\n.ads-native"},{"a":".custom,\n.customads"},{"a":".FixedAdvertising,\n.left.sidebar_widget:nth-of-type(3),\n.left_ads,\n.right_ads,\n.top_ads"},{"a":".sidebar > div.box:nth-of-type(5)"},{"a":"#next1-231,\n.asd_top,\n.fl.block_right > div.box_sh.ads_2"},{"a":".sidebar_tabliq,\n[href^=\"/ads/\"]"},{"a":".doctor-ads-item"},{"a":"#header_ad,\n.sb_ad"},{"a":".zxc-mobile"},{"a":".banner468,\n.tab_box"},{"a":"[href^=\"/redirect/ads/\"]"},{"a":"#mainadv,\n#pos-article-display-70266,\n.biga,\n.htmlad"},{"a":".advertise_default"},{"a":".c-forceToLogin__message.o-box,\n.c-forceToLogin__overlay"},{"a":".im-header-ad"},{"a":".textads"},{"a":".go-left.main > div.row.box:nth-of-type(1),\n.middle.inner-el.container > div.row.box:nth-of-type(2),\ndiv.black.row.box"},{"a":"#textads-contents,\n.ads-containter"},{"a":"#ads-container > .list-thumbs.title-only.list.box,\n#header-ad,\n.bg-gray-links.box"},{"a":".ads_bt_box,\n.ads_singles_post,\n.top_img_ads"},{"a":".type-sticky.status-publish"},{"a":".ads-widget"},{"a":".down-box-ads,\n.down-box1"},{"a":".singleads"},{"a":"[id^=\"ad\"]"},{"a":"#bottombanner,\n.apnl,\n.b"},{"a":"#sezfvg-2,\n.sezfvg,\n.sticky-column:not(:has(a[href*=\"modirnameh.ir\"]))"},{"a":".txt-ads-sl"},{"a":".banneritem:has(a[href*=\"/banners/click/\"]),\n.eb-inst"},{"a":".adspanel"},{"a":".adsblockpop,\n.afc_popup,\n.banners,\n.textAds"},{"a":"#fxp,\n#kaprila_p30download_ir_related,\n#kaprila_p30download_ir_related-top-post,\n.basic-list-linkdump,\n.sidebar-tabliq,\n.text-tabliq"},{"a":".body_wrapper > div:nth-of-type(4)"},{"a":"#custom_html-108,\n.stream-item-top,\n.widget_custom_html:has(img[src*=\".gif\"])"},{"a":"div > div > a.toolt > .onsc"},{"a":".ad--content"},{"a":".ytn-hamsan"},{"a":".c-advertisement"},{"a":".banner-box"},{"a":".tabligh-logo"},{"a":".center.body_c > div > div,\n.center.body_c > div:nth-of-type(2),\n.txtad"},{"a":"#ad7_40,\n.footer-ads"},{"a":"[href*=\"/fa/ads/\"]"},{"a":".left_banner,\n.links"},{"a":"#arasideadvertising"},{"a":"#ads3,\n.main-ads,\n.morders,\n.textads2"},{"a":".heading-ads,\n.sidebar-right > div.box:nth-of-type(1)"},{"a":".adv_mobile"},{"a":".textwidget,\naside:nth-of-type(5)"},{"a":".backoritybase,\n.news-box,\n.text-ads-1,\n.widgets.bg-custom.box"},{"a":"#cycle_adv_tabnak"},{"a":".Topadver"},{"a":".ads120000,\ndiv.Relement.Bstyle.RBC:nth-of-type(5)"},{"a":"[class^=\"adv\"]:not(.adv8,.adv19)"},{"a":".inner-wrapper-sticky > .mb-3,\n.sidebar-banners"},{"a":".type-resource-image"},{"a":".side1:has(a[title][rel=\"noopener noreferrer\"])"},{"a":".advertisment"},{"a":"#fpc-banner-top,\n#top-right-ad,\n.content-container:has(.ad-reportage),\n.square-ad:not(:has(#featured-posts))"},{"a":".full2.box.right,\ndiv.sideheader2:nth-of-type(3)"},{"a":".footer-back-link,\n.free_ad_con,\n.logo_full_view"},{"a":"[href*=\"b2n.ir\"]"},{"a":"#tabligh"},{"a":".ads120,\n.ads468,\n.fixpost,\n.gsh,\n.headads"},{"a":".bottom_ads,\n.fix_ads,\n.stream-item-widget:has(a[href*=\"faradars.org\"])"},{"a":".textad,\n[href^=\"/ad/\"]"},{"a":"#kaprila_linktable_left,\n.left-block-top"},{"a":"#slider-box,\n.mortabet-links,\ndiv.row:nth-of-type(2) > .col-xs-12 > .category-side-ads"},{"a":".advertisements"},{"a":".sideads"},{"a":"#mobileBannerAfterTags,\n.main-top-ads,\n.wide-ad-row"},{"a":".price-sticky,\n.wide-adv-row,\n[class*=\"BrowseArticleItem___StyledFlex\"]:has(a[href*=\"/pr/\"]),\n[class^=\"AdvertisingParser\"],\n[class^=\"DisplaySkeleton__DisplayRoot\"]"},{"a":".col-sm-9.main-right > .col-sm-3 > aside.block:nth-of-type(2),\n.text-center.justify-content-around.row"},{"a":".flex-ad-body"},{"a":"#ads-sticky"},{"a":"#ads-text"},{"a":".box-title,\n.moreads.widget_text,\n.pm"},{"a":".mom_custom_text.widget,\n.widget_custom_html.widget.widget_text"},{"a":".ads-container,\n.ads-row,\n.ads-row-left,\n.mediaad-row,\n.mediaad-row-top,\n.mediaad-top-row,\n.top-ad-row"},{"a":"#ad14,\n.ad-cell,\n.widget_text"},{"a":".content_item:has(a[href*=\"/category/ads/\"]),\n.sidebar-area .image"},{"a":".adpar30,\n.adsidimg"},{"a":".fixedbanner,\n.mobilebanner,\n.sidebar-box-shop,\n.top-large-ads,\n[href^=\"https://playpod.ir/\"]"},{"a":".my-single-t-p"},{"a":".dailylink,\nbody > div > font,\ncenter > center > center > center,\ncenter:nth-of-type(2) > center,\ndiv > font > font > .menuheader,\ndiv > font > font > font > p"},{"a":".adv-cnt,\n.home-zxc,\n.padding-bottom-8,\n.sanjagh,\n.side_txt_zxc,\n.zxc-header-zxc,\n.zxc-padding-custom,\n.zxc_c9"},{"a":"#box_1398,\n#popbox-blackout"},{"a":".AdsContainer"},{"a":".special_links,\n.text_adds_container"},{"a":".zxc_news"},{"a":".featured_news"},{"a":".zxc_left"},{"a":".ads-full-banner-img"},{"a":".vebgardi"},{"a":".jmb_banner"},{"a":".inline-4d"},{"a":".adrightPanel,\n.container55,\narticle > .box > a[href*=\"salampnu.com\"]"},{"a":".vfozk"},{"a":".aligncenter.wp-image-9273.size-full,\n.size-full.attachment-full"},{"a":".myside.right-sidebar"},{"a":"#popup-layer-container,\n.advertise,\n.bottom-left-ad,\n.bottom-right-ad"},{"a":".adsBanner,\n.two-ad-banners,\n.widget_media_image.widget.container-wrapper"},{"a":"#posts_single_ads,\n#top_ads"},{"a":"#titr-box,\n.maincontent > center,\ntbody"},{"a":"#sidebar_ad,\n.b-hd,\n.hidden-xs.hidden-sm.block,\n.hideOnMobile"},{"a":".new-banner"},{"a":".abvertise > .container > a:not(a[href=\"https://t.me/filmha_top\"])"},{"a":".tabliq"}];

const hostnamesMap = new Map([["emalls.ir",0],["emeil.ir",1],["fa-tools.ir",2],["faceit.ir",3],["farsnews.ir",4],["freedownload.ir",5],["freescript.ir",6],["gamesetup.ir",7],["gamesib.ir",8],["gsm.ir",9],["hidoctor.ir",10],["imemar.icivil.ir",11],["ilna.ir",12],["imgurl.ir",13],["imna.ir",14],["khabaronline.ir",[14,22]],["iranjib.ir",15],["itna.ir",16],["jobinja.ir",17],["kafebook.ir",18],["kalakamuz.ir",[19,20]],["varoone.ir",[19,67]],["ariapix.net",19],["my-film.pw",[19,107]],["khaandaniha.ir",21],["khodropluss.ir",23],["languagedownload.ir",24],["lastsecond.ir",25],["listen2music.ir",26],["loudmusic.ir",27],["mashreghnews.ir",28],["mobile.ir",29],["modirnameh.ir",30],["montiego.ir",31],["moviemag.ir",32],["omidnamehnews.ir",33],["p30day.ir",34],["p30download.ir",35],["parsipet.ir",36],["pedal.ir",37],["pgnews.ir",38],["plaza.ir",39],["power-music.ir",40],["rahnamato.ir",41],["rond.ir",42],["rouydad24.ir",43],["rozup.ir",44],["sena.ir",45],["shahraranews.ir",46],["shmi.ir",47],["sid.ir",48],["skinak.ir",49],["smusic.ir",50],["snn.ir",51],["sornamusic.ir",52],["subf2m.ir",53],["tabnak.ir",54],["taknaz.ir",[55,56]],["talab.org",55],["tehranrasaneh.ir",57],["timecity.ir",58],["tinn.ir",59],["iranart.news",59],["top90.ir",60],["topseda.ir",61],["toranji.ir",62],["up44.ir",63],["uplod.ir",64],["uptrack.ir",65],["uupload.ir",66],["vgdl.ir",68],["vista.ir",69],["webgoo.ir",70],["webii.ir",71],["yun.ir",72],["zohur12.ir",73],["zoomg.ir",74],["zoomit.ir",75],["hamtamovie.lol",76],["filmino.me",77],["androidina.net",[78,79]],["salamdl.rip",[79,108]],["cooldl.net",80],["dlbook.net",81],["footballi.net",82],["gadgetnews.net",83],["jeyran.net",84],["par30dl.net",85],["par30games.net",86],["parsroid.net",87],["pichak.net",88],["rokna.net",89],["takblog.net",90],["yektablog.net",90],["article.tebyan.net",91],["uplooder.net",92],["55online.news",[93,94]],["gostaresh.news",[93,95]],["mobo.news",96],["sobhtazeh.news",97],["techna.news",98],["titr.online",99],["20file.org",100],["bazdeh.org",101],["gold-team.org",102],["texahang.org",103],["tgju.org",104],["wikihoax.org",105],["zoomtech.org",106],["oila.tj",109],["filmha.top",110],["harmonydl.us",111]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
