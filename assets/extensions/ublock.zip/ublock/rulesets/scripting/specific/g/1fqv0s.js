/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// spa-1

const argsList = [{"a":"#pbt"},{"a":".e3lan"},{"a":"div[id^=\"bloco\"]"},{"a":"center > a[href^=\"https://bit.ly/\"][rel=\"noopener\"] > img"},{"a":"div[class^=\"escomad\"]"},{"a":"#content > div.contentBox+center,\n.garotaslindas"},{"a":"#cboxOverlay,\n#colorbox"},{"a":"img[style=\"border: 0px solid; width: 300px; height: 250px;\"]"},{"a":"ol#messageList > li.message:not([id]):not([data-author])"},{"a":".adblock_detect"},{"a":"a[href=\"http://www.primecursos.com.br/\"]"},{"a":"a[href^=\"http://tocarviolao.com.br/\"]"},{"a":"a.descarga_href_big"},{"a":"a[href^=\"javascript:void(centerpopup('https://bit.ly/\"][rel=\"nofollow\"],\na[href^=\"javascript:void(centerpopup('https://goo.gl/\"][rel=\"nofollow\"]"},{"a":".TpRwCont > aside > div.ai_widget,\n.TpRwCont > aside > div.widget_text"},{"a":".sidebaha[style^=\"background-color:\"]"},{"a":".cuad01,\n.headpub,\n.pub60"},{"a":".post-content > div[style=\" margin:12px; text-align:center\"] > a[rel=\"nofollow\"]"},{"a":"center > div.separator"},{"a":"a[href^=\"//mellowads.com/\"]"},{"a":"div[class*=\"pb-pub-\"]:not(.pb-pub-6)"},{"a":".box_gr"},{"a":"a[href^=\"https://ladsanz.com/\"]"},{"a":".banner-336x280"},{"a":"#DESCARGAslidein,\n#ddbar,\niframe[height=\"600\"],\niframe[width=\"130\"],\niframe[width=\"300\"],\niframe[width=\"728\"]"},{"a":"div[style=\"height:300px;\"]"},{"a":"a[href^=\"https://goo.gl/\"] > img"},{"a":".header,\na[href^=\"http://todaoferta.uol.com.br/\"]"},{"a":"center > a[href][target=\"_blank\"]"},{"a":"div[class^=\"content_gpt_\"]"},{"a":"[data-ads-name]"},{"a":".aside-ads-top"},{"a":".orbitslider"},{"a":"div[class^=\"content_gpt_caja\"]"},{"a":"#orquidea-slideup"},{"a":"div[style^=\"position: absolute;\"][style*=\"z-index:\"][onclick*=\"anunciotag\"]"},{"a":".box.xx"},{"a":"#headerPub,\n#lastPubPub,\n#topoPUBsidebar"},{"a":"#zahirflut,\n.bn300x250,\n.bn300x75,\n.box-border,\n.mon_td_glb"},{"a":"[style=\"width:300px;height:250px;overflow:hidden;position:relative;\"],\n[style=\"width:300px;height:250px;overflow:visible;z-index:0;\"],\ndiv[style=\"width: 300px; height: 250px; overflow: hidden; position: relative;\"],\ndiv[style=\"width: 300px; height: 250px; overflow: visible; z-index: 0;\"]"},{"a":".mrec"},{"a":".pub-textads"},{"a":".pubHeader,\n.pubTextual"},{"a":".bannerPub"},{"a":".artfundpub"},{"a":".moduletable_publicidade"},{"a":".mrec-status"},{"a":".tg-adhesion-bar"},{"a":".t-pubbox-ct-1,\ndiv[class^=\"t-modsys-pub\"],\ndiv[class^=\"t-pub-\"]"},{"a":"#leaderboard-pub"},{"a":".c-publicity"},{"a":"#Rectangle"},{"a":".advert"},{"a":"#bannerFooter"},{"a":"#bannerMrec"},{"a":"#halfbanner,\n#topPub,\n.col-google,\n.pub-line,\n.pub_full,\n.pub_half"},{"a":"#mrec"},{"a":"#frase2"},{"a":".banner-obj"},{"a":"div[class^=\"t-pub-box-\"]"},{"a":"a[href^=\"http://ad.doubleclick.net/\"]"},{"a":".wow-modal-overlay"},{"a":".beachPartners,\n.dealer-block,\n.liveCamInfoContainer > div.sponsorContainer + div"},{"a":"#table50"},{"a":".commBanners"},{"a":".ad-slot,\n.rmp-ad-outstream,\n.stack__ads,\na[href^=\"http://bs.serving-sys.com/\"]"},{"a":"[align=\"right\"][width=\"348\"],\n[height=\"76\"][width=\"8\"]"},{"a":".GooglePub300_250,\n.PubGoogle300"},{"a":"#MREC2,\n#pub728x90ifrm,\n.BoxPub300x250,\n.PagInicialPub2,\n.bannerMrec,\n.block-pub,\n.comentariosPag,\n.cx-iniciativas-pub,\n.special-ctn,\n.tin-pub-inner,\n[style=\"WIDTH:300px; margin-bottom:10px; TEXT-ALIGN:right\"],\n[style=\"padding: 20px 0px; text-align: center; height: 90px;\"],\n[style=\"padding:20px 0px; text-align:center; height:90px\"],\n[style=\"width: 300px; margin-bottom: 10px; text-align: right;\"],\n[style=\"width: 527px; height: 150px; float: right;\"],\n[style=\"width:527px; height:150px; float:right\"],\ntable[cellpadding=\"5\"][width=\"641\"]"},{"a":".pubTextInfo,\ndiv[id^=\"pubText_\"]"},{"a":".odigi-adlabel"},{"a":"div[id^=\"ws_widget__ad_\"]"},{"a":"#TinAdPopup"},{"a":".t-a-pub-1,\n.t-pubbox-bb-1,\n.t-pubbox-mrec-1"},{"a":"#magazine_modules_receivenewsletter,\n.stk_666"},{"a":".pubframe"},{"a":"#adslot-side-mrec,\n#adslot-top-lead"},{"a":".theiaStickySidebar > #custom_html-2"},{"a":"#ba_avanza,\n#ba_interbanco"},{"a":".adp,\n.adp-underlay"},{"a":".adsInfo,\n.adsLateral"},{"a":"body ~ iframe[style*=\"width:\"][style*=\"opacity:\"][style*=\"z-index:\"][style*=\"position:\"]:not([src])"},{"a":"div[class*=\"gg_ads\"]"},{"a":".enlace_descarga"},{"a":".entry-content center > a[rel=\"noopener\"] > img"},{"a":"#sticky-banner1"},{"a":".inside-header > a[target=\"blank\"] > img,\n.inside-right-sidebar > #custom_html-4"},{"a":".player__happy-inside"},{"a":"a[class^=\"reserve-button\"][target=\"_blank\"] > img,\ncenter > a[class^=\"super-r-button\"] > img"},{"a":".happy-section,\ndiv[class^=\"adde_\"],\ndiv[id^=\"adde_modal-\"]"},{"a":"#content > .contentBox + center,\n#sidebarGeral > .sidebar:first-child,\nbody > center"},{"a":".DvrAbs"},{"a":"#firstClick"},{"a":".the-banner"},{"a":"center > a[target*=\"_blank\"] > img"},{"a":"#frutuante"},{"a":"td[width=\"961\"][height=\"60\"]"},{"a":"#iphone_banner"},{"a":".Ads"},{"a":"td[class=\"style6\"][style=\"height: 53px\"]"},{"a":".generalModal"},{"a":"a[href^=\"https://btt-pt.toldmeroc.com/\"]"},{"a":".TPlayerNv > .Button.STPb[data-tplayernv=\"Opt0\"],\na[href^=\"https://ocio.leadzutw.com/\"]"},{"a":"a[href^=\"http://www.portablemusic.mobi/\"],\np > a[href][rel=\"noopener\"][target=\"_blank\"] > img"},{"a":"#cointainerBanner300,\ndiv#banner300x250"},{"a":".ParceirosLink,\n.Publicidade728"},{"a":"iframe[width=\"220\"]"},{"a":"#superderbi"},{"a":"#capa2"},{"a":"a[href^=\"/play/\"]"},{"a":"body > .vizerNewBox.adsByVizer"},{"a":".comments-pub,\n.movies-pub"},{"a":"a[href^=\"http://www.neobux.com/\"]"},{"a":".c180-home-banners-container,\n.delsol-wrapper,\n.lomas-banner,\n.mgsl--iframe-box,\n.streaming-box"},{"a":".modulo_publi"},{"a":".Page-above,\n.ads-container,\n.ads-under-header,\n.editorial-ads,\ndiv[style=\"width:300px;padding:4px;margin:8px;float:left;border:0px solid #eeeeee;\"]"},{"a":".module1colAds,\ndiv[class*=\"category-secondary-ad\"]"},{"a":"#header-pub"},{"a":".zone-adsense"},{"a":".ultim-adlabel + a[rel=\"nofollow\"],\ndiv[class^=\"ultim-\"]"},{"a":"a[href^=\"https://bit.ly/\"] > img"},{"a":"#adxx"},{"a":".adorshop,\ndiv[style=\"margin-top:.5em;min-height:312px\"]"},{"a":"td[height=\"630\"]"},{"a":"#adsacumulada,\n#adsalosexo,\n#adscamerasex,\n#adsempire,\n#adsmp,\n#adsoriginal,\n#adspb,\n#amigos"},{"a":".sidebar section.widget_block > a[target=\"_blank\"] > img"},{"a":".fg1 > a[target=\"_blank\"].snd"},{"a":"#videoss > section:not([class]),\n.dvcss"},{"a":"#text-19,\n.top-header-ads-mobile"},{"a":".mt_ad"},{"a":".ad-bodyvideo"},{"a":".lst_ft_bn"},{"a":"#block-7,\n.rteam_antiadb"},{"a":"div[style^=\"width:300px;height:250px;display: inline-block;\"]"},{"a":"div[style][onclick*=\"anunciotag()\"]"}];

const hostnamesMap = new Map([["gamestorrents.one",0],["gamesviatorrent.top",0],["buscalinks.xyz",0],["pelisplus.one",1],["empregonews.online",2],["g1novelas.online",3],["g1novelas.org",[3,13]],["ordenador.online",4],["animesorion.org",5],["baixefilmesgratis.org",6],["baixeturbo.org",7],["bmwfaq.org",8],["comandotorrents.org",9],["degracaemaisgostoso.org",[10,11]],["yesfilmes.org",[11,27]],["espaebook.org",12],["gamesfull.org",14],["hayatbul.org",15],["internautas.org",16],["megawarez.org",17],["pastepvp.org",18],["pastesgamesfull.org",19],["dicionario.priberam.org",20],["procurandovagas.org",21],["seriesanimadas.org",22],["tabletsesmartphones.org",23],["tomadivx.org",24],["top10mais.org",25],["torrentbrazil.org",26],["zdescargas.org",28],["elcomercio.pe",[29,30]],["gestion.pe",29],["peru21.pe",[30,32]],["larepublica.pe",31],["trome.pe",33],["listas.pro",34],["megaseriesonline.pro",35],["servernew.xyz",35],["servertwo.xyz",35],["mundotec.pro",36],["acorianooriental.pt",37],["aeiou.pt",38],["autosport.aeiou.pt",39],["caras.pt",40],["exameinformatica.pt",40],["xl.pt",[40,74]],["clix.pt",[41,42]],["publico.pt",[42,65]],["correiomanha.pt",43],["dementia.pt",44],["diariocoimbra.pt",45],["dn.pt",[46,47,48]],["tsf.pt",[46,73]],["jn.pt",[47,59]],["dnoticias.pt",49],["e-konomista.pt",50],["ebuddy.pt",51],["eurogamer.pt",52],["aeiou.expresso.pt",[53,54]],["sapo.pt",[53,54,56,68]],["visao.pt",54],["iol.pt",[55,56]],["rr.pt",56],["diario.iol.pt",57],["ionline.pt",58],["jornaldenegocios.pt",60],["jornaleconomico.pt",61],["beachcam.meo.pt",62],["miau.pt",63],["millenniumbcp.pt",64],["record.pt",66],["rtp.pt",67],["kbb.sapo.pt",69],["odigital.sapo.pt",70],["pplware.sapo.pt",71],["visao.sapo.pt",72],["zerozero.pt",75],["forum.zwame.pt",76],["portal.zwame.pt",77],["lanacion.com.py",78],["link-descarga.site",79],["superanimes.site",80],["pelisplus.so",81],["pdfslide.tips",82],["1v.to",83],["comando.to",84],["canaistv.top",85],["downloadcursos.top",86],["hentai-asia.top",87],["mrpiracy.top",88],["porno-japones.top",89],["animesorion.tv",90],["animespace.tv",91],["cablegratis.tv",92],["canalnet.tv",93],["comandotorrent.tv",94],["filmeshd.tv",95],["infonegocios.tv",96],["justin.tv",97],["lasestrellas.tv",98],["calcular.onlinegratis.tv",99],["pobre.tv",[100,101]],["pobre.wtf",100],["seriesgato.tv",102],["televisionparatodos.tv",103],["tu.tv",104],["tudotv.tv",105],["tuporno.tv",106],["verfutebol.tv",107],["vertelevision.tv",108],["vidcorn.tv",109],["vizer.tv",110],["wareztuga.tv",111],["tvperuana.us",112],["180.com.uy",113],["elobservador.com.uy",114],["elpais.com.uy",[115,116]],["ovaciondigital.com.uy",116],["ladiaria.com.uy",117],["lr21.com.uy",118],["ultimasnoticias.com.ve",119],["tabonitobrasil.video",120],["repelisplus.vip",121],["numero.wiki",122],["juegosypelis.ws",123],["revistasgratis.ws",124],["cuevana-3.wtf",125],["pelispedia-v2.wtf",126],["aztecapornohd.xxx",127],["hentaiporno.xxx",128],["morritastube.xxx",129],["pornolandia.xxx",130],["tupornogratis.xxx",131],["animesonehd.xyz",132],["clickhouse.xyz",133],["playnewserie.xyz",134]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
