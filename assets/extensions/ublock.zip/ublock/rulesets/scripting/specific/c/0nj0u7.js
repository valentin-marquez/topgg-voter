/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// bgr-0

const argsList = [{"a":"#banner_ad","n":["bg-ikonomika.com"]},{"a":"#adbody","n":["noshtuvki.burkan.info"]},{"a":"#newAd","n":["olx.bg","prodavalnik.com"]},{"a":"#Ads","n":["rbb.bg"]},{"a":"A[href*=\"mediamall.bg\"]"},{"a":"#ArticleLinkMediaMall,\n.box-right.cat-store,\nSPAN[style=\"text-decoration: underline;\"]"},{"a":".vip-firms"},{"a":"#aukcion,\n#rowAdv,\niframe[src=\"/app/j/banner.jsp\"]"},{"a":"#adwbanner300x250,\n.adwiseBlock"},{"a":"div[align=\"center\"]"},{"a":"#adv_zone_24,\n#adv_zone_26,\n#adv_zone_top"},{"a":"#banerdqsno,\n#bglink"},{"a":".banner_new"},{"a":".superbanner.text-center.hidden-xs"},{"a":"#ado-vbg-slave-3"},{"a":"#banner_a0_1,\n#banner_a0_2"},{"a":".banneritem"},{"a":"#sbox-overlay,\n#sbox-window,\n#wpfront-notification-bar,\n.code-block.code-block-12,\n.top_banner"},{"a":".banner"},{"a":".fc-dialog-container"},{"a":".col-lg-12.col-md-12.col-sm-12.col-xs-12"},{"a":".abw_message"},{"a":"[id^=\"banner\"]"},{"a":"MARQUEE,\nTD[style=\"text-align: center; border: 1px dashed rgb(24, 130, 237); box-shadow: 3px 3px 3px 3px rgba(0, 0, 0, 0.3); padding: 3px;\"]"},{"a":".banner-right,\ntable[width=\"220\"][bgcolor=\"#ffffff\"]"},{"a":".bann300x250"},{"a":"#offers"},{"a":"#BANNER,\ntd[style=\"border:1px solid #555555; width:340px; height:280px;\"],\ntd[valign=\"middle\"][align=\"center\"][style=\"border: 1px solid rgb(85, 85, 85); width: 340px; height: 280px;\"]"},{"a":"#bplay,\n#ips-ad,\n#setech,\n#single_ad,\n#your-ad,\n.custom-ad"},{"a":".adv"},{"a":".bannerWraper"},{"a":"#colorbox"},{"a":".imgNoBorder[style=\"float: left; background-color: lightgray; width: 300px; height: 250px; margin: 14px 0px 14px 8px\"]"},{"a":"#bannertop_72890,\n#red"},{"a":"#media_image-2,\n#media_image-3,\n#media_image-4,\n.widget-1.widget-odd.widget.widget_media_image,\n.widget-3.widget-odd.widget.widget_media_image,\n.widget-4.widget-even.widget-alt.widget.widget_media_image"},{"a":".ispace"},{"a":"#branding"},{"a":".bannerwrapper-200x200,\n.bannerwrapper-250x250,\n.bannerwrapper-728x90"},{"a":"#ad_lb_atf,\n#ban300x250,\n.paidAdvert"},{"a":".banner-box,\n.module.long-scroll,\n.smodule"},{"a":".easy_ads_main"},{"a":".copyright"},{"a":"iframe[style=\"border: medium none ; margin: 0pt; padding: 0pt; overflow: hidden; width: 300px; height: 250px; border-collapse: collapse;\"]"},{"a":".zaplata-footer-logo,\ndiv#adsblock-msg"},{"a":"#facebox_games_mess,\n#popup-ad"},{"a":"#adr_bot_240,\n#wallpaper_half_l,\n#wallpaper_half_r"},{"a":"#h_adv,\n.article-after-comments-ad,\n.article-after-text-ad,\n.article-before-donate-ads,\n.boxw100.advleft,\n.etarget_middle_after,\n.etarget_right_top,\n.h_adv.ad-elm,\n.health-ad-blk,\n.innewads,\n.inside-area-right-bottom-ad,\n.inside-area-right-middle-ad,\n.inside-area-right-top-ad.brc,\n.inside-news-area-right-ad,\n.r_b,\n.r_b_c.ad-elm,\n.top-news-area-ad,\n.top-news-area-ad.brc,\n.topfrog-ads-blk,\ndiv[style=\"padding-bottom:15px;\"]"},{"a":"#hotOffBg,\n#topBanCont,\n#topBanner,\n.adv.adwise,\n.shadow.block.offers,\nDIV[style=\"margin: 0 0 20px; height: 250px; width: 300px;\"]"},{"a":".hp-right-column"},{"a":".adwise"},{"a":"#pop"},{"a":"DIV[style=\"position:absolute; width:130px;left:-130px;height:900px;\"],\nDIV[style=\"position:absolute;width:120px;right:-120px;\"]"},{"a":"#divbh1.lfs-top-banner-holder"},{"a":"#GoogleAdSense,\n.nws-commercial-column"},{"a":".sponsor-logo,\n.ts-commercial-column,\n.ts-header-banner"},{"a":".td-header-rec-wrap"},{"a":"#MAX_a02e99f2,\ndiv[style=\"height:90px;\"]"},{"a":"#banners_position_2,\n#banners_position_3,\n#banners_position_4,\n#banners_position_5"},{"a":".LW-Home-Page-Banner-Top-Right"},{"a":".banner468_60,\nDIV[style=\"margin: auto; background-color: transparent; border-width: 0px; width: 300px; height: 250px;\"]"},{"a":"#header_banner"},{"a":"#gpt-banner-1-desktop"},{"a":"#main-billboard-spacer"},{"a":".banner_header_right,\n.etarget_container,\n.header_banner_container"},{"a":"#banner-234-90,\n#group-id-tids-12,\n#top_banner,\n.content-advertisement"},{"a":"#artbot,\n#artvert,\n#comm,\n#embed,\n#mplx,\n.artbot.center.mt20.mb20,\n.artvert,\n.assignshop,\n.embed.mt10.mb10,\n.g-comments.pt25.center.pt15.pb15,\n.giwrp,\n.rkl"},{"a":".mny-header-banner"},{"a":".grid__item.grid__item--w-100.plakat"},{"a":".square-banner.topmargin,\n.square-banner.topmargin.alignright"},{"a":".mom-e3lanat-inner"},{"a":".banners"},{"a":"#gpt-banner-4_ad_container"},{"a":"ins[style=\"width: 970px; height: 250px; display: block; position: relative; border: 0px none;\"],\nins[style=\"width: 970px; height: 250px; display: inline-table; position: relative; border: 0px none; vertical-align: bottom;\"]"},{"a":"#banner-top"},{"a":"#aax_if_aax_\\/26641721\\/novini\\.bg_branding_megaboard,\n.line_banner"},{"a":".banner640"},{"a":".ads-25,\n.ads-60-r"},{"a":"#topbar"},{"a":"#banner"},{"a":".bannerbox"},{"a":"#banner_right_bottom,\n#banner_right_middle,\n#banner_right_top,\n#fb_likeBox,\n.ads-caption,\n.left_brand,\n.right_brand,\n.top-banner.text-center"},{"a":"#banner_top"},{"a":"#brand"},{"a":"#mainscollertd"},{"a":"#flygrabo,\n#flyoffer_text,\n#leftbrand,\n#rightbrand"},{"a":".left-sidebar-banner.box,\ndiv[style=\"width: 728px; height: 90px; overflow: hidden;\"]"},{"a":"#bannersdesktop"},{"a":"#banner_right"},{"a":"#flash_big,\nDIV[style=\"width:670px; height:120px; left:0px; right:0px; margin-bottom:20px\"]"},{"a":"#banner_show"},{"a":"#adwbann_0,\n#adwbann_1,\n#booking-widget-slider,\n.astralBlock,\n.ecoHomeWeber"},{"a":"#baners_top"},{"a":"#block-panels-mini-leaderboard-banners"},{"a":".main-widget.google_adds.google_adds300x250"},{"a":"#bottom-s300,\n#top-s300"},{"a":".g300x600single"},{"a":".art-sidebar2"},{"a":"#banner1,\n#topBannerBlock,\n.adwise-right,\n.hot-offers-block"},{"a":".popup-back"},{"a":"#trendo_branding,\n.shop_box"},{"a":"#adv"},{"a":"#banner_2"},{"a":"#banner_3,\n.white_box.right_box.actual_offers"},{"a":".banneritem_text"},{"a":"#topbanner"},{"a":".phAddsText"},{"a":".ads"},{"a":"#banner_11,\n#banner_4,\n#banner_5,\n#banner_7,\n#spot-1,\n#spot-4,\n#spot-5,\n.ads_left,\n.border-left.w-100,\n.d-none.d-sm-none.d-md-none.d-lg-inline-block.col-lg-2,\n.hidden-xs.hidden-sm.arena_9.mb5,\n.hidden-xs.hidden-sm.arena_9.revive.mb5,\n.mb-2.mt-2.border,\n.mb-3.d-none.d-sm-block.border,\n.panel-footer.text-center.arena_10,\nIFRAME[src*=\"/banner/\"],\nIFRAME[src*=\"banner.htm\"],\niframe[src=\"about:blank\"]"},{"a":"#canvas"},{"a":".small-horoscopes2.clearfix"},{"a":"#bigbanner"},{"a":".RAD,\ntd[style=\"padding-bottom: 6px;\"]"},{"a":".sublineSearchBuffer-banner"},{"a":"DIV[style=\"height:100px !important; overflow:hidden; background:#8cc051 url(http://www.bulforums.com/source/public_html/images/bforums.jpg) no-repeat top left;\"]"},{"a":".right_banner.load-banner"},{"a":".wpb_single_image.wpb_content_element.vc_align_center"},{"a":"#aswift_0,\n#aswift_0_anchor,\n#aswift_0_expand,\n.banner-160x600_right.iframeBanner,\n.modal-link,\ndiv[style=\"font-family: Arial, Helvetica, sans-serif; font-size: 9px; text-transform: uppercase; color: rgb(128, 129, 143); background-color: rgba(255, 255, 255, 0.3); line-height: 10px; padding: 2px 4px; width: 98%; height: 8px;\"]"},{"a":".kare.top10"},{"a":"DIV[style=\"margin: 0px auto; min-height: 450px; width: 100%; padding-top: 500px; background-image: url('images/interface/kom_branding.png'); background-repeat: no-repeat; background-position: top center;\"]"},{"a":".etarget"},{"a":".custom-info-bgtop-backdrop,\nDIV[style=\"height: 220px;\"],\nDIV[style=\"min-height: 270px;width:960px;background-color: #F7F7F7;\"]"},{"a":"DIV[style=\"height: 265px;\"]"},{"a":".box-pink"},{"a":"#fanback"},{"a":"TABLE[style=\"border: 1px solid #000000; margin: 0; padding: 0;\"]"},{"a":"#banner2"},{"a":"td[class=\"left_fon\"]"},{"a":"#footer_inner_wrapper"},{"a":".ad.tac"},{"a":".banner1"},{"a":"#maxbannerads-3,\n#maxbannerads-4,\n#maxbannerads-5,\n#maxbannerads-6,\n.bannertop.clearfix"},{"a":".slidingBanners"},{"a":".sban"},{"a":"#advert_5,\n.adv-728-90.adv-block"},{"a":"#rightCol"},{"a":"#wdBanners"},{"a":".bigbanner,\n.verticalbanner"},{"a":"#tcvn-banner-slider215"},{"a":"#advert_id"},{"a":"#\\5f _dimScreen,\n#advm_preload,\n#pop_up_s"},{"a":"#left_banner_img,\n#right_banner"},{"a":"#banner_wrap,\n.users_wrap"},{"a":"#gkBannerTop"},{"a":".Footer,\nDIV[style=\"margin-bottom:10px\"]"},{"a":"#HTML2.widget.HTML"},{"a":"#news_ad,\n.container[style=\"height:105px\"]"},{"a":"#headerLineBgr,\n.col-sm-12.col-md-12.col-lg-12.video-cell"},{"a":".td-container.td-header-row.td-header-header"},{"a":"#bottomBanner,\n.zbranding_left2"},{"a":".banner_col,\n.banner_top"},{"a":".mod_bannerslider"},{"a":"DIV[style^=\"width:728px; height:90px;\"]"},{"a":"#text-4,\n.g1-row.g1-row-layout-page.g1-advertisement.g1-advertisement-before-content-theme-area"},{"a":"[style=\"width:728px;height:90px;\"]"},{"a":"#b300"},{"a":".advertisement"},{"a":".blogname"},{"a":".adv_box_kv_left,\n.adv_box_kv_right"},{"a":"div[style=\"padding-top:30px;padding-bottom:30px;\"]"},{"a":".ads_big_block,\n.ads_small_block"},{"a":"#login_popup"},{"a":"#site-cap-banner,\n.page_margin_top.box-with-shadow.wide-banner.wb-content,\n.placeholder.wide-banner.site-cap-banner,\n.sliding_banner_div,\n.widget.simple.square-banner,\n.widget.simple.square-banner.banner-zone-c"},{"a":".infor-before-content"},{"a":"IMG[style=\"width: 300px; height: 250px;\"]"},{"a":".poop2"},{"a":".e3lan-top"},{"a":".customContent"},{"a":"DIV[style=\"width: 462px; padding:3px; margin: 10px 0px 0px 0px; min-height: 60px; border: #dddddd solid 1px;\"],\nDIV[style=\"width: 466px; height:58px; overflow:hidden; border: #dddddd solid 1px;\"]"},{"a":"#header_img_right"},{"a":"DIV[style=\"width:728px; height:90px;\"],\n[style=\"width:300px;height:250px;\"],\n[style=\"width:300px;height:600px;\"]"},{"a":"#SC_TBlock_73002,\n#navpages"},{"a":"#right"},{"a":"IMG:first-child:last-child"},{"a":"#hot_offers"},{"a":"#text-26,\n#text-34,\n#text-35,\n#text-39,\n#text-40,\nDIV[style=\"width:630px; margin-bottom:10px; height:90px;   overflow:hidden;\"]"},{"a":"TABLE[height=\"253\"],\nTABLE[height=\"600\"]"},{"a":".bar_topadd,\n.topadd_bar,\n.topadd_barr"},{"a":"#rssnews,\n.clear[width=\"80\"]"},{"a":".iframe"},{"a":".boxPartBanner"},{"a":".leaderboard"},{"a":"#bannerTop"},{"a":"#aff-popup-banner"},{"a":"#widget_A"},{"a":"#kayan_reklam_sol,\n.squarebanner,\n.widebanner"}];

const hostnamesMap = new Map([["24chasa.bg",[4,5]],["trud.bg",4],["911.bg",6],["abv.bg",7],["as.adwise.bg",8],["afera.bg",9],["alo.bg",10],["autoclub.bg",11],["balkanec.bg",12],["banker.bg",13],["bgdnes.bg",14],["bgonair.bg",15],["bivol.bg",[16,17]],["smolyandnes.com",[16,142]],["blitz.bg",[18,19]],["dnevnik.bg",[18,38,39]],["topsport.ibox.bg",[18,54]],["mediapool.bg",[18,63]],["money.bg",[18,61,66]],["vnews.bg",18],["etapgroup.com",[18,70,118]],["briag.bg",20],["btv.bg",[21,22]],["btvnovinite.bg",21],["bukvi.bg",23],["business.bg",24],["capital.bg",25],["carmarket.bg",26],["conquiztador.bg",27],["crimes.bg",28],["cross.bg",[29,30]],["download.bg",29],["econ.bg",29],["burgasnews.com",[29,55,115]],["e-novinar.com",29],["dariknews.bg",31],["dartsnews.bg",32],["data.bg",33],["dev.bg",34],["dir.bg",35],["novini.dir.bg",35],["dnes.dir.bg",36],["dnesplus.bg",37],["media.easyads.bg",40],["forum.eshop.bg",41],["expert.bg",42],["fakti.bg",43],["framar.bg",44],["apteka.framar.bg",45],["frognews.bg",46],["gbg.bg",47],["get.bg",48],["gong.bg",49],["recepti.gotvach.bg",50],["homes.bg",51],["lifestyle.ibox.bg",52],["news.ibox.bg",53],["iskra.bg",55],["kamioni.bg",56],["knnews.bg",57],["legalworld.bg",58],["lex.bg",59],["lifehacker.bg",60],["lifestyle.bg",61],["news.bg",[61,70,71,72]],["mail.bg",62],["menumag.bg",64],["miau.bg",65],["monitor.bg",67],["nakratko.bg",68],["nbp.bg",69],["newshub.bg",73],["novini.bg",74],["novinite.bg",75],["offnews.bg",76],["krisfansait.ovo.bg",[77,78]],["kartelito.com",77],["myonvideo.com",77],["samokov365.com",[77,137]],["serialmaniq.com",[77,129,139]],["cinemabg.net",77],["club-bg.org",77],["data-bg.org",[77,182]],["submatrixs.ovo.bg",78],["recepty.bg",[78,88]],["prikachi.com",78],["pari.bg",79],["petel.bg",[80,81]],["programata.bg",[81,87]],["photo-forum.net",[81,168]],["pik.bg",82],["zajenata.bg",[82,99]],["plevenzapleven.bg",83],["plovdiv24.bg",84],["pozvanete.bg",85],["pravatami.bg",86],["remix.bg",89],["sinoptik.bg",90],["ticketpro.bg",91],["topnovini.bg",92],["sofia.topnovini.bg",92],["tribune.bg",93],["troll.bg",94],["try.bg",95],["versia.bg",96],["vesti.bg",97],["webcafe.bg",98],["subs.sab.bz",100],["actualno.com",[101,102]],["arenabg.com",[101,106,107]],["animes-bg.com",103],["antenneair.com",104],["bgnes.com",[104,110]],["apteka-optima.com",105],["kaksepishe.com",106],["cdn.arenabg.com",108],["bg-mamma.com",109],["bgrabotodatel.com",111],["bgrazpisanie.com",112],["bulforums.com",113],["burgasinfo.com",114],["djagi.com",116],["elmaz.com",117],["bg.static.etargetnet.com",119],["filmi7.com",120],["filmisub.com",121],["flash-igri.com",122],["gledaigo.com",123],["hardwarebg.com",124],["kik-info.com",125],["lesno-fakturirane.com",126],["managerteams.com",127],["nenovinite.com",[128,129]],["nessebar-news.com",130],["pirinsko.com",131],["plovdiv-sport.com",132],["podtepeto.com",133],["rechnik-bg.com",134],["rodopinews.com",135],["ruse-news.com",136],["segabg.com",138],["silabg.com",140],["sliven-news.com",141],["struma.com",143],["troyan21.com",144],["utroruse.com",145],["vbox7.com",146],["viaranews.com",147],["zavedenia.com",148],["zovnews.com",149],["advokatibg.eu",150],["4bg.info",151],["berbim.info",[152,153]],["politikata.net",[153,169]],["odit.info",154],["prnew.info",155],["subsmania.info",156],["bg-zone.net",157],["peter.and.bilyana.net",158],["ciela.net",159],["bgsimsonimz.forumotion.net",160],["haskovo.net",161],["informiran.net",162],["itforumbg.net",163],["kaminata.net",164],["lekuva.net",165],["mikrotik-bg.net",166],["moreto.net",167],["skandalno.net",170],["sedmica.sliven.net",171],["subsunacs.net",172],["svejo.net",173],["vchas.net",174],["vestnici.net",175],["yavka.net",176],["zamunda.net",[177,178]],["zdrave.net",179],["booksbg.org",180],["bourgas.org",181],["zoomania.org",183],["bg-gledai.tv",184]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
