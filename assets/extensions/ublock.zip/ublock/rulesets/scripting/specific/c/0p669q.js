/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// kor-1

const argsList = [{"a":".widget-box.widget-img"},{"a":"center > div[style*=\"margin:\"]"},{"a":"div[class^=\"style__GoogleAdSenseContainer-\"]"},{"a":".widget-side div[style*=\" \"]"},{"a":"#coupangAd,\n#hongboInfoList,\ndiv[class*=\"_outline\"]"},{"a":".shop_naver,\ndiv[id^=\"naverAd\"]"},{"a":".section_list.hongbo"},{"a":"#sidebar > .tab,\n.simple_banner_wrap,\nimg[src^=\"https://photo.coolenjoy.co.kr/banner/\"]"},{"a":"iframe[src^=\"//shop-redapi.daum.net/red-apigate/daumtop/\"]"},{"a":".aside_g.aside_ad,\n.aside_g.aside_shopping"},{"a":"div[data-tiara-layer=\"ad\"]"},{"a":".ggb-bnr"},{"a":".mtop_adfit,\ndiv[class][data-ad-media][data-ad-pubuser][data-ad-type][data-ad-width][data-ad-height]"},{"a":"#splinkColl,\n.adLinkColl,\n.content_sponsor,\niframe[src*=\"//ad.search.nate.com/\"]"},{"a":"body.nate .section_cont [disp-attr] > #specialMColl,\nbody.nate .section_cont [disp-attr] > div[style*=\"height:\"]"},{"a":"ul.list_column > li.item_ad"},{"a":".box_shopping,\ndiv[class^=\"advert_\"]"},{"a":".ddnad-board"},{"a":"#r_aside center > div[class=\"bn\"]"},{"a":"#content > div.bd > div.bd_lst_wrp > center,\n.content > div.bd > div.clear > div > center,\n.side > .widget_div > .content > center"},{"a":".wrapper > div[style*=\" \"]#container > div:not([class])"},{"a":"a[href^=\"http\"][target=\"_blank\"].thumbnail"},{"a":".sub-contents > .banner"},{"a":"#menufoot > .hot_under,\ndiv[id^=\"sidead\"],\ntable#mboard.mboard tr:not([id])"},{"a":"#menufoot .content div[class*=\"ad\"][style*=\"padding:\"],\ndiv[id^=\"div-\"][style*=\"min-height:\"]:not([class])"},{"a":"body > div[style^=\"min-height:\"]:not([class]):not([id])"},{"a":"div[class$=\"ad\"][id$=\"ad\"],\ndiv[style].content ~ div[class$=\"ad\"][style*=\"min-height:\"]"},{"a":"#serContents div[align=\"left\"],\ndiv[class$=\"_adban\"],\ndiv[class*=\" \"] > div[class*=\" \"][class*=\"_\"] ~ div[class$=\"fright\"],\ndiv[class*=\"mall_\"][style*=\" \"][class*=\"_slider_\"],\ntd[width]:not([valign]) ~ td[align=\"left\"] ul.banner"},{"a":".ads + div:not([class]),\n.pop-layer,\ndiv[class] > div[class^=\"post-style\"] ~ .rn_block,\ndiv[class] > div[class^=\"post-style\"] ~ .rn_block + hr"},{"a":"aside > .obituaries-wrapper.recent_news_inner"},{"a":".xe_content span ~ div[style]"},{"a":".board-tail-banner,\n[style=\"margin-bottom: 20px;\"].row.row-15"},{"a":".sidebar_book"},{"a":".feed-list-wrap .feed-item-wrap-SPONSORED"},{"a":".gdl-left-sidebar"},{"a":"#sidebartop,\n.entry-content > div[id^=\"top\"]"},{"a":".sidebar[style] > aside[id^=\"text-\"][class] ~ aside[id^=\"text-\"][class]"},{"a":"nav ~ .at-title"},{"a":"div[class$=\"_ban\"],\ndiv[class*=\"_ban_\"]"},{"a":"#wrap_right > #right"},{"a":"div[class^=\"Ad\"],\nheader .dis-table > div[style^=\"padding-top:\"].dis-table-cell"},{"a":"[id*=\"Ad\"],\ntable[align] table[align] td[valign] table[cellspacing] tr > td[colspan][height][bgcolor]"},{"a":"#TopAddFrame,\n.row > div[class][id=\"\"] ~ #Contents ~ a[href*=\"?Board=enterprise\"],\n.row > div[class][id=\"\"] ~ #Contents ~ a[href*=\"Board=enterprise\"] + div[class],\n.row > div[class][id=\"\"] ~ #Contents ~ div[style],\n.row > div[style=\"\"].col-xs-12 ~ div[id] + div[style]"},{"a":"div[class*=\"ad-\"]"},{"a":".custom_code.board_top,\ndiv[id^=\"plusad_\"]"},{"a":".sub-contener-wraper > div:not(.sub-cont)"},{"a":"div[id*=\"banner\"]"},{"a":"iframe[src*=\"//arca.live/external/callad\"],\niframe[src*=\"//arca.live/static/ad/\"]"},{"a":"a[href^=\"/ad-\"]"}];

const hostnamesMap = new Map([["avjamak.net",0],["m.betanews.net",1],["blackkiwi.net",2],["bozayo.net",3],["clien.net",4],["m.clien.net",5],["www.clien.net",6],["coolenjoy.net",7],["daum.net",8],["entertain.daum.net",9],["focus.daum.net",10],["pubg.game.daum.net",11],["m.daum.net",12],["search.daum.net",13],["m.search.daum.net",14],["news.v.daum.net",15],["www.daum.net",16],["dogdrip.net",17],["esuwon.net",18],["ggoorr.net",19],["hellot.net",20],["hellven.net",21],["hodu287.net",22],["hodu288.net",22],["hodu289.net",22],["hodu290.net",22],["hodu291.net",22],["hodu292.net",22],["hodu293.net",22],["hodu294.net",22],["hodu295.net",22],["hodu296.net",22],["hodu297.net",22],["hodu298.net",22],["instiz.net",23],["m.instiz.net",[24,25]],["www.instiz.net",[24,26]],["kidkids.net",27],["koreatimes.net",28],["www.koreatimes.net",29],["lover903.net",30],["lover904.net",30],["lover905.net",30],["lover906.net",30],["lover907.net",30],["lover908.net",30],["lover909.net",30],["lover910.net",30],["lover911.net",30],["lover912.net",30],["manatoki215.net",31],["manatoki216.net",31],["manatoki217.net",31],["manatoki218.net",31],["manatoki219.net",31],["manatoki220.net",31],["manatoki221.net",31],["manatoki222.net",31],["manatoki223.net",31],["manatoki224.net",31],["manatoki225.net",31],["manatoki226.net",31],["manatoki227.net",31],["mathbang.net",32],["minimap.net",33],["miraetv.net",34],["mongri.net",35],["moviepang.net",36],["ohli24.net",37],["popco.net",38],["tailstar.net",39],["topstarnews.net",40],["ibric.org",41],["m.ibric.org",42],["lol.ps",43],["1412.rest",44],["todawa100.top",45],["todawa101.top",45],["todawa102.top",45],["todawa103.top",45],["todawa104.top",45],["todawa105.top",45],["todawa106.top",45],["todawa107.top",45],["todawa108.top",45],["todawa99.top",45],["etorrent.us",46],["namu.wiki",47],["bobaelink38.xyz",48],["bobaelink39.xyz",48],["bobaelink40.xyz",48],["bobaelink41.xyz",48],["bobaelink42.xyz",48],["bobaelink43.xyz",48],["bobaelink44.xyz",48],["bobaelink45.xyz",48],["bobaelink46.xyz",48],["bobaelink47.xyz",48],["bobaelink48.xyz",48],["bobaelink49.xyz",48]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
