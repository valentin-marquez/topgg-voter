/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// swe-1

const argsList = [{"a":"a.td_single_image_bg"},{"a":"div[data-block=\"CookieBannerBlock\"]"},{"a":"#black-studio-tinymce-3,.menu-item a[target=\"_blank\"]"},{"a":"#topbanner,#mittbanner,#topbannerm,#mittbannerm"},{"a":"#videoad"},{"a":"#cookie-button-banner,.campaigns,[id*=\"GlobalCampaigns\"]"},{"a":".masthead,.col-right,a[href^=\"https://goo.gl/\"],a[href*=\"//bit.ly/\"],a[target=\"_blank\"][onclick],#ap1"},{"a":".right-sidebar aside[id^=\"block\"],.right-sidebar aside[id^=\"adguru\"]"},{"a":".sidebar"},{"a":"#modal-container"},{"a":".ss-modal,.modal-mobile-app"},{"a":".polopolyNotification"},{"a":".block-rr"},{"a":".sidebar-right,.ad_header + p"},{"a":".banner-container"},{"a":".mh-sidebar .textwidget"},{"a":"#text-4"},{"a":".header_top,#media_image-2,#text-6,\na[href*=\"/annonsering\"]"},{"a":"#text-html-widget-3"},{"a":".pnlAdTop"},{"a":".banner-right,.banner-left,.wpb_single_image a[target=\"_blank\"],.tdm-popup-modal-wrap"},{"a":"[class*=\"jsx-\"][style*=\"position: sticky\"],.bc--grey-neutral-50[style^=\"min-height\"]"},{"a":".premium-page-ad,.footer-banner-wrapper,div[id^=\"stopp-\"]"},{"a":"div[class*=\"-promo\"],div[class*=\"prisjakt-\"]"},{"a":"#mega-ad-wrapper,.Container--ad,.theme-Native,.AdWrapper,.AdPositionData,.Teaser--fullAdLabel,div[data-engage-entity-id=\"sales-banner-bottom-sticker-wide\"]"},{"a":"#eprivacyModal,.modal-backdrop"},{"a":".widget_et_ads,.module-etads,#text-13,#block-4,a[target=\"_blank\"][rel=\"noopener noreferrer\"],a > img[width=\"300\"][height=\"250\"],a > img[width=\"800\"][height=\"175\"],a[href*=\"casino\"],a[href*=\"poker\"]"},{"a":"[data-ad-id]"},{"a":"#bannercolumn,img[title^=\"Annons\"]"},{"a":"#cookie-box"},{"a":".cd-desktop-banner"},{"a":"div[id$=\"_ad\"],div[id$=\"_ad_mobile\"],.externalTopMobile,a[href^=\"//www.prisjakt.nu/produkt\"],#nativendo-mainfeed + aside > .article,.article-footer > h3,.article-footer > .aeChart,.newExternal"},{"a":"[class*=\"-reklam\"],.sif-sponsorer,.teaserblock,.commonblock a:not([href^=\"/\"],[href*=\"/swehockey.se\"])"},{"a":".abann_wrapper,#hspalt_s1"},{"a":".create-account-banner,.buy-premium-banner,div[class*=\"pb-\"] > div.text-center"},{"a":".adscolumn"},{"a":"section[id^=\"Panorama\"]"},{"a":"[class^=\"ad-container\"],[class^=\"adbox-single\"]"},{"a":".code-block,main > div:last-child:not(:only-child),#uid_08313ba73,#uid_ab3738b5a,.jeg_header_wrapper .jeg_midbar"},{"a":".page-gutter.left,.page-gutter.right,[id^=\"bbPrisjakt\"]"},{"a":".row-uppdragstest"},{"a":".ad-container-section,.article-sponsored"},{"a":"a.td_single_image_bg:not([href*=\"thepattayanews.se\"])"},{"a":".sidebar .widget_widget_code"},{"a":"div[style*=\"z-index: 999; background-color: rgba(0, 0, 0, 0.5)\"],.bg-grey.hideOnPrint,.bg-adYellow"},{"a":".elementor-image a[target=\"_blank\"],.revive-box"},{"a":".subscribe_now_popup,.type-native,#captive"},{"a":"div[data-ai]"},{"a":".adv"},{"a":"div.tot-content-preview-container-small[style*=\"border-top:4px solid #ffb200;\"],.content-overlay--black,a[href*=\"casino\"],a[href*=\"/sponsrat/\"],a[href*=\"/sponsrat/\"] + p.tot-content-preview--meta,.newaddiv"},{"a":"[id^=\"bunyad\"]"},{"a":".bottom-bar--animate-in,#job_ads_scroller,.header_banner,.newsletter-popup"},{"a":"a[href*=\"/sponsrat/\"],\nmain > div > div > div > div > div:has(.adunitContainer)"},{"a":"[class$=\"banner_ad\"]"},{"a":".site-wrap > .row > .col-sm-3"},{"a":"#col_right"},{"a":".visit-advertiser-link"},{"a":".privacy-information--visible"},{"a":".backdrop,.fcb"},{"a":"div[id^=\"ungdo-\"]"},{"a":".type-partnerartikel"},{"a":"#banner-top-block"},{"a":".results li[style^=\"margin\"]:not(.result)"},{"a":".latest-article-native"},{"a":"app-native-puff,.header-top-banners"},{"a":".profile-annons"},{"a":"[id*=\"annons\"],#getFixed"},{"a":".campaign-teaser-show"},{"a":".newsletter-popup--background-fade,.newsletter-popup,.c-cookie-banner"},{"a":".wpb_single_image a[target],.gp-footer-2"},{"a":"article[data-section=\"nativeannons\"]"},{"a":"a[href^=\"/mainbanner\"]"},{"a":"[class*=\"ai-viewport\"],.full_screen_ad"},{"a":".nyhet-ad"},{"a":".cookieNotification"},{"a":"a[href^=\"/partnermaterial/\"]"},{"a":".body-overlay,.article-native-scroll"},{"a":".Internal-ad"},{"a":".mtsnb,.villalivet-target,a[href*=\"/sponsrat-innehall/\"],div[data-td-block-uid=\"tdi_85\"],a[href*=\"utm_campaign\"][target=\"_blank\"]"},{"a":".annonsinlagg,.annonsen"},{"a":".push-to-newsletter,.fancybox-overlay,\n.top-add,.sidebar-adds,.spons-content"},{"a":".product_banner_wrapper"},{"a":".popup_missa-inget"},{"a":".topheaderinfo"},{"a":"a[href*=\"/go/\"][target],.category-kampanjer"},{"a":"a[href*=\"campaign\"][data-test-tag=\"external-link\"],div[data-ad-subtype]"},{"a":".gpt-slot,.newsletter"},{"a":"div[class^=\"CookieBar\"]"},{"a":".LFRBox"},{"a":".js-cookie-iframe"},{"a":".yweb-news-paper-banner"},{"a":".featured"},{"a":"div[style^=\"position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; z-index: 999;\"]"}];

const hostnamesMap = new Map([["sjostadsbladet.se",0],["skandia.se",1],["skanesport.se",2],["skargarden.se",3],["skidspar.se",4],["skk.se",5],["skogsforum.se",6],["skolfamiljen.se",7],["skyltat.se",8],["skyscanner.se",9],["smartsenior.se",10],["smhi.se",11],["so-rummet.se",12],["spelagratis.se",13],["spelo.se",14],["spelochfilm.se",15],["sportbilen.se",16],["sporthalsa.se",17],["sportpanelen.se",18],["stallet.se",19],["startaochdriva.se",20],["stegforhalsa.se",21],["stoppapressarna.se",22],["surfa.se",23],["svd.se",24],["svenskahousegruppen.se",25],["svenskhistoria.se",26],["svensktgolfforum.se",27],["svensktidskrift.se",28],["sverigeskonsumenter.se",29],["sverigespringer.se",30],["swedroid.se",31],["swehockey.se",32],["sydnarkenytt.se",33],["synonymer.se",34],["sysidan.se",35],["tabyallehanda.se",36],["tandlakartidningen.se",37],["tekniksmart.se",38],["99.teknikveckan.se",39],["testfakta.se",40],["thelocal.se",41],["thepattayanews.se",42],["tidningen.se",43],["tidningenbalans.se",44],["tidningenglobal.se",45],["tidningenridsport.se",46],["tina.se",47],["tittapavideon.se",48],["totallyorebro.se",49],["totallystockholm.se",49],["traning40plus.se",50],["travelnews.se",51],["travronden.se",52],["tripadvisor.se",53],["turismnytt.se",54],["turistmal.se",55],["tv4play.se",56],["tvkanalengodare.se",57],["tvprogram.se",58],["ungdomsfotboll.se",59],["upphandling24.se",60],["uppsalanyheter.se",61],["uppsatser.se",62],["vagabond.se",63],["varden.se",64],["varldenidag.se",65],["varldenshaftigaste.se",66],["varldenshistoria.se",67],["vartgoteborg.se",68],["varvat.se",69],["vasterastidning.se",70],["vaxjolakers.se",71],["vegomagasinet.se",72],["veterinarmagazinet.se",73],["vi.se",74],["vibilagare.se",75],["viivilla.se",76],["vilaser.se",77],["villalivet.se",78],["vimedbarn.se",79],["vinbanken.se",80],["vinliv.se",81],["vinochmatguiden.se",82],["viseniorer.se",83],["vm-fotboll.se",84],["wellness.se",85],["welma.se",86],["xlbygg.se",87],["xn--lnforum-exa.se",88],["yelp.se",89],["ysektionen.se",90],["omtanke.today",91],["kolla.tv",92]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
