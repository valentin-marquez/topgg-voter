/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// ltu-0

const argsList = [{"a":"#tv300x600_1d_tv3\\.lt *,\n#tv980x200_tv3_lt,\n#tv980x200_tv3_lt *,\n.custom-stick-div,\n.imMobile,\n[id^=\"tv300x250\"],\n[onclick=\"ga('send', 'event', 'Anonsai', 'Click', 'Svarbiausia blokelio paspaudimas');\"] *,\na[href*=\"goo.gl/\"]"},{"a":".custom-div"},{"a":"#ad_banner_skin,\n.c-details__leaderboard-ad,\niframe[style=\"border: 0px none transparent; width: 1440px; height: 750px; overflow: hidden;\"],\nspan[id*=\"_ad_container\"]"},{"a":"#adblocker"},{"a":"#area1.home-banner,\n#area2.home-banner"},{"a":"#billboardwrapper,\n#table-rightbanner1,\n#table-rightbanner3.rightbanner_info,\n.module_right_content_col,\n.topbanner_info [data^=\"http://www.vaistai.lt/images/banners/\"]"},{"a":".col-md-12.col-sm-6.col-xs-12.nopaddingright.nopaddingright-small.nopaddingleft-xs.padding-left-sidebar-small"},{"a":".banner-1"},{"a":".popup_overlay"},{"a":"#block-adaboveheader,\n.layout__region--ad"},{"a":".ad120_box,\n.ad468_frame_bot,\n.widget3"},{"a":".otRounded.module-other-website-banner *"},{"a":"#page-ads,\n#sidebar-madmen"},{"a":".moduletabledesinen"},{"a":".adv_b"},{"a":".links"},{"a":".content_banners"},{"a":"a[rel=\"nofollow\"] + * + * + * > img"},{"a":".fluid-width-video-wrapper"},{"a":".bannerbox,\n.cvWr.row.hidden-xxs,\n.cvWrSidebar,\n[onclick=\"window.open('http://www.cv.lt','_blank')\"]"},{"a":"#bottom-banners,\n.remejulogo"},{"a":"#rightcol"},{"a":"a[href*=\"http://www\"] > img"},{"a":"CENTER > A > *,\na[alt=\"Prezi.lt\"] + CENTER"},{"a":"img[alt=\"Informacija ir pagalba telefonu 1588\"]"},{"a":"div[style=\"width: 80%; font-size: 12px; padding: 5px; border: 1px dashed #CCF5CC; background: #F0FCF0; margin: 0 auto;\"]"},{"a":"#k980x200_krepsinis_net > *,\na[href^=\"https://goo.gl/\"],\ndiv[style=\"width:100%; top:44px; left:0; height:100vh; background-repeat:no-repeat;  position:fixed; background-position:50% 0px; background-image:url(https://www.tv3.lt/Uploads/wp_danai.jpg);\"]"},{"a":".home.blog .homeslider.rotator,\n.rightbar *"},{"a":"img[alt=\"www.linda-seeds.com\"]"},{"a":"a[href=\"http://sportouzdarbis.com/\"] > *"},{"a":"#wdBannerImg"},{"a":".side-body > TABLE[bgcolor=\"#87B6D9\"]"},{"a":"#block-block-7 P,\n#sidebar-right"},{"a":".adsb"},{"a":"a[target=\"titul\"] > img"},{"a":"a[href^=\"/redirect/ad/\"] > *"},{"a":".hometakeover.gofollow"},{"a":"a[href=\"http://www.filmux.us\"]"}];

const hostnamesMap = new Map([["tv3.lt",[0,1]],["krepsinis.net",[1,26]],["play.tv3.lt",2],["powerhitradio.tv3.lt",3],["vaikutis.lt",4],["vaistai.lt",5],["valstietis.lt",6],["vandensparkas.lt",7],["varle.lt",8],["ve.lt",9],["veidas.lt",10],["vela.lt",11],["versliukai.lt",12],["verslosavaite.lt",13],["vilniausskelbimai.lt",14],["vilniauszinios.lt",15],["visalietuva.lt",16],["voruta.lt",17],["naujienos.vu.lt",18],["vz.lt",19],["zalgiris.lt",20],["zappy.lt",21],["zindyk.lt",22],["zooplius.lt",23],["zurnalai.lt",24],["danielius.net",25],["kulturizmas.net",27],["legalus.net",28],["linksmiau.net",29],["lietuvis.no",30],["drauge.org",31],["pradzia.org",32],["vardai.org",33],["internetine-tv.narod.ru",34],["anglija.today",35],["ekspresas.co.uk",36],["lttv.us",37]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
