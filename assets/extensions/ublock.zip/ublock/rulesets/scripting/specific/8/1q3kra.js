/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// idn-0

const argsList = [{"a":".nyaa300,\n.nyaa728"},{"a":".adsbygoogle"},{"a":".sidebar > .klan300"},{"a":"#ads"},{"a":".bausastra-ads"},{"a":".affcoups"},{"a":".inf_infusionsoft_popup"},{"a":"div.ui_adblock"},{"a":"#TopBannerBg"},{"a":".bnr"},{"a":".banner-sc,\n.banner-sc2,\n.col-banner,\n.masonry-brick.drm-banner-x.drm-artikel:nth-of-type(3)"},{"a":".header__kasad,\n.kasad-h"},{"a":"#adsoutsream,\n.heightads250"},{"a":"#fixslowshow"},{"a":"#dablewidget_RoOGdzom,\n#div-Skycrapper-Stocksetup,\n.heightads600.pad-t.pad-r.pad-l.pad-10,\n.heightads90.ads-middle-list-news,\n.text-center.center.width-px-1100"},{"a":"#Kolom-random-300,\n#iklan-dalam-postingan-300,\n#overlay[style=\"display: block;\"],\nimg[style=\"border:0;display:block;\"]"},{"a":"#top-banner-parallax,\n.banner-parallax"},{"a":".adsense"},{"a":".ads-160,\n.ads-160-600,\n.ads-300-video,\n.set-ads-468,\na[style=\"width: 100%; height: 100%; display: block; position: fixed; z-index: 1\"]"},{"a":"#otp_ads,\n.portlet.sideskycrapper"},{"a":"#bottomframe-ad,\n#skinframe-ad-left"},{"a":".ad-inventory-wrapper"},{"a":"a[href^=\"http://www.apktiga.com/p/start-download-reayus.html\"]"},{"a":"#detailSkinAdLeft,\n#detailSkinAdRight"},{"a":".ads-mr,\n.ads__skyscraper,\n.ads_sky,\n.clearfix.ads__horizontal"},{"a":".mt20.top1,\ndiv.banner-r"},{"a":"#div-top-banner-transparent"},{"a":".ads_sticky_footer"},{"a":".ads-sticky-left,\n.ads-sticky-right,\n.bg-grey.text-center.p-0.mb-3.mt-3,\n.mb-4.bg-grey.text-center"},{"a":".ad-box-wrappr,\n.row > .show-desktop > div,\n.underlay-ad-text-box"},{"a":".nkt__stick"},{"a":"#main-banner-middle,\n.legend_banner-container,\n.stickybanner"},{"a":".gambar_pemanis"},{"a":".ftadss"},{"a":".parallax_ads,\n.widebanner.banner,\ndiv.showcase.banner,\ndiv.skycrapper.banner"},{"a":".cls.code-block-center"},{"a":".banner-skin--left,\n.banner-skin--right,\n.banner__giant.banner,\n.banner__left.banner,\n.banner__right.banner,\n.banner__top.banner"},{"a":".ads-popup__inner"},{"a":".ads.single_post_content,\n.animated.ads"},{"a":".adbox"},{"a":".skinner-left,\n.skinner-right"},{"a":".box-ads-300x250"},{"a":".text-align-center.box-ads-content"},{"a":".in_up_ad-area"},{"a":".cads"},{"a":"#ilang2"},{"a":".modal"},{"a":".box-banner"},{"a":"#floating_ads_bottom_textcss2"},{"a":".wait"},{"a":"[href=\"javascript:showHideGB()\"],\n[href^=\"http://dwatngkas.\"],\na[href^=\"http://cocobet.\"]"},{"a":"#ilang1"},{"a":".adv"},{"a":".bannersinglefot"},{"a":"#googlebox"},{"a":"#floatbtmleft,\na[href^=\"//angel4d.com/\"],\na[href^=\"//telolet4d.com/\"]"},{"a":".iklanSUKI"},{"a":".slot-iklan"},{"a":".float_tengah,\n.separator"},{"a":"#iklanFloat,\n.iklan,\n.modal-backdrop"},{"a":".lenyap"},{"a":".ad-float-image"},{"a":".rsABlock"},{"a":"a[href=\"https://klik.fun/Kp7S5\"]"},{"a":".col-xs-12.col-md-6.col-lg-6"},{"a":"#previewBox"},{"a":".wpb-outer-wrap"},{"a":".bot.ads"},{"a":"#float-pop"},{"a":"#overlay-pop"},{"a":"#fancybox-overlay"},{"a":"[href=\"http://bit.ly/adsvbola\"],\n[id^=\"yui-gen\"].postcontainer"},{"a":".bm.overlay"},{"a":"a.bnner"},{"a":".top-bnner.lazy"},{"a":"[href=\"https://144.126.241.203/invite/c6c83up\"],\n[href=\"https://bit.ly/anoboySG88\"],\n[href=\"https://kliksaya.info/mcdanoboy\"]"},{"a":".adbtm,\n.bh-ad,\n.block-bh-googledfp,\n.center-block.img-responsive"},{"a":".cari-ads"},{"a":".td-banner-bg.td-banner-wrap-full"},{"a":"#Taboola_widget,\n#rec_ad4,\n.tonal__standfirst"},{"a":".code-block-6,\ndiv[data-ub-carousel]"},{"a":"#sadl,\n#sadr"},{"a":".ktz_banner"},{"a":"#sct_banner_top,\n#videoad1"},{"a":".ads-header-5"},{"a":".placeholder-container:has(.ads-container)"},{"a":"img.aligncenter"},{"a":"#fixedban"},{"a":".cfmonitor"},{"a":"#banner-popup-desktop"},{"a":".idmupi-topbanner"},{"a":"#banner-right"},{"a":".clearfix.act2-970x90:nth-of-type(1),\n.clearfix.act2-970x90:nth-of-type(3)"},{"a":"img[width=\"1020\"][height=\"350\"]"},{"a":"#jsemrp_372_719,\n#jsemrp_373_873,\n#jsemrp_374_469,\n#jsemrp_380_290"},{"a":".coliklan"},{"a":".cm-popup-modal"},{"a":".banner3"},{"a":".blox"},{"a":"#floatads2,\n#floatads3"},{"a":".anuads"},{"a":"a[title^=\"manga4d\"]"},{"a":"#openpopunder"},{"a":".mvic-btn"},{"a":".sidebarborder:nth-of-type(4),\n.sidebarborder:nth-of-type(5)"},{"a":"a[href^=\"//bit.ly/\"]"},{"a":"#videoOverAd"},{"a":"#tutup,\n#tutup2"},{"a":"#lmd-iklan"},{"a":".swal-overlay--show-modal.swal-overlay"},{"a":"#popuppress-9119,\n#top-banner-content"},{"a":"#main-popup"},{"a":".banner-middle"},{"a":"[class*=\"banner\"]"},{"a":".teaser3"},{"a":"a[target=\"_blank\"][rel^=\"noopener noreferrer\"] > img[src$=\".gif\"]"},{"a":".kzl-header.kzl"},{"a":".iklan-tengah"},{"a":"[href$=\"/referral/nontoncinema\"],\na[href^=\"http://referral.\"]"},{"a":".box_banner"},{"a":"[href=\"//dumbpop.com/help.xml\"]"},{"a":"#largebanner"},{"a":"table"},{"a":"#ffbp-bg,\n#ffbp-body,\n#ffbp-close"},{"a":"[href^=\"http://linkalternatif.\"],\n[href^=\"https://tinyurl.com/\"]"},{"a":".setdah"},{"a":"a[rel^=\"nofollow noopener\"] > img[src$=\".gif\"]"},{"a":"#ffbp,\n#popup"},{"a":".add,\n.mobi.content-left,\n.mobi.content-right"},{"a":"#floatbottom"},{"a":".adsrow"},{"a":"#epmblock,\ndiv:nth-of-type(2) > div > .btn-block.btn-lg.btn-success.btn"},{"a":".hidden-xs"},{"a":".page > div:nth-of-type(4) > div:nth-of-type(1),\ndiv:nth-of-type(4) > div:nth-of-type(2)"},{"a":".av-content-full,\n.glx-link,\n.glx-teaser"},{"a":"[href=\"http://sbovn88.net/\"]"},{"a":".adsincenter"},{"a":"#ftadsth"},{"a":"#player-side-left,\n[href=\"https://indoxplay.com/promosi/slots\"]"},{"a":"#home-bnner-content"},{"a":"#home-bnner2-content,\n.reklam-goster-sag,\n.reklam-goster-sol"},{"a":"#directorio > .random > center"},{"a":"#sidebar_right > .side:nth-of-type(5) > .textwidget,\n#sidebar_right > .side:nth-of-type(6) > .textwidget,\n#sidebar_right > .side:nth-of-type(7) > .textwidget,\n#sidebar_right > .side:nth-of-type(8) > .textwidget,\n#sidebar_right > .side:nth-of-type(9) > .textwidget"},{"a":".bannerwrap"},{"a":"#previewBox1"},{"a":"#top-bnner-content"},{"a":".ads-big,\n.ads-foot,\n.ads-right2,\n.container_skinad"},{"a":".fancybox-skin"},{"a":".navbar-brand.bot,\ndiv[id^=\"previewBox\"]"},{"a":".ads728-slot-panjang"},{"a":".banner-premium"},{"a":"[class=\"sc__wrp\"]"},{"a":"[href^=\"http://enakbet.link/\"]"},{"a":".tutup.banner"},{"a":"#content > div:nth-of-type(1)"},{"a":"#sgpb-popup-dialog-main-div-wrapper,\n.sg-popup-builder-content"}];

const hostnamesMap = new Map([["animeindo.id",0],["apkmod.id",1],["radarlombok.co.id",1],["novelgo.id",1],["paraedu.id",1],["hightech.web.id",[1,49]],["nama.web.id",1],["batch.id",2],["budiarto.id",[3,4]],["cinemaindo.web.id",[3,45,46]],["filmapik.tv",3],["ceklist.id",5],["alona.co.id",6],["cerpen.co.id",7],["chip.co.id",8],["cosmogirl.co.id",9],["anime17.net",[9,82]],["dream.co.id",10],["kaskus.co.id",11],["kontan.co.id",12],["pusatdata.kontan.co.id",13],["stocksetup.kontan.co.id",14],["lihat.co.id",15],["orami.co.id",16],["pontianakpost.co.id",17],["republika.co.id",18],["viva.co.id",19],["log.viva.co.id",20],["wartaekonomi.co.id",21],["filmterbaru.id",22],["ggwp.id",23],["grid.id",24],["nextren.grid.id",25],["www.grid.id",26],["inews.id",27],["www.inibaru.id",28],["investor.id",29],["jurnalisindonesia.id",30],["kabargames.id",31],["komikindo.id",32],["manganime.id",33],["medcom.id",34],["onlinemetro.id",35],["www.sonora.id",36],["tek.id",37],["terasjakarta.id",38],["terkini.id",39],["tirto.id",40],["uzone.id",41],["internetpositif.uzone.id",42],["animeindo.web.id",43],["animeindo.video",43],["animekompi.web.id",44],["sinemaindo.web.id",[45,55]],["filmbagus21.info",46],["eka.web.id",47],["ganool.web.id",48],["kazefuri.web.id",50],["lk21.web.id",51],["mangaku.web.id",52],["mangaku.in",52],["mangaku.site",[52,137]],["nontonmovie.web.id",53],["videocrot.org",53],["resep.web.id",54],["suki48.web.id",56],["zigi.id",57],["manganime.in",58],["nanimex.in",59],["b201.info",60],["senimovie.info",[61,62]],["senimovies.net",61],["westmanga.info",63],["ganool.is",64],["ganool.ph",64],["ganool.se",[64,131]],["ganool.st",64],["lk21.li",65],["nonton21.tv",65],["nontonlk21.live",66],["bioskop99.me",67],["dunia21.me",[68,69]],["dunia21.net",69],["dunia21.org",69],["dunia21.wtf",69],["idfl.me",[70,71]],["r-l.me",70],["idtube.me",[72,73]],["idxx1.top",[73,138]],["xx1.me",74],["anoboy.media",75],["bharian.com.my",76],["mforum.cari.com.my",77],["hijabista.com.my",78],["majalahpama.my",78],["nona.my",78],["vanillakismis.my",78],["utusan.com.my",79],["rasa.my",80],["youtube-mp3.my",81],["animeindo.net",83],["awnime.net",84],["briliofood.net",85],["cinema-indo.net",86],["drakorindofilms.net",87],["dramaqu.net",88],["duniaku.net",89],["filmace21.net",90],["filmbagus88.net",91],["filmku.net",92],["funtasticko.net",93],["harakahdaily.net",94],["indoxxi.net",95],["inidramaku.net",96],["juragan-anime.net",97],["kazefuri.net",98],["komiku.net",99],["kurazone.net",100],["mangakita.net",101],["mangashiro.net",102],["nobarfilm21.net",103],["nontonganool.net",104],["seri168.net",105],["torjack.net",106],["tvkabel.net",107],["animasu.nl",108],["dutafilm.observer",109],["layarxxi.online",110],["dewabioskop21.org",[111,112]],["dwa21.org",[111,113]],["film21terbaru.org",114],["gatsunime.org",115],["kumpulmanga.org",116],["nanimex.org",117],["nontoncinema.org",118],["otakuindo.org",119],["pakbos21.org",120],["pkspiyungan.org",121],["satujiwa.org",122],["indoxxi.pictures",123],["bioskop168.pro",124],["komikindo.pro",125],["otakudesu.pro",126],["indoxx1.pw",127],["file.rocks",128],["samehadaku.run",[129,130]],["samehadaku.win",130],["cmovieshd.se",[131,132]],["hdfree.se",133],["myasiantv.se",134],["filmbokep21.shop",135],["ganol.si",136],["mangaku.vip",137],["indoxxi.top",[139,140]],["indoxxi.tv",[139,145]],["bioskopmovie.tv",141],["cinemaindo.tv",142],["elde.tv",143],["fb21.tv",144],["xx1.tv",145],["kompas.tv",146],["layarkaca21.tv",147],["lk21.tv",147],["ns21.tv",148],["ns21.us",148],["drakorasia.us",149],["dewanonton.vip",150],["kurina.vip",151],["otakudesu.watch",152],["goblintv.xyz",153],["indostreamings.xyz",154],["kazemanga.xyz",155]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
