/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// spa-0

const argsList = [{"a":"#ccr-sidebar-add-place"},{"a":"div[style=\"float:none;margin:10px 0 10px 0;text-align:center;\"]"},{"a":"a[href=\"http://castillafloristeria.com/\"],\na[href=\"http://electrosanzhermanos.com/\"]"},{"a":".adpv:has(> .adsbygoogle),\n.posts:has(> div > div > .adsbygoogle),\n[alt^=\"Tienda\"],\nimg[src=\"http://static.tumblr.com/omgciym/0iNnhnzq2/neopeseta.png\"],\nimg[src=\"http://static.tumblr.com/omgciym/0tvmih3p3/memetienda.jpg\"],\nimg[src=\"http://static.tumblr.com/omgciym/2bBmgb175/juegacos.jpg\"],\nimg[src=\"http://static.tumblr.com/omgciym/Pnenkw34v/edrfwregwrgwtrgwr.jpg\"],\nimg[src=\"http://static.tumblr.com/omgciym/SXxm66n6y/lol-logo.png\"]"},{"a":"a[href=\"http://ganadineroconencuestas.com/dinero_flow/?webform=*&c=&s2s=*&pubid=*&subid=&medio=*&vendor=*&context=\"]"},{"a":"div[style=\"position:relative;z-index:100;height:450px\"]"},{"a":"#total"},{"a":"#block-especialclarodesktop"},{"a":"[href^=\"https://clasificados.clasiguia.com.pa\"]"},{"a":"[onclick*=\"/publicidad\"]"},{"a":".sidebar-zonahogar"},{"a":".ec-club"},{"a":"[class$=\"_ads\"]"},{"a":"#bannercentral,\n#bannercentral2,\n#bannertop"},{"a":".atm-banner-middle,\n.atm-banner-strip,\n.atm-banner-top"},{"a":".hiraoka"},{"a":".logo-min"},{"a":".content_gpt_top"},{"a":"#total2,\n#total3"},{"a":"#divpubli"},{"a":"#article-banner-comentarios,\n#breaking-news-banner1,\n#fullwidth-banner,\n#top-banners,\n.banner-full-60,\n.col-banner,\n.col-banner-45"},{"a":".grid.desk-8.alpha > p"},{"a":"a[href^=\"https://hacktorrent.net/\"]"},{"a":"#after-ad,\n[id^=\"Image\"]"},{"a":".adblockweb"},{"a":"#banner_sinopsis"},{"a":"#gift-middle"},{"a":"[id^=\"gift-\"]"},{"a":"#gift-top"},{"a":"span[style=\"font-weight:bold; cursor:pointer; text-decoration:underline\"]"},{"a":"a[href*=\"leadzupc.com/\"]"},{"a":"#closeX2"},{"a":".branding-wrapper"},{"a":".advertisement,\n.widget_ti_image_banner"},{"a":"a[href*=\"clicktag_promo\"]"},{"a":".grid_12 > .grid_4"},{"a":"a[href^=\"http://www.maxonclick.com/\"]"},{"a":"#promo,\n#promoSept19A,\n#promoSept19B,\n.promoTop"},{"a":"#bottomlink,\n#categories"},{"a":"a[href^=\"https://veranime.org/\"]"},{"a":".banners-side-container,\na[href=\"http://www.180.com.uy/banner?ID=857&CODE=portal.index\"]"},{"a":".auspicios,\n.modulo_publi"},{"a":"#conectab"},{"a":"#bannerEspeciales,\n#clima-banner"},{"a":".bfbc"},{"a":".bnpub"},{"a":".vjs-producer"},{"a":"[href^=\"https://qp.erotilink.es\"]"},{"a":".lst_ft_bn"}];

const hostnamesMap = new Map([["artesacro.org",0],["booksmedicos.org",1],["diariodelaribera.org",2],["finofilipino.org",3],["noticiasdelmundo.org",4],["peliculasyseries.org",5],["verdirectotv.org",6],["dinostream.pw",[6,18]],["diaadia.com.pa",7],["panamaamerica.com.pa",8],["andina.pe",9],["diariocorreo.pe",10],["elcomercio.pe",11],["gestion.pe",12],["laindustria.pe",13],["larepublica.pe",14],["peru21.pe",15],["rpp.pe",16],["trome.pe",17],["livesports.pw",19],["abc.com.py",20],["cuevana3.rip",21],["nocensor.sbs",22],["noticiasdehoy.site",23],["vidasana.sv",24],["cinecalidad.to",25],["ev01.to",26],["moviesjoy.to",27],["myflixertv.to",28],["seriesdanko.to",29],["animeid.tv",30],["cinestrenostv.tv",31],["eldoce.tv",32],["jerezcofrade.tv",33],["mundoplus.tv",34],["ondaluz.tv",35],["pelisplus.tv",36],["qmusica.tv",37],["shippuden.tv",38],["genteflow.us",39],["180.com.uy",40],["elobservador.com.uy",41],["montevideo.com.uy",42],["pantallazo.com.uy",43],["juegosjuegos.ws",44],["maduras.xxx",45],["videos.mrvideospornogratis.xxx",46],["qporno.xxx",47],["tupornogratis.xxx",48]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
