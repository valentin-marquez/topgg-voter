/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-procedural

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssProceduralImport() {

/******************************************************************************/

// ita-0

const argsList = [{"a":["{\"selector\":\".ruby-block-wrap\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"SPONSORED\"]]}]]}"]},{"a":["{\"selector\":\".widget_text.td_block_template_1.widget.widget_custom_html\",\"tasks\":[[\"has\",{\"selector\":\".block-title\",\"tasks\":[[\"has-text\",\"Intesa Sanpaolo\"]]}]]}"]},{"a":["{\"selector\":\".post.type-post.consigliato\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"Sponsorizzato\"]]}]]}"]},{"a":["{\"selector\":\".article-blog-default\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"CONTENUTO SPONSORIZZATO\"]]}]]}"]},{"a":["{\"selector\":\".td_block_wrap\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"Contenuti sponsorizzati\"]]}]]}"]},{"a":["{\"selector\":\".col-12.text-center\",\"tasks\":[[\"has\",{\"selector\":\".special\",\"tasks\":[[\"has-text\",\"Contenuto Sponsorizzato\"]]}]]}","{\"selector\":\".media-imgnews\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"Contenuto Sponsorizzato\"]]}]]}"]},{"a":["{\"selector\":\".homearticle-box\",\"tasks\":[[\"has\",{\"selector\":\"strong\",\"tasks\":[[\"has-text\",\"sponsorizzato\"]]}]]}"]},{"a":["{\"selector\":\".m-relases__result\",\"tasks\":[[\"has\",{\"selector\":\"div\",\"tasks\":[[\"has-text\",\"Contenuto pubblicitario\"]]}]]}"]},{"a":["{\"selector\":\".td_block_wrap\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"Contenuti sponsorizzati\"]]}]]}"]},{"a":["{\"selector\":\"article\",\"tasks\":[[\"has\",{\"selector\":\"p\",\"tasks\":[[\"has-text\",\"Sponsorizzata\"]]}]]}"]},{"a":["{\"selector\":\".row-inner\",\"tasks\":[[\"has\",{\"selector\":\"h2\",\"tasks\":[[\"has-text\",\"Branded\"]]}]]}"]},{"a":["{\"selector\":\".bx\",\"tasks\":[[\"has\",{\"selector\":\"div\",\"tasks\":[[\"has-text\",\"CONTENUTO SPONSORIZZATO\"]]}]]}"]},{"a":["{\"selector\":\".right.es.large\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"contenuto sponsorizzato\"]]}]]}"]},{"a":["{\"selector\":\".c-post\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"Sponsored by \"]]}]]}"]},{"a":["{\"selector\":\".et_pb_css_mix_blend_mode_passthrough\",\"tasks\":[[\"has-text\",\"Sponsorizzato\"]]}"]},{"a":["{\"selector\":\".feat-widget-wrap\",\"tasks\":[[\"has\",{\"selector\":\"div\",\"tasks\":[[\"has-text\",\"INFORMAZIONE REDAZIONALE\"]]}]]}"]},{"a":["{\"selector\":\".td_block_wrap\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"Advertorial\"]]}]]}"]},{"a":["{\"selector\":\".listed.small\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"Informazione Pubblicitaria\"]]}]]}"]},{"a":["{\"selector\":\"center\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"Esponi i tuoi banner sul forum\"]]}]]}"]},{"a":["{\"selector\":\"article[id^=\\\"post-\\\"]\",\"tasks\":[[\"has\",{\"selector\":\"span\",\"tasks\":[[\"has-text\",\"Adv\"]]}]]}"]},{"a":["{\"selector\":\".news\",\"tasks\":[[\"has\",{\"selector\":\"div\",\"tasks\":[[\"has-text\",\"in collaborazione con \"]]}]]}"]},{"a":["{\"selector\":\"div[class^=\\\"css-\\\"]\",\"tasks\":[[\"has\",{\"selector\":\"a\",\"tasks\":[[\"has-text\",\"contenuto sponsorizzato\"]]}]]}"]}];

const hostnamesMap = new Map([["innaturale.com",0],["italpress.com",1],["lavocedinovara.com",2],["lospiffero.com",3],["meccanicanews.com",4],["logisticanews.it",4],["mffashion.com",5],["tusciaweb.eu",6],["borsaitaliana.it",7],["ilprogettistaindustriale.it",8],["plastix.it",8],["lasicilia.it",9],["linkiesta.it",10],["iene.mediaset.it",11],["tgcom24.mediaset.it",12],["quattroruote.it",13],["quotidianodelsud.it",14],["radioluna.it",15],["technofashion.it",16],["zonalocale.it",17],["guadagna.net",18],["tuttoandroid.net",19],["open.online",20],["aleteia.org",21]]);

self.proceduralImports = self.proceduralImports || [];
self.proceduralImports.push({ argsList, hostnamesMap });

/******************************************************************************/

})();

/******************************************************************************/
