/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-procedural

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssProceduralImport() {

/******************************************************************************/

// hun-0

const argsList = [{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"adblocker\"]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"testadblock\"]]}"]},{"a":["{\"selector\":\"body > script\",\"tasks\":[[\"has-text\",\"a2blckLayer\"]]}"]},{"a":["{\"selector\":\".widget\",\"tasks\":[[\"has\",{\"selector\":\"h3w\",\"tasks\":[[\"has-text\",\"Támogatóink\"]]}]]}","{\"selector\":\"[class*=\\\"item_container\\\"]\",\"tasks\":[[\"has\",{\"selector\":\"[class*=\\\"_tag\\\"]\",\"tasks\":[[\"has-text\",\"hirdetés\"]]}]]}"]},{"a":["{\"selector\":\"div[class*=\\\"widget\\\"]\",\"tasks\":[[\"has\",{\"selector\":\" > .widgettitle\",\"tasks\":[[\"has-text\",\"Hirdetés\"]]}]]}","{\"selector\":\"div[class*=\\\"widget\\\"]\",\"tasks\":[[\"has\",{\"selector\":\" > .widgettitle\",\"tasks\":[[\"has-text\",\"Állásajánlat\"]]}]]}"]},{"a":["{\"selector\":\".sb-widget\",\"tasks\":[[\"has\",{\"selector\":\" > h4\",\"tasks\":[[\"has-text\",\"Hirdetés\"]]}]]}"]},{"a":["{\"selector\":\"body > script\",\"tasks\":[[\"has-text\",\"window.onload = window.onfocus\"]]}"]},{"a":["{\"selector\":\".wrapRectangle\",\"tasks\":[[\"has\",{\"selector\":\" > div > span\",\"tasks\":[[\"has-text\",\"Hirdetés\"]]}]]}","{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"Quantcast Choice\"]]}"]},{"a":["{\"selector\":\"body > script\",\"tasks\":[[\"has-text\",\"cli_cookiebar_\"]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"contextmenu\"]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"ai_run_\"]]}"]},{"a":["{\"selector\":\".ik\",\"tasks\":[[\"has-text\",\"/^[Hh]irdetés$/\"]]}"]},{"a":["{\"selector\":\"div[style*=\\\"margin-bottom:10px\\\"]\",\"tasks\":[[\"has\",{\"selector\":\" > div\",\"tasks\":[[\"has-text\",\"HIRDETÉS\"]]}]]}"]},{"a":["{\"selector\":\"aside\",\"tasks\":[[\"has\",{\"selector\":\".widgettitle > span\",\"tasks\":[[\"has-text\",\"Hirdetés\"]]}]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"popUpBannerBox Ad300 hirdetes_box\"]]}"]},{"a":["{\"selector\":\"body > script\",\"tasks\":[[\"has-text\",\"fbmodal-title\"]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"window.atob\"]]}"]},{"a":["{\"selector\":\"body > script\",\"tasks\":[[\"has-text\",\"ShadowRoot\"]]}"]},{"a":["{\"selector\":\"div.grid_item\",\"tasks\":[[\"has\",{\"selector\":\" > div\",\"tasks\":[[\"has-text\",\"Hirdetés\"]]}]]}","{\"selector\":\"div.grid_item\",\"tasks\":[[\"has-text\",\"Google Hirdetés\"]]}"]},{"a":["{\"selector\":\"script\",\"tasks\":[[\"has-text\",\"adpv\"]]}"]}];

const hostnamesMap = new Map([["hungliaonline.com",0],["openspeedtest.com",1],["24.hu",2],["bpiautosok.hu",3],["budapestkornyeke.hu",4],["cyberpress.hu",5],["divany.hu",6],["totalbike.hu",6],["totalcar.hu",6],["egeszsegkalauz.hu",7],["gamer.hu",8],["grundoajandek.hu",9],["hang.hu",10],["magyarhang.org",10],["idokep.hu",11],["kezilabda.hu",12],["kiszamolo.hu",13],["port.hu",14],["portfolio.hu",15],["szeretlekmagyarorszag.hu",16],["filmvilag.me",17],["szineshir.net",18],["ncore.pro",19]]);

self.proceduralImports = self.proceduralImports || [];
self.proceduralImports.push({ argsList, hostnamesMap });

/******************************************************************************/

})();

/******************************************************************************/
