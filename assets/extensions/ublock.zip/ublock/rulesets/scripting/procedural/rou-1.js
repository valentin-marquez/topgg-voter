/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-procedural

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssProceduralImport() {

/******************************************************************************/

// rou-1

const argsList = [{"a":["{\"selector\":\".widget_text\",\"tasks\":[[\"has\",{\"selector\":\"[href*=\\\"utm_source=aff\\\"]\"}]]}"]},{"a":["{\"selector\":\".post_block:has([class^=\\\"guest\\\"])\",\"tasks\":[[\"has-text\",\"Anunturi\"]]}"]},{"a":["{\"selector\":\".code-block\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\".sidebar-widget\",\"tasks\":[[\"has-text\",\"/Recomandate/\"],[\"not\",{\"selector\":\"*\",\"tasks\":[[\"has-text\",\"Post\"]]}]]}"]},{"a":["{\"selector\":\"div.grey-section\",\"tasks\":[[\"has-text\",\"Advertorial\"]]}"]},{"a":["{\"selector\":\"#sidebar > div.widget\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\".td-pb-span3\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\".textwidget\",\"tasks\":[[\"has-text\",\"PUBLICITATE\"]]}"]},{"a":["{\"selector\":\".td-pb-span12\",\"tasks\":[[\"has-text\",\"Advertisement\"]]}"]},{"a":["{\"selector\":\"h2\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\"section\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\".widget\",\"tasks\":[[\"has-text\",\"Reclame\"]]}"]},{"a":["{\"selector\":\".mh-widget\",\"tasks\":[[\"has-text\",\"/PROMO|PARTENER/i\"]]}"]},{"a":["{\"selector\":\".custom_textwidget\",\"tasks\":[[\"has-text\",\"publicitar\"]]}"]},{"a":["{\"selector\":\"#custom_html-10\",\"tasks\":[[\"has-text\",\"Advertising\"]]}"]},{"a":["{\"selector\":\".widget_text.widget\",\"tasks\":[[\"has-text\",\"Reclame\"]]}"]},{"a":["{\"selector\":\"td > center\",\"tasks\":[[\"has-text\",\"Reclama\"]]}"]},{"a":["{\"selector\":\".elementor-element\",\"tasks\":[[\"has-text\",\"ad\"]]}"]},{"a":["{\"selector\":\".special-box-pm > p\",\"tasks\":[[\"has-text\",\"Philip Morris\"]]}"]},{"a":["{\"selector\":\".textlink\",\"tasks\":[[\"has-text\",\"ad\"]]}"]},{"a":["{\"selector\":\".widget_media_image\",\"tasks\":[[\"has\",{\"selector\":\"[href]\",\"tasks\":[[\"not\",{\"selector\":\"*\",\"tasks\":[[\"has-text\",\"[href*=\\\"litoraltv.ro\\\"]\"],[\"spath\",\":not(*:has([href*=\\\"facebook.com\\\"]))\"]]}]]}]]}"]},{"a":["{\"selector\":\".widget\",\"tasks\":[[\"has-text\",\"/Publicitate|Asemanatoare/\"]]}"]},{"a":["{\"selector\":\".widget\",\"tasks\":[[\"has-text\",\"PUBLICITATE\"]]}"]},{"a":["{\"selector\":\".elementor-column\",\"tasks\":[[\"has-text\",\"PUBLICITATE\"]]}"]},{"a":["{\"selector\":\".widget_header\",\"tasks\":[[\"has-text\",\"/recomand/i\"]]}"]},{"a":["{\"selector\":\".tdm-descr\",\"tasks\":[[\"has-text\",\"sponsor\"]]}"]},{"a":["{\"selector\":\".ipsWidget_title.ipsType_reset\",\"tasks\":[[\"has-text\",\"Sponsor\"]]}"]},{"a":["{\"selector\":\"article > div.td-post-content > p\",\"tasks\":[[\"has-text\",\"/^\\\\u00A0$/\"]]}"]},{"a":["{\"selector\":\".inside-right-sidebar\",\"tasks\":[[\"has-text\",\"ads\"]]}"]},{"a":["{\"selector\":\".textwidget\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]},{"a":["{\"selector\":\".widget_custom_html\",\"tasks\":[[\"has-text\",\"ad\"]]}"]},{"a":["{\"selector\":\".boxstire2head\",\"tasks\":[[\"has-text\",\"Publicitate\"]]}"]}];

const hostnamesMap = new Map([["aproapemasini.com",0],["forum.softpedia.com",1],["cespun.eu",2],["7media.md",3],["agora.md",4],["buzau.net",5],["agro-tv.ro",6],["agrointel.ro",7],["autolatest.ro",8],["buletindecarei.ro",9],["campinatv.ro",10],["ciutacu.ro",11],["ctnews.ro",12],["curier.ro",13],["evmarket.ro",14],["gazetavalceana.ro",15],["girlshare.ro",16],["graiulsalajului.ro",17],["jurnalul.ro",18],["kudika.ro",19],["litoraltv.ro",20],["lovendal.ro",21],["mesageruldesibiu.ro",22],["mesagerulneamt.ro",23],["nwradu.ro",24],["presadeazi.ro",25],["sa-mp.ro",26],["smlive.ro",27],["stireadeazi.ro",28],["weradio.ro",29],["ziarulargesul.ro",30],["zvj.ro",31]]);

self.proceduralImports = self.proceduralImports || [];
self.proceduralImports.push({ argsList, hostnamesMap });

/******************************************************************************/

})();

/******************************************************************************/
