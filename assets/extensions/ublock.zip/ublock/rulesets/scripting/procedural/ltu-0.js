/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-procedural

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssProceduralImport() {

/******************************************************************************/

// ltu-0

const argsList = [{"a":["{\"selector\":\".col-md-6\",\"tasks\":[[\"has\",{\"selector\":\"ins.adsbygoogle\"}]]}"]},{"a":["{\"selector\":\".obj-cont dt\",\"tasks\":[[\"has-text\",\" Reklama/\"]]}"]},{"a":["{\"selector\":\"#sp-right .module\",\"tasks\":[[\"has\",{\"selector\":\"script, a[data-saferedirecturl]\"}]]}"]},{"a":["{\"selector\":\".widget_text\",\"tasks\":[[\"has\",{\"selector\":\"ins\"}]]}"]},{"a":["{\"selector\":\".md-block > div:not([class])\",\"tasks\":[[\"has\",{\"selector\":\"> [class*=\\\"adx\\\"]\"}]]}"]},{"a":["{\"selector\":\"#sidebar1 > div\",\"tasks\":[[\"has-text\",\"mods\"]]}"]},{"a":["{\"selector\":\".td_block_wrap\",\"tasks\":[[\"has-text\",\"/^Nuorodos/\"]]}"]},{"a":["{\"selector\":\".sp-column\",\"tasks\":[[\"has\",{\"selector\":\"#krepsiniozinios_lt_top\"}]]}"]},{"a":["{\"selector\":\".partner-item\",\"tasks\":[[\"upward\",\".bg-gray-100\"]]}"]},{"a":["{\"selector\":\".widget_custom_html\",\"tasks\":[[\"has\",{\"selector\":\".stickyContainer\"}]]}"]},{"a":["{\"selector\":\"aside > .uk-panel-box\",\"tasks\":[[\"has\",{\"selector\":\"> ins\"}]]}"]},{"a":["{\"selector\":\".portlet_block\",\"tasks\":[[\"has-text\",\"Partneriai\"]]}"]},{"a":["{\"selector\":\"#sidebar > div.custom-div\",\"tasks\":[[\"has-text\",\"REKLAMA\"]]}"]},{"a":["{\"selector\":\".sp-module\",\"tasks\":[[\"has\",{\"selector\":\".adsbygoogle, img[src*=\\\"/reklama_\\\"], a[href*=\\\"mods.\\\"]\"}]]}"]},{"a":["{\"selector\":\"center\",\"tasks\":[[\"has-text\",\"Reklama\"]]}"]}];

const hostnamesMap = new Map([["anekdotai.lt",0],["aruodas.lt",1],["budas.lt",2],["bukimevieningi.lt",3],["m.delfi.lt",4],["kaunozinios.lt",5],["klaipedoszinios.lt",6],["xn--iauliinios-z9b5t9e.lt",6],["krepsiniozinios.lt",7],["lkl.lt",8],["nidosreceptai.lt",9],["pirkis.lt",10],["technologijos.lt",11],["tv3.lt",12],["zarasuose.lt",13],["itiketini-faktai.online",14]]);

self.proceduralImports = self.proceduralImports || [];
self.proceduralImports.push({ argsList, hostnamesMap });

/******************************************************************************/

})();

/******************************************************************************/
