/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name set-constant
/// alias set

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_setConstant() {

/******************************************************************************/

// spa-1

const argsList = [{"a":["adBlockerActive","false"]},{"a":["cdo","1"]},{"a":["canRunAds","true"]},{"a":["eazy_ad_unblocker_msg_var","''"]},{"a":["antiAdBlockerStyle","noopFunc"]},{"a":["Object.prototype.adblockerEnabled","false"]},{"a":["adsbygoogle.loaded","true"]},{"a":["adBlockCheck","true"]},{"a":["pp_show_popupmessage","noopFunc"]},{"a":["easySettings.adblock","0"]},{"a":["onload","null"]},{"a":["adblockDetector.init","noopFunc"]},{"a":["adsbygoogle.length","undefined"]},{"a":["WSL2.config.enableAdblockEcommerce","0"]},{"a":["ads_unblocked","true"]},{"a":["adblock","true"]},{"a":["kkwoiNI","noopFunc"]},{"a":["yUIlOsT","noopFunc"]},{"a":["better_ads_adblock","true"]},{"a":["adBlockDetected","false"]},{"a":["isAdsDisplayed","true"]},{"a":["Lata","1"]},{"a":["loadingAds","true"]},{"a":["goog_pvsid","1"]},{"a":["Goog_Osd_UnloadAdBlock","1"]},{"a":["google_osd_loaded","1"]},{"a":["stopMan","false"]},{"a":["google_unique_id","1"]},{"a":["googleIMState","{}"]},{"a":["ads","false"]},{"a":["acdl","undefined"]},{"a":["player.preroll","noopFunc"]},{"a":["anunciotag","noopFunc"]},{"a":["_mvnxp","noopFunc"]},{"a":["loadingAds","undefined"]},{"a":["click","1"]},{"a":["clickd","1"]},{"a":["xxxStore","undefined"]},{"a":["vidorev_jav_plugin_video_ads_object.vid_ads_m_video_ads","''"]},{"a":["clicked","true"]},{"a":["eClicked","true"]},{"a":["number","0"]},{"a":["sync","true"]},{"a":["a_consola","noopFunc"]}];

const hostnamesMap = new Map([["pobre.wtf",[0,29]],["suaurl.com",[1,30]],["impactoespananoticias.com",2],["skynovels.net",2],["wuolah.com",2],["botinnifit.com",2],["minhasdelicias.com",2],["luchaonline.com",2],["legendei.net",3],["mangacrab.com",4],["cadenaser.com",5],["texto.kom.gt",6],["infojobs.com.br",7],["maringapost.com.br",8],["bandab.com.br",8],["ouniversodatv.com",9],["tribunaavila.com",10],["deportealdia.live",11],["elquintobeatle.com",12],["empregoestagios.com",12],["satcesc.com",12],["applesfera.com",13],["bebesymas.com",13],["compradiccion.com",13],["diariodelviajero.com",13],["directoalpaladar.com",13],["elblogsalmon.com",13],["espinof.com",13],["genbeta.com",13],["motorpasion.com",13],["motorpasionmoto.com",13],["pymesyautonomos.com",13],["trendencias.com",13],["trendenciashombre.com",13],["vidaextra.com",13],["vitonica.com",13],["xataka.com",13],["xatakaciencia.com",13],["xatakafoto.com",13],["xatakahome.com",13],["xatakamovil.com",13],["xatakandroid.com",13],["xatakawindows.com",13],["doceru.com",14],["docero.com.br",14],["comandotorrents.org",15],["mangahost.site",[16,17]],["adslayuda.com",18],["outerspace.com.br",19],["doramasmp4.com",20],["file4go.net",21],["seriesdonghua.com",22],["mundodonghua.com",22],["mangahost4.com",[23,24,25,26,27,28]],["mangahosted.com",[23,24,25,26,27,28]],["mangahost2.com",[23,24,25,26,27,28]],["mangahost1.com",28],["mangahostbr.net",28],["mangahostbr.com",28],["player.hentaistube.com",31],["playnewserie.xyz",32],["vizer.vip",33],["tiohentai.xyz",34],["otakustv.com",[35,36]],["pornolandia.xxx",37],["hentaiporno.xxx",38],["megadescarga.net",[39,40,41,42]],["fakings.com",43]]);

/******************************************************************************/

const scriptlet = (
    chain = '',
    cValue = ''
) => {
    if ( chain === '' ) { return; }
    if ( cValue === 'undefined' ) {
        cValue = undefined;
    } else if ( cValue === 'false' ) {
        cValue = false;
    } else if ( cValue === 'true' ) {
        cValue = true;
    } else if ( cValue === 'null' ) {
        cValue = null;
    } else if ( cValue === "''" ) {
        cValue = '';
    } else if ( cValue === '[]' ) {
        cValue = [];
    } else if ( cValue === '{}' ) {
        cValue = {};
    } else if ( cValue === 'noopFunc' ) {
        cValue = function(){};
    } else if ( cValue === 'trueFunc' ) {
        cValue = function(){ return true; };
    } else if ( cValue === 'falseFunc' ) {
        cValue = function(){ return false; };
    } else if ( /^\d+$/.test(cValue) ) {
        cValue = parseFloat(cValue);
        if ( isNaN(cValue) ) { return; }
        if ( Math.abs(cValue) > 0x7FFF ) { return; }
    } else {
        return;
    }
    let aborted = false;
    const mustAbort = function(v) {
        if ( aborted ) { return true; }
        aborted =
            (v !== undefined && v !== null) &&
            (cValue !== undefined && cValue !== null) &&
            (typeof v !== typeof cValue);
        return aborted;
    };
    // https://github.com/uBlockOrigin/uBlock-issues/issues/156
    //   Support multiple trappers for the same property.
    const trapProp = function(owner, prop, configurable, handler) {
        if ( handler.init(owner[prop]) === false ) { return; }
        const odesc = Object.getOwnPropertyDescriptor(owner, prop);
        let prevGetter, prevSetter;
        if ( odesc instanceof Object ) {
            owner[prop] = cValue;
            if ( odesc.get instanceof Function ) {
                prevGetter = odesc.get;
            }
            if ( odesc.set instanceof Function ) {
                prevSetter = odesc.set;
            }
        }
        try {
            Object.defineProperty(owner, prop, {
                configurable,
                get() {
                    if ( prevGetter !== undefined ) {
                        prevGetter();
                    }
                    return handler.getter(); // cValue
                },
                set(a) {
                    if ( prevSetter !== undefined ) {
                        prevSetter(a);
                    }
                    handler.setter(a);
                }
            });
        } catch(ex) {
        }
    };
    const trapChain = function(owner, chain) {
        const pos = chain.indexOf('.');
        if ( pos === -1 ) {
            trapProp(owner, chain, false, {
                v: undefined,
                init: function(v) {
                    if ( mustAbort(v) ) { return false; }
                    this.v = v;
                    return true;
                },
                getter: function() {
                    return cValue;
                },
                setter: function(a) {
                    if ( mustAbort(a) === false ) { return; }
                    cValue = a;
                }
            });
            return;
        }
        const prop = chain.slice(0, pos);
        const v = owner[prop];
        chain = chain.slice(pos + 1);
        if ( v instanceof Object || typeof v === 'object' && v !== null ) {
            trapChain(v, chain);
            return;
        }
        trapProp(owner, prop, true, {
            v: undefined,
            init: function(v) {
                this.v = v;
                return true;
            },
            getter: function() {
                return this.v;
            },
            setter: function(a) {
                this.v = a;
                if ( a instanceof Object ) {
                    trapChain(a, chain);
                }
            }
        });
    };
    trapChain(window, chain);
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
