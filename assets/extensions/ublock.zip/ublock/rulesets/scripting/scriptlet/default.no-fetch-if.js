/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-fetch-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noFetchIf() {

/******************************************************************************/

// default

const argsList = [{"a":["ads"]},{"a":["/^/"]},{"a":["player-feedback"]},{"a":["method:HEAD"]},{"a":["googlesyndication"]},{"a":["googlesyndication","method:HEAD"]},{"a":["adsbygoogle"]},{"a":["damoh.ani-stream.com"]},{"a":["/google|adpushup/"]},{"a":["zomap.de"]},{"a":["adsafeprotected"]},{"a":["google"]},{"a":["cloudfront"]},{"a":["googletagmanager"]},{"a":["popunder"]},{"a":["/google|\\/ad.+\\.js/"]},{"a":["adsbygoogle.js"]},{"a":["pop"]},{"a":["snigelweb"]},{"a":["manager"]},{"a":["moonicorn.network"]},{"a":["ad"]},{"a":["tvid.in/log"]},{"a":["cloudfront.net/?"]},{"a":["xhr0"]},{"a":["analytics"]},{"a":["wtg-ads"]},{"a":["adv"]},{"a":["doubleclick"]},{"a":["cloud"]},{"a":["/ads|doubleclick/"]},{"a":["dqst.pl"]},{"a":["/googlesyndication|uniconsent/"]},{"a":["googlesyndication.com"]},{"a":["ads."]},{"a":["wpadmngr"]},{"a":["vlitag"]},{"a":["imasdk"]},{"a":["adoto"]},{"a":["tpc.googlesyndication.com"]},{"a":["syndication"]},{"a":["/freychang|passback|popunder|tag/"]},{"a":["google-analytics"]},{"a":["ima"]},{"a":["/\\d\\?country/"]},{"a":["body:browser"]},{"a":["url:/^https:\\/\\/www\\.reddit\\.com$/ method:post"]},{"a":["body:/[\\w\\W]{700}/"]},{"a":["method:/post|posT|poSt|poST|pOst|pOsT|pOSt|pOST|Post|PosT|PoSt|PoST|POst|POsT|POSt|POST/"]},{"a":["marmalade"]},{"a":["url:ipapi.co"]},{"a":["api"]}];

const hostnamesMap = new Map([["allmusic.com",0],["investing.com",0],["mylivewallpapers.com",0],["softfully.com",0],["sekilastekno.com",0],["mangahost4.com",0],["key-hub.eu",0],["discoveryplus.in",0],["news-world24.com",0],["calculator-online.net",0],["tutorial.siberuang.com",0],["romania.bz",0],["desiflixindia.com",0],["insurance.iptvsetupguide.com",0],["dotabuff.com",0],["mcqmall.com",0],["nguontv.org",0],["apksafe.in",0],["spigotunlocked.org",0],["cizzyscripts.com",0],["clamor.pl",0],["one-tech.xyz",0],["ozulscans.com",0],["i-polls.com",0],["insurancevela.com",0],["plagiarismchecker.co",0],["noor-book.com",0],["viraluttarakhand.in",0],["wrzesnia.info.pl",0],["elahmad.com",0],["compromath.com",0],["sumoweb.to",0],["haloursynow.pl",0],["skidrowreloaded.com",1],["filmisub.com",1],["player.glomex.com",2],["mac2sell.net",3],["1001tracklists.com",3],["gamebrew.org",3],["rechub.tv",3],["game3rb.com",3],["sixsave.com",3],["highload.to",3],["bowfile.com",[3,23]],["hdsport.biz",3],["dealsfinders.blog",3],["iphonechecker.herokuapp.com",3],["coloringpage.eu",3],["conocimientoshackers.com",3],["juegosdetiempolibre.org",3],["karaokegratis.com.ar",3],["mammaebambini.it",3],["riazor.org",3],["rinconpsicologia.com",3],["sempredirebanzai.it",3],["vectogravic.com",3],["androidacy.com",3],["freetohell.com",3],["faucetcrypto.com",4],["mynewsmedia.co",4],["toolss.net",4],["romadd.com",4],["disheye.com",4],["dailynewstoknow.com",4],["blog-forall.com",4],["homeairquality.org",[4,13]],["techtrim.tech",4],["arhplyrics.in",4],["raky.in",4],["askpaccosi.com",4],["crypto4tun.com",4],["jpoplist.us",4],["quizack.com",4],["moddingzone.in",4],["rajsayt.xyz",4],["jaunpurmusic.info",4],["apkandroidhub.in",4],["babymodz.com",4],["deezloaded.com",4],["mad.gplpalace.one",4],["studyis.xyz",4],["worldappsstore.xyz",4],["prepostseo.com",4],["dulichkhanhhoa.net",4],["noithatmyphu.vn",4],["bitefaucet.com",4],["iptvjournal.com",4],["dramaworldhd.co",4],["tudaydeals.com",4],["choiceappstore.xyz",4],["inbbotlist.com",4],["freepreset.net",4],["cryptoblog24.info",4],["amritadrino.com",4],["wikitraveltips.com",4],["getintoway.com",4],["crdroid.net",4],["zerion.cc",4],["beelink.pro",4],["hax.co.id",4],["woiden.id",4],["pviewer.site",4],["theusaposts.com",4],["hackr.io",4],["esopress.com",4],["muyinteresante.es",5],["leechpremium.link",6],["camcam.cc",6],["png.is",6],["nohat.cc",6],["kpopsea.com",6],["isi7.net",6],["hyipstats.net",6],["palixi.net",6],["howdy.id",6],["fastssh.com",6],["sshkit.com",6],["freecoursesonline.me",6],["pinloker.com",6],["audiodoceo.com",6],["ani-stream.com",7],["smallseotools.com",8],["joyn.de",9],["tf1.fr",10],["exe.app",11],["freshi.site",11],["eio.io",11],["ufacw.com",11],["figurehunter.net",11],["workink.click",12],["camarchive.tv",14],["duplichecker.com",15],["hindustantimes.com",16],["makaveli.xyz",17],["falixnodes.net",18],["linkpoi.me",19],["platform.adex.network",20],["mcrypto.club",21],["coinsparty.com",21],["weszlo.com",21],["timesnowhindi.com",22],["timesnowmarathi.com",22],["timesofindia.com",22],["tinyurl.is",24],["wyze.com",25],["mmorpg.org.pl",26],["pinoyfaucet.com",27],["journaldemontreal.com",28],["tvanouvelles.ca",28],["boxingstreams100.com",28],["mlbstreams100.com",28],["mmastreams-100.tv",28],["nbastreams-100.tv",28],["soccerstreams-100.tv",28],["vods.tv",28],["weather.com",28],["independent.co.uk",28],["speedrun.com",29],["dongknows.com",30],["forsal.pl",31],["photopea.com",32],["2the.space",33],["drakescans.com",34],["allcryptoz.net",35],["crewbase.net",35],["crewus.net",35],["shinbhu.net",35],["shinchu.net",35],["thumb8.net",35],["thumb9.net",35],["topcryptoz.net",35],["uniqueten.net",35],["ultraten.net",35],["mdn.lol",35],["freeshib.biz",36],["deutschekanale.com",37],["multifaucet.club",38],["soranews24.com",39],["computerpedia.in",40],["smartkhabrinews.com",41],["freepik-downloader.com",42],["ortograf.pl",43],["listen.tidal.com",44],["search.brave.com",45],["reddit.com",46],["blog.skk.moe",47],["skk.moe",48],["pimylifeup.com",49],["seazon.fr",50],["html5.gamedistribution.com",51]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.fetch = new Proxy(self.fetch, {
        apply: function(target, thisArg, args) {
            let proceed = true;
            try {
                let details;
                if ( args[0] instanceof self.Request ) {
                    details = args[0];
                } else {
                    details = Object.assign({ url: args[0] }, args[1]);
                }
                const props = new Map();
                for ( const prop in details ) {
                    let v = details[prop];
                    if ( typeof v !== 'string' ) {
                        try { v = JSON.stringify(v); }
                        catch(ex) { }
                    }
                    if ( typeof v !== 'string' ) { continue; }
                    props.set(prop, v);
                }
                proceed = needles.length === 0;
                for ( const { key, re } of needles ) {
                    if (
                        props.has(key) === false ||
                        re.test(props.get(key)) === false
                    ) {
                        proceed = true;
                        break;
                    }
                }
            } catch(ex) {
            }
            return proceed
                ? Reflect.apply(target, thisArg, args)
                : Promise.resolve(new Response());
        }
    });
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

