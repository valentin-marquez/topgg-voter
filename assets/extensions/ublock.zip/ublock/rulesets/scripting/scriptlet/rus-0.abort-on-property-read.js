/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-on-property-read
/// alias aopr

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortOnPropertyRead() {

/******************************************************************************/

// rus-0

const argsList = [{"a":["AdbBanner"]},{"a":["CTRManager.host3"]},{"a":["CheckingUser"]},{"a":["ClickUndercookie"]},{"a":["D4zz"]},{"a":["Date.prototype.toUTCString"]},{"a":["EUMPAntiblockConfig"]},{"a":["Groups.showDisclaimer"]},{"a":["Light.Popup"]},{"a":["Object.prototype.AdfoxXhrRequestPrepared"]},{"a":["Object.prototype.BannerAdx"]},{"a":["Object.prototype.Metrika"]},{"a":["Object.prototype.YA_TURBO_PAGES"]},{"a":["Object.prototype._isAutostartQueueSet"]},{"a":["Object.prototype.brandingBlock"]},{"a":["Object.prototype.fakeDetect"]},{"a":["Object.prototype.initDeps"]},{"a":["Object.prototype.initOnPlay"]},{"a":["Object.prototype.isApplySticky"]},{"a":["Object.prototype.loadBanner"]},{"a":["Object.prototype.noAdsHref"]},{"a":["Object.prototype.parseBlockId"]},{"a":["Object.prototype.render"]},{"a":["Object.prototype.scriptsViaXhr"]},{"a":["Object.prototype.yaContextCb"]},{"a":["PUM.getPopup"]},{"a":["PageBottomBanners"]},{"a":["SIN.AdsLoader"]},{"a":["TotemToolsObject"]},{"a":["Unauthorized"]},{"a":["Unauthorized2"]},{"a":["WebSocket"]},{"a":["XMLHttpRequest"]},{"a":["Ya"]},{"a":["a_urls"]},{"a":["aab"]},{"a":["abl"]},{"a":["adblock_availability_check"]},{"a":["adcashMacros"]},{"a":["admiral"]},{"a":["ads"]},{"a":["advFirstClickOpenNewTab"]},{"a":["advanced_ads_ready"]},{"a":["anOptions"]},{"a":["app_vars.force_disable_adblock"]},{"a":["atob"]},{"a":["blocked_action"]},{"a":["brblob"]},{"a":["cardinals"]},{"a":["clickNS4"]},{"a":["createAds"]},{"a":["creepyVideo"]},{"a":["disable_copy"]},{"a":["disable_hot_keys"]},{"a":["document.addEventListener"]},{"a":["document.body.oncopy"]},{"a":["document.getElementById","mdl_adb"]},{"a":["document.oncontextmenu"]},{"a":["document.ondragstart"]},{"a":["document.onkeydown"]},{"a":["eaglePlayerPlugins.autoplay_position"]},{"a":["echelon"]},{"a":["flat_pm_arr"]},{"a":["forTheFreeVideo.css"]},{"a":["getSelection"]},{"a":["get_ya_browser"]},{"a":["goTolink"]},{"a":["helpUsImproveSite"]},{"a":["initsnow"]},{"a":["isABPEnabled"]},{"a":["kav_cn"]},{"a":["lftrght"]},{"a":["m205"]},{"a":["mdpDeBlocker"]},{"a":["move_string"]},{"a":["myatu_bgm"]},{"a":["nocontext"]},{"a":["onload"]},{"a":["open"]},{"a":["perROS"]},{"a":["preventSelection"]},{"a":["setsnow"]},{"a":["sparkle"]},{"a":["stopPrntScr"]},{"a":["target_script"]},{"a":["td_ad_background_click_target"]},{"a":["tingle"]},{"a":["tnAdditionalParams"]},{"a":["unSelect"]},{"a":["updateDownloadLinks"]},{"a":["utarget_script"]},{"a":["video.preroll"]},{"a":["vpb"]},{"a":["web_script"]},{"a":["webpackChunkyandex_pcode"]},{"a":["weekCallbacks"]},{"a":["window.alert"]},{"a":["window.block"]},{"a":["yaContextCb"]},{"a":["zfgformats"]},{"a":["OK.hooks"]},{"a":["globalAuthLoginPopupCounter"]},{"a":["u_global_data"]}];

const hostnamesMap = new Map([["htmlweb.ru",0],["joyreactor.cc",1],["pornreactor.cc",[1,4]],["reactor.cc",1],["tarkov-wiki.ru",2],["anifap.com",3],["anipoisk.org",3],["anitokyo.tv",3],["hcdn.online",3],["kinofilm.co",3],["fapreactor.com",4],["24smi.org",[5,22]],["amedia.online",[5,16]],["rg.ru",[5,94]],["sm.news",[5,33,35,80]],["ura.news",[5,98]],["player.mediavitrina.ru",6],["vk.com",[7,26,29,30]],["vk.ru",[7,26,29,30]],["rutor.org",8],["drive2.ru",[9,24]],["www.kinopoisk.ru",10],["liveinternet.ru",[11,12]],["yap.ru",11],["yaplakal.com",11],["rbc.ru",[13,18,64]],["www.e1.ru",14],["fishki.net",15],["gdespaces.com",17],["gdespaces.net",17],["google-cloud.services",17],["spac.me",17],["spac1.com",17],["spac1.info",17],["spac1.me",17],["spac1.net",17],["spac1.org",17],["spac1.ru",17],["spaces-blogs.com",17],["spaces.im",17],["spcs.global",17],["spcs.life",17],["spcs.me",17],["spcs.news",17],["spcs.pro",17],["spcs.pub",17],["spcs.social",17],["strip2.in",17],["strip2.xxx",17],["usersporn.com",17],["nova.rambler.ru",19],["lena-miro.ru",20],["levik.blog",20],["livejournal.com",20],["olegmakarenko.ru",20],["periskop.su",20],["shakko.ru",20],["shiro-kino.ru",20],["vadimrazumov.ru",20],["reshuege.ru",21],["reshuoge.ru",21],["reshuvpr.ru",21],["sdamgia.ru",21],["gismeteo.by",23],["gismeteo.kz",23],["gismeteo.md",23],["gismeteo.ru",23],["f1comp.ru",25],["tagaev.com",25],["times.zt.ua",25],["sinoptik.ua",[27,92]],["porngames.su",28],["rintor.info",28],["rintor.net",28],["castle-tv.com",31],["coderlessons.com",32],["fixx.one",32],["its-kids.ru",32],["molitvy.guru",32],["nizhny.ru",32],["pro100hobbi.ru",32],["publy.ru",32],["samelectric.ru",32],["svadba.expert",32],["vibir.ru",32],["3dnews.kz",33],["3dnews.ru",33],["avtovzglyad.ru",33],["baby.ru",33],["dni.ru",33],["e1.ru",33],["mamba.ru",33],["sports.ru",33],["www.goha.ru",33],["forum.overclockers.ua",34],["bstudy.net",36],["studbooks.net",36],["studme.org",36],["studref.com",36],["studwood.net",36],["vuzlit.com",36],["xstud.org",36],["vgtimes.ru",37],["upload.ee",38],["footboom.com",[39,61]],["footboom.kz",[39,61]],["electric-house.ru",40],["stroi-help.ru",40],["freehat.cc",[41,78]],["agroreview.com",42],["amazinghis.ru",43],["moj-pes.ru",43],["shrlink.top",44],["friends.in.ua",[45,54]],["gidonline.eu",[45,84]],["medicina.ua",46],["anidub.vip",47],["anidubonline.com",47],["overclockers.ru",48],["zaruba.fun",49],["vesti.ua",50],["gazeta.ru",[51,60,66]],["kolizhanka.com.ua",[52,53,76]],["gra-prestoliv.in.ua",54],["simpsonsua.tv",54],["pravvest.ru",55],["dclans.ru",56],["animevost.org",57],["animevost.site",57],["animevost.top",57],["doefiratv.info",57],["payeer-gift.ru",57],["sinema.top",57],["smotret-anime-365.ru",57],["turkish-tv-series.ru",[57,59,64]],["vost.pw",57],["my-expert.ru",58],["7ogorod.ru",62],["autonevod.ru",62],["shtrafsud.ru",62],["zazloo.ru",62],["kinozapas.co",63],["livesx.online",63],["xn--80aikhbrhr.xn--j1amh",63],["championat.com",64],["doramy.club",64],["sportrbc.ru",64],["musify.club",65],["dota2.ru",67],["elitesnooker.com",68],["pikabu.ru",69],["artfile.me",70],["artfile.ru",70],["astrakhan.ru",70],["myjane.ru",70],["omskpress.ru",70],["tambovnet.org",70],["daz3d.ru",71],["studizba.com",72],["asteriatm.ru",73],["sudya-dredd.ru",[73,83]],["tehnobzor.ru",73],["anime-chan.me",[74,82]],["city.ogo.ua",75],["it-actual.ru",77],["hlamer.ru",78],["lostpix.com",78],["oveg.ru",78],["potokcdn.com",78],["prostoporno.help",78],["saltday.ru",78],["uploadimagex.com",78],["wowskill.ru",78],["xittv.net",78],["all-episodes.one",79],["tapochek.net",[81,93]],["bryansknovosti.ru",83],["novozybkov.su",83],["kinogo.eu",84],["1informer.com",85],["fainaidea.com",85],["housechief.ru",85],["itech.co.ua",85],["mediasat.info",85],["root-nation.com",85],["fssp.gov.ru",86],["liveforums.ru",87],["onlineclass.space",88],["nsportal.ru",89],["animekun.ru",90],["doramakun.ru",90],["vestivrn.ru",91],["www.ukr.net",92],["gorodrabot.by",94],["gorodrabot.ru",94],["relax-fm.ru",94],["4studio.com.ua",95],["cikavosti.com",95],["dialogs.org.ua",95],["fakty.ua",95],["gorodkiev.com.ua",95],["informator.ua",95],["kriminal.tv",95],["mignews.com.ua",95],["pingvin.pro",95],["technoportal.com.ua",95],["u-news.com.ua",95],["uanews.org.ua",95],["versii.if.ua",95],["volynpost.com",95],["bombardir.ru",96],["comp-service.kiev.ua",96],["softportal.com",97],["80-e.ru",98],["examenpdd.com",98],["animedia.tv",99],["animedub.ru",99],["vsetut.su",99],["ok.ru",[100,101]],["3dn.ru",102],["a-point.info",102],["addfiles.ru",102],["all-for-kompa.ru",102],["asia-tv.su",102],["at.ua",102],["autosimgames.ru",102],["chernobyl-soul.com",102],["clan.su",102],["cliphq.ru",102],["coop-lands.ru",102],["db-energo.ru",102],["devdrivers.ru",102],["do.am",102],["dtva-it-rus.gq",102],["elegos.ru",102],["elektronika56.ru",102],["elektrosat.ru",102],["fon-ki.com",102],["for-gsm.ru",102],["free-dream.ru",102],["ftechedu.ru",102],["fukushima-news.ru",102],["gals.md",102],["gamesdendy.ru",102],["giginfo.ru",102],["gloria-cedric.ru",102],["goldformat.ru",102],["greenflash.su",102],["hero-empire.com",102],["igrul-ka.ru",102],["jetvis.ru",102],["kinovego.ru",102],["krasnickij.ru",102],["krolmen.ru",102],["megaclips.net",102],["mod-rus.ru",102],["mow-portal.ru",102],["moy.su",102],["mp3songs.ru",102],["mp4android.ru",102],["mrcmirgorod.com.ua",102],["my1.ru",102],["narod.ru",102],["newgames.com.ua",102],["novospasskoe-city.ru",102],["obschestvo-9999.gq",102],["omsimclub.ru",102],["online-supernatural.ru",102],["onlinestargate.ru",102],["only-paper.ru",102],["others.name",102],["pidru4nik.com",102],["pkrc.ru",102],["play-force.ru",102],["pokatushki-pmr.ru",102],["pro-zakupki.ru",102],["project-ss.ru",102],["psxworld.ru",102],["radiodom.org",102],["rocketdockfree.ru",102],["sdr-deluxe.com",102],["skidrowcrack.ru",102],["soft-game.net",102],["stalker-gsc.ru",102],["stalker-zone.info",102],["stalkermods.ru",102],["svadbatomsk.ru",102],["tes-game.ru",102],["torfiles.ru",102],["torm-egan.ru",102],["torrent-file.top",102],["ucoz.club",102],["ucoz.com",102],["ucoz.net",102],["ucoz.org",102],["ucoz.ru",102],["ucoz.ua",102],["usite.pro",102],["vodopads.ru",102],["vsthouse.ru",102],["warcraftda.ru",102],["xakevsoft.ru",102],["xn--80aeshkkbdj.xn--p1ai",102],["yaminecraft.ru",102],["zona-stalkera.ru",102]]);

/******************************************************************************/

const ObjGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const ObjDefineProperty = Object.defineProperty;

const magic =
    String.fromCharCode(Date.now() % 26 + 97) +
    Math.floor(Math.random() * 982451653 + 982451653).toString(36);

const abort = function() {
    throw new ReferenceError(magic);
};

const makeProxy = function(owner, chain) {
    const pos = chain.indexOf('.');
    if ( pos === -1 ) {
        const desc = ObjGetOwnPropertyDescriptor(owner, chain);
        if ( !desc || desc.get !== abort ) {
            ObjDefineProperty(owner, chain, {
                get: abort,
                set: function(){}
            });
        }
        return;
    }

    const prop = chain.slice(0, pos);
    let v = owner[prop];
    chain = chain.slice(pos + 1);
    if ( v ) {
        makeProxy(v, chain);
        return;
    }

    const desc = ObjGetOwnPropertyDescriptor(owner, prop);
    if ( desc && desc.set !== undefined ) { return; }

    ObjDefineProperty(owner, prop, {
        get: function() { return v; },
        set: function(a) {
            v = a;
            if ( a instanceof Object ) {
                makeProxy(a, chain);
            }
        }
    });
};

const scriptlet = (
    chain = ''
) => {
    const owner = window;
    makeProxy(owner, chain);
    const oe = window.onerror;
    window.onerror = function(msg, src, line, col, error) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe(msg, src, line, col, error);
        }
    }.bind();
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

