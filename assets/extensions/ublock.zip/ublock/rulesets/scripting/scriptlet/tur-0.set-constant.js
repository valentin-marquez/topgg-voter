/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name set-constant
/// alias set

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_setConstant() {

/******************************************************************************/

// tur-0

const argsList = [{"a":["adblock.check","noopFunc"]},{"a":["xv_ad_block","0"]},{"a":["tie.ad_blocker_disallow_images_placeholder","undefined"]},{"a":["eazy_ad_unblocker_msg_var","''"]},{"a":["adbEnableForPage","false"]},{"a":["detector_active","true"]},{"a":["adblock_active","false"]},{"a":["adBlockRunning","false"]},{"a":["adb","false"]},{"a":["adBlockEnabled","false"]},{"a":["kan_vars.adblock","undefined"]},{"a":["hasAdblock","false"]},{"a":["AdblockDetector","undefined"]},{"a":["adblockCheckUrl","''"]},{"a":["canRunAds","true"]},{"a":["window.google_jobrunner","true"]},{"a":["jQuery.adblock","false"]},{"a":["$tieE3","true"]},{"a":["koddostu_com_adblock_yok","null"]},{"a":["google_jobrunner","noopFunc"]},{"a":["adsbygoogle.loaded","true"]},{"a":["adblock","false"]},{"a":["ai_adb_detected","noopFunc"]},{"a":["puShown","true"]},{"a":["isShow","true"]},{"a":["loadPlayerAds","trueFunc"]},{"a":["reklamsayisi","0"]},{"a":["player.vroll","noopFunc"]},{"a":["config.adv.enabled","0"]},{"a":["volumeClearInterval","0"]},{"a":["rek_kontrol","noopFunc"]},{"a":["clicked","true"]},{"a":["adSearchTitle","undefined"]},{"a":["Object.prototype.ads","noopFunc"]},{"a":["HBiddings.vastUrl","''"]},{"a":["AdvPlayer","undefined"]},{"a":["_popByHours","undefined"]},{"a":["_pop","undefined"]},{"a":["initOpen","undefined"]},{"a":["initNewAd","noopFunc"]},{"a":["rg","noopFunc"]},{"a":["Object.prototype.ads_enable","false"]},{"a":["td_ad_background_click_link","''"]},{"a":["start","1"]},{"a":["popup","noopFunc"]}];

const hostnamesMap = new Map([["iyibeslenme.net",0],["teknop.net",0],["kirtkirtla.com",0],["buneymis.net",0],["ozgunbilgi.com",0],["exceldepo.com",1],["tgyama.com",2],["uzaymanga.com",3],["e-kitapstore.com",4],["wheel-size.com.tr",5],["karnaval.com",6],["mangaship.net",7],["mangaship.com",7],["miuitr.info",8],["puhutv.com",9],["coinotag.com",10],["cnnturk.com",[11,12]],["kanald.com.tr",[11,13]],["iddaaorantahmin.com",14],["forum.auraroleplay.com",15],["oyungibi.com",16],["veterinerhekimleri.com",16],["unisinav.com",17],["turkdenizcileri.com",18],["bilgalem.blogspot.com",18],["okulsoru.com",18],["tekniknot.com",19],["messletters.com",20],["klavyeanaliz.org",21],["turkeycrack.com",22],["dizirun2.com",23],["kozfilm.com",23],["siyahfilmizle.info",23],["hdfilmhit.org",23],["hdfilmizle.in",23],["dizicaps.org",23],["dizipall.org",23],["diziyou.co",23],["fullhdfilmizle5.net",[23,26]],["filmizlew.net",23],["tafdi.net",23],["fullfilmizle.net",23],["dizimag.eu",23],["erotikfilmler.live",23],["bumfilmizle1.com",23],["yabancidizilertv.com",23],["1080hdfilmizle.com",23],["vipfilmlerizle.me",23],["hdfilmcehennemi.buzz",23],["erotikizle123.com",23],["dipfilmizle.net",23],["erotikizlefilm.com",23],["turkerotikizle.com",23],["yabancidizibax.com",23],["sinemangoo.org",23],["sexfilmleriizle.com",23],["fullhdfilm.pro",[23,26]],["pembetv18.com",23],["geziforumu.com",23],["ddizipal.com",23],["efendim.xyz",23],["dizipaltv.org",23],["dizispeed.net",23],["filmjr1.com",23],["fluffcore.com",23],["filmpaf.com",23],["hdfilmfullizle.com",23],["hdfilmcehennemizle.com",23],["netfullfilmizle3.com",23],["filmmodu.info",23],["izlekolik.com",23],["dizipaltv.com",23],["dizifilm.pro",23],["dizivid.net",23],["arrowizle.com",23],["hdfilmifullizle.com",23],["erotik123.com",23],["jokerfilmizle.com",23],["720pfilmiizle.net",23],["seehdfilm.com",23],["dizirun1.com",23],["filmfiz.net",23],["filmcus.com",23],["hazirfilm.com",23],["filmizlew.org",23],["zoof1.xyz",23],["sinemakolik.net",23],["sinefilmizlesen.com",23],["zarize.com",23],["pornobuna.com",23],["zarizeporno.com",23],["burdenfly.com",23],["diziking.vip",23],["filmdelisi.org",23],["1080pfilmizle.me",23],["zzerotik.com",23],["filmgo.org",23],["filmiifullizlee.net",23],["sinemafilmizle.net",23],["fullhdfilmiizle.org",23],["hdfilmw.org",23],["buzfilmizle1.com",23],["filmkuzusu1.com",23],["hdfilmcix.net",23],["sinemadelisi.com",23],["yetiskinfilmizle.net",23],["hdsexfilmizle.com",23],["erotik-film.org",23],["erotikfilmtube.com",23],["erotik-filmler.net",23],["erotikfilms.net",23],["erotizmfilmleri.net",23],["sezonlukdizi3.com",23],["sezonlukdizi4.com",23],["sezonlukdizi5.com",23],["sezonlukdizi6.com",23],["sezonlukdizi7.com",23],["sezonlukdizi8.com",23],["sezonlukdizi9.com",23],["sezonlukdizi10.com",23],["sezonlukdizi11.com",23],["sezonlukdizi12.com",23],["sezonlukdizi13.com",23],["sezonlukdizi14.com",23],["sezonlukdizi15.com",23],["sezonlukdizi16.com",23],["sezonlukdizi17.com",23],["sezonlukdizi18.com",23],["sezonlukdizi19.com",23],["sezonlukdizi20.com",23],["sezonlukdizi21.com",23],["sezonlukdizi22.com",23],["sezonlukdizi23.com",23],["sezonlukdizi24.com",23],["sezonlukdizi25.com",23],["sezonlukdizi26.com",23],["sezonlukdizi27.com",23],["sezonlukdizi28.com",23],["sezonlukdizi29.com",23],["sezonlukdizi30.com",23],["filmbabasi.com",23],["pornoanne.com",23],["dizikorea.com",23],["koredizileri.tv",23],["diziboxx.com",23],["turkaliz.com",23],["jetdiziizle.net",23],["vkfilmizle.net",23],["dizimom.live",23],["yerlidizi.pw",23],["fullhdfilmizleyin.com",23],["filmizlet.net",23],["baglanfilme.com",23],["filmgooo.com",23],["pornorips.com",23],["bumfilmizle.com",23],["bestdizi.com",23],["shirl.club",23],["evrenselfilmlerim.org",23],["turkcealtyazilipornom.com",23],["sinema.cc",23],["hdfilmizletv.net",23],["filmmom.pro",[23,24]],["torrent-oyun.com",23],["shortz.club",23],["sinemaizle.co",23],["filmlane.com",23],["netfilmtvizle.com",23],["hdfilmcehennem.live",23],["xbox360torrent.com",23],["efullizle.com",23],["morfilmizle.com",23],["asyafanatiklerim.com",23],["guncelhdfilm.com",23],["dizilost.com",23],["fileru.net",23],["dizitube.net",23],["fullhdfilmdeposu.com",23],["volsex.com",23],["torba.info",23],["erotiksexizle.com",23],["divx720pfilmizle.org",23],["dizipal503.com",23],["dizipal504.com",23],["dizipal505.com",23],["dizipal506.com",23],["dizipal507.com",23],["dizipal508.com",23],["dizipal509.com",23],["dizipal510.com",23],["dizipal511.com",23],["dizipal512.com",23],["dizipal513.com",23],["dizipal514.com",23],["dizipal515.com",23],["dizipal516.com",23],["dizipal517.com",23],["dizipal518.com",23],["dizipal519.com",23],["dizipal520.com",23],["dizipal521.com",23],["dizipal522.com",23],["dizipal523.com",23],["dizipal524.com",23],["dizipal525.com",23],["dizipal526.com",23],["dizipal527.com",23],["dizipal528.com",23],["dizipal529.com",23],["dizipal530.com",23],["dizipal531.com",23],["dizipal532.com",23],["dizipal533.com",23],["dizipal534.com",23],["dizipal535.com",23],["dizipal536.com",23],["dizipal537.com",23],["dizipal538.com",23],["dizipal539.com",23],["dizipal540.com",23],["dizipal541.com",23],["dizipal542.com",23],["dizipal543.com",23],["dizipal544.com",23],["dizipal545.com",23],["dizipal546.com",23],["dizipal547.com",23],["dizipal548.com",23],["dizipal549.com",23],["dizipal550.com",23],["dizimom1.com",24],["trgoalshosting.cf",[24,28]],["tekfullfilmizle5.com",24],["yovmiyelazim.com",24],["tekfullfilmizle3.com",24],["izleorg2.org",24],["trgoals185.xyz",24],["trgoals186.xyz",24],["trgoals187.xyz",24],["trgoals188.xyz",24],["trgoals189.xyz",24],["trgoals190.xyz",24],["trgoals191.xyz",24],["trgoals192.xyz",24],["trgoals193.xyz",24],["trgoals194.xyz",24],["trgoals195.xyz",24],["trgoals196.xyz",24],["trgoals197.xyz",24],["trgoals198.xyz",24],["trgoals199.xyz",24],["trgoals200.xyz",24],["trgoals201.xyz",24],["trgoals202.xyz",24],["trgoals203.xyz",24],["trgoals204.xyz",24],["trgoals205.xyz",24],["trgoals206.xyz",24],["trgoals207.xyz",24],["trgoals208.xyz",24],["trgoals209.xyz",24],["trgoals210.xyz",24],["trgoals211.xyz",24],["trgoals212.xyz",24],["trgoals213.xyz",24],["trgoals214.xyz",24],["trgoals215.xyz",24],["trgoals216.xyz",24],["trgoals217.xyz",24],["trgoals218.xyz",24],["trgoals219.xyz",24],["trgoals220.xyz",24],["trgoals221.xyz",24],["trgoals222.xyz",24],["trgoals223.xyz",24],["trgoals224.xyz",24],["trgoals225.xyz",24],["trgoals226.xyz",24],["trgoals227.xyz",24],["trgoals228.xyz",24],["trgoals229.xyz",24],["trgoals230.xyz",24],["trgoals231.xyz",24],["trgoals232.xyz",24],["trgoals233.xyz",24],["trgoals234.xyz",24],["trgoals235.xyz",24],["trgoals236.xyz",24],["trgoals237.xyz",24],["trgoals238.xyz",24],["trgoals239.xyz",24],["trgoals240.xyz",24],["trgoals241.xyz",24],["trgoals242.xyz",24],["trgoals243.xyz",24],["trgoals244.xyz",24],["trgoals245.xyz",24],["trgoals246.xyz",24],["trgoals247.xyz",24],["trgoals248.xyz",24],["trgoals249.xyz",24],["trgoals250.xyz",24],["dizipal73.cloud",24],["dizipal70.cloud",24],["dizipal71.cloud",24],["dizipal72.cloud",24],["dizipal74.cloud",24],["dizipal75.cloud",24],["dizipal76.cloud",24],["dizipal77.cloud",24],["dizipal78.cloud",24],["dizipal79.cloud",24],["dizipal80.cloud",24],["dizipal81.cloud",24],["dizipal82.cloud",24],["dizipal83.cloud",24],["dizipal84.cloud",24],["dizipal85.cloud",24],["dizipal86.cloud",24],["dizipal87.cloud",24],["dizipal88.cloud",24],["dizipal89.cloud",24],["dizipal90.cloud",24],["dizipal91.cloud",24],["dizipal92.cloud",24],["dizipal93.cloud",24],["dizipal94.cloud",24],["dizipal95.cloud",24],["dizipal96.cloud",24],["dizipal97.cloud",24],["dizipal98.cloud",24],["dizipal99.cloud",24],["dizipal100.cloud",24],["dizipal101.cloud",24],["dizipal102.cloud",24],["dizipal103.cloud",24],["dizipal104.cloud",24],["dizipal105.cloud",24],["dizipal106.cloud",24],["dizipal107.cloud",24],["dizipal108.cloud",24],["dizipal109.cloud",24],["dizipal110.cloud",24],["dizipal111.cloud",24],["dizipal112.cloud",24],["dizipal113.cloud",24],["dizipal114.cloud",24],["dizipal115.cloud",24],["dizipal116.cloud",24],["dizipal117.cloud",24],["dizipal118.cloud",24],["dizipal119.cloud",24],["dizipal120.cloud",24],["dizipal121.cloud",24],["dizipal122.cloud",24],["dizipal123.cloud",24],["dizipal124.cloud",24],["dizipal125.cloud",24],["dizipal126.cloud",24],["dizipal127.cloud",24],["dizipal128.cloud",24],["dizipal129.cloud",24],["dizipal130.cloud",24],["dizipal131.cloud",24],["dizipal132.cloud",24],["dizipal133.cloud",24],["dizipal134.cloud",24],["dizipal135.cloud",24],["dizipal136.cloud",24],["dizipal137.cloud",24],["dizipal138.cloud",24],["dizipal139.cloud",24],["dizipal140.cloud",24],["dizipal141.cloud",24],["dizipal142.cloud",24],["dizipal143.cloud",24],["dizipal144.cloud",24],["dizipal145.cloud",24],["dizipal146.cloud",24],["dizipal147.cloud",24],["dizipal148.cloud",24],["dizipal149.cloud",24],["dizipal150.cloud",24],["dizipal151.cloud",24],["dizipal152.cloud",24],["dizipal153.cloud",24],["dizipal154.cloud",24],["dizipal155.cloud",24],["dizipal156.cloud",24],["dizipal157.cloud",24],["dizipal158.cloud",24],["dizipal159.cloud",24],["dizipal160.cloud",24],["dizipal161.cloud",24],["dizipal162.cloud",24],["dizipal163.cloud",24],["dizipal164.cloud",24],["dizipal165.cloud",24],["dizipal166.cloud",24],["dizipal167.cloud",24],["dizipal168.cloud",24],["dizipal169.cloud",24],["dizipal170.cloud",24],["dizipal171.cloud",24],["dizipal172.cloud",24],["dizipal173.cloud",24],["dizipal174.cloud",24],["dizipal175.cloud",24],["dizipal176.cloud",24],["dizipal177.cloud",24],["dizipal178.cloud",24],["dizipal179.cloud",24],["dizipal180.cloud",24],["dizipal181.cloud",24],["dizipal182.cloud",24],["dizipal183.cloud",24],["dizipal184.cloud",24],["dizipal185.cloud",24],["dizipal186.cloud",24],["dizipal187.cloud",24],["dizipal188.cloud",24],["dizipal189.cloud",24],["dizipal190.cloud",24],["dizipal191.cloud",24],["dizipal192.cloud",24],["dizipal193.cloud",24],["dizipal194.cloud",24],["dizipal195.cloud",24],["dizipal196.cloud",24],["dizipal197.cloud",24],["dizipal198.cloud",24],["dizipal199.cloud",24],["dizipal200.cloud",24],["izlesene.com",25],["play.diziyou.co",27],["tranimeci.com",29],["filmmakinesi1.com",30],["turkanime.co",31],["forum.donanimhaber.com",32],["filmmodu9.com",33],["filmmodu10.com",33],["filmmodu11.com",33],["filmmodu12.com",33],["filmmodu13.com",33],["filmmodu14.com",33],["filmmodu15.com",33],["filmmodu16.com",33],["filmmodu17.com",33],["filmmodu18.com",33],["filmmodu19.com",33],["filmmodu20.com",33],["atv.com.tr",34],["turkturk.org",35],["turkturk.net",35],["narcovip.com",[36,37]],["contentx.me",38],["superfilmgeldi.com",39],["edebiyatdefteri.com",40],["belgeselizlesene.com",41],["technopat.net",42],["aydindenge.com.tr",43],["diziall.com",44]]);

/******************************************************************************/

const scriptlet = (
    chain = '',
    cValue = ''
) => {
    if ( chain === '' ) { return; }
    if ( cValue === 'undefined' ) {
        cValue = undefined;
    } else if ( cValue === 'false' ) {
        cValue = false;
    } else if ( cValue === 'true' ) {
        cValue = true;
    } else if ( cValue === 'null' ) {
        cValue = null;
    } else if ( cValue === "''" ) {
        cValue = '';
    } else if ( cValue === '[]' ) {
        cValue = [];
    } else if ( cValue === '{}' ) {
        cValue = {};
    } else if ( cValue === 'noopFunc' ) {
        cValue = function(){};
    } else if ( cValue === 'trueFunc' ) {
        cValue = function(){ return true; };
    } else if ( cValue === 'falseFunc' ) {
        cValue = function(){ return false; };
    } else if ( /^\d+$/.test(cValue) ) {
        cValue = parseFloat(cValue);
        if ( isNaN(cValue) ) { return; }
        if ( Math.abs(cValue) > 0x7FFF ) { return; }
    } else {
        return;
    }
    let aborted = false;
    const mustAbort = function(v) {
        if ( aborted ) { return true; }
        aborted =
            (v !== undefined && v !== null) &&
            (cValue !== undefined && cValue !== null) &&
            (typeof v !== typeof cValue);
        return aborted;
    };
    // https://github.com/uBlockOrigin/uBlock-issues/issues/156
    //   Support multiple trappers for the same property.
    const trapProp = function(owner, prop, configurable, handler) {
        if ( handler.init(owner[prop]) === false ) { return; }
        const odesc = Object.getOwnPropertyDescriptor(owner, prop);
        let prevGetter, prevSetter;
        if ( odesc instanceof Object ) {
            owner[prop] = cValue;
            if ( odesc.get instanceof Function ) {
                prevGetter = odesc.get;
            }
            if ( odesc.set instanceof Function ) {
                prevSetter = odesc.set;
            }
        }
        try {
            Object.defineProperty(owner, prop, {
                configurable,
                get() {
                    if ( prevGetter !== undefined ) {
                        prevGetter();
                    }
                    return handler.getter(); // cValue
                },
                set(a) {
                    if ( prevSetter !== undefined ) {
                        prevSetter(a);
                    }
                    handler.setter(a);
                }
            });
        } catch(ex) {
        }
    };
    const trapChain = function(owner, chain) {
        const pos = chain.indexOf('.');
        if ( pos === -1 ) {
            trapProp(owner, chain, false, {
                v: undefined,
                init: function(v) {
                    if ( mustAbort(v) ) { return false; }
                    this.v = v;
                    return true;
                },
                getter: function() {
                    return cValue;
                },
                setter: function(a) {
                    if ( mustAbort(a) === false ) { return; }
                    cValue = a;
                }
            });
            return;
        }
        const prop = chain.slice(0, pos);
        const v = owner[prop];
        chain = chain.slice(pos + 1);
        if ( v instanceof Object || typeof v === 'object' && v !== null ) {
            trapChain(v, chain);
            return;
        }
        trapProp(owner, prop, true, {
            v: undefined,
            init: function(v) {
                this.v = v;
                return true;
            },
            getter: function() {
                return this.v;
            },
            setter: function(a) {
                this.v = a;
                if ( a instanceof Object ) {
                    trapChain(a, chain);
                }
            }
        });
    };
    trapChain(window, chain);
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
