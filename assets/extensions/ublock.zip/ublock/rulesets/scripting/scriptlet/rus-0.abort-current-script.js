/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-current-script
/// alias acs
/// alias abort-current-inline-script
/// alias acis

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortCurrentScript() {

/******************************************************************************/

// rus-0

const argsList = [{"a":["$","1xbet"]},{"a":["$","append"]},{"a":["$","contextmenu"]},{"a":["$","divWrapper"]},{"a":["$","get"]},{"a":["$","init_x_place"]},{"a":["$","mainContainer"]},{"a":["$","showPopupextra"]},{"a":["JSON.parse"]},{"a":["JSON.parse","atob"]},{"a":["Math.floor","adregain_wall"]},{"a":["Math.random"]},{"a":["Object.defineProperty","rcBuf"]},{"a":["String.fromCharCode","var _0x"]},{"a":["XMLHttpRequest","document.querySelectorAll"]},{"a":["__require","/clickunder/"]},{"a":["addEventListener","DOMContentLoaded"],"n":["new.fastpic.org"]},{"a":["atob","void"]},{"a":["clickExplorer"]},{"a":["decodeURIComponent","/63cc63/"]},{"a":["decodeURIComponent","fromCharCode"]},{"a":["decodeURIComponent","getAdBlockStatus"]},{"a":["disableSelection","reEnable"]},{"a":["document.addEventListener","adsBlocked"]},{"a":["document.createElement"]},{"a":["document.createElement","/ru-n4p|ua-n4p|загрузка.../"]},{"a":["document.createElement","ExternalChromePop"]},{"a":["document.createElement","Math.random"],"n":["new.fastpic.org"]},{"a":["document.createElement","atob"]},{"a":["document.createElement","delete window"]},{"a":["document.getElementsByTagName","unselectable"]},{"a":["document.oncontextmenu"]},{"a":["document.onkeydown"]},{"a":["document.querySelector","/banner/"]},{"a":["document.querySelector","click"]},{"a":["encodeURIComponent","rcBuf"]},{"a":["fuckAdBlock","undefined"]},{"a":["jQuery","backgroundImage"]},{"a":["redram","/загрузка.../"]},{"a":["setInterval","reload"]},{"a":["setTimeout","adblockwarn"]},{"a":["Math.floor","AdSense"]},{"a":["document.getElementById","composedPath"]},{"a":["document.querySelectorAll","popMagic"]},{"a":["$","blockWarnClass"]},{"a":["$","mimicTopClass"]},{"a":["dispatchEvent","zoomdecorate"]}];

const hostnamesMap = new Map([["shaiba.kz",0],["budport.com.ua",1],["asn.in.ua",2],["penzainform.ru",3],["l2top.ru",4],["tut.by",5],["conversion.im",6],["bez-smenki.ru",7],["freescreens.ru",8],["imgbase.ru",8],["imgcach.ru",8],["imgclick.ru",8],["payforpic.ru",8],["picclick.ru",8],["picclock.ru",8],["picforall.ru",8],["fenglish.site",9],["mp3spy.cc",9],["electric-house.ru",10],["euro-football.ru",10],["forums.rusmedserv.com",10],["liveresult.ru",10],["smolensk-auto.ru",10],["smolensk-auto.site",10],["stroi-help.ru",10],["tenews.org.ua",[11,25]],["agroreview.com",[12,35]],["dc-marvel.org",13],["gidonline.eu",13],["filmisub.com",[14,20]],["kinofen.net",[14,20]],["gdespaces.com",15],["gdespaces.net",15],["google-cloud.services",15],["spac.me",15],["spac1.com",15],["spac1.info",15],["spac1.me",15],["spac1.net",15],["spac1.org",15],["spac1.ru",15],["spaces-blogs.com",15],["spaces.im",15],["spcs.global",15],["spcs.life",15],["spcs.me",15],["spcs.news",15],["spcs.pro",15],["spcs.pub",15],["spcs.social",15],["strip2.in",15],["strip2.xxx",15],["usersporn.com",15],["fastpic.org",[16,27]],["allboxing.ru",17],["pravvest.ru",18],["daz3d.ru",19],["dynamo.kiev.ua",[21,33]],["epravda.com.ua",[21,33]],["football.ua",[21,33]],["isport.ua",[21,33]],["liga.net",[21,25,33]],["pravda.com.ua",[21,33]],["www.i.ua",[21,33]],["my-expert.ru",[22,30,31]],["mod-wot.ru",23],["krolik.biz",24],["1news.com.ua",25],["365news.biz",25],["4mama.ua",25],["4studio.com.ua",25],["7days-ua.com",25],["agroter.com.ua",25],["alter-science.info",25],["apnews.com.ua",25],["argumentiru.com",25],["asiaplustj.info",25],["autotema.org.ua",25],["autotheme.info",25],["avtodream.org",25],["beauty.ua",25],["begemot-media.com",25],["begemot.media",25],["chas.cv.ua",25],["cheline.com.ua",25],["cikavosti.com",25],["ck.ua",25],["cn.ua",25],["comments.ua",25],["cvnews.cv.ua",25],["day.kyiv.ua",25],["depo.ua",25],["dnews.dn.ua",25],["dv-gazeta.info",25],["dyvys.info",25],["economistua.com",25],["edinstvennaya.ua",25],["ekovolga.com",25],["expert.in.ua",25],["fedpress.ru",25],["firtka.if.ua",25],["forpost.media",25],["fraza.com",25],["gazeta1.com",25],["glavnoe.ua",25],["glavnoe24.ru",25],["glavpost.ua",25],["golosinfo.com.ua",25],["gorodkiev.com.ua",25],["gov.ua",25],["grad.ua",25],["greenpost.ua",25],["ifnews.org.ua",25],["inforpost.com",25],["inkorr.com",25],["itechua.com",25],["iz.com.ua",25],["kh.ua",25],["khersonline.net",25],["kolizhanka.com.ua",25],["kop.net.ua",25],["kr.ua",25],["krymr.com",25],["kurskcity.ru",25],["lvnews.org.ua",25],["mega-music.pro",25],["mi100.info",25],["mignews.com.ua",25],["mind.ua",25],["moirebenok.ua",25],["mycompplus.ru",25],["nakanune.ru",25],["narodna-pravda.ua",25],["nashbryansk.ru",25],["news24today.info",25],["newsua.one",25],["ngp-ua.info",25],["nnews.com.ua",25],["novavlada.info",25],["novynarnia.com",25],["np.pl.ua",25],["odessa-life.od.ua",25],["ogo.ua",25],["oukr.info",25],["panoptikon.org",25],["pg11.ru",25],["pik.net.ua",25],["pingvin.pro",25],["pl.com.ua",25],["planetanovosti.com",25],["podpricelom.com.ua",25],["politnavigator.net",25],["poltava365.com",25],["portal.lviv.ua",25],["praktika-vlasti.com.ua",25],["prm.ua",25],["procherk.info",25],["profootball.ua",25],["promin.cv.ua",25],["radiosvoboda.org",25],["ratel.kz",25],["real-vin.com",25],["reporter.ua",25],["risu.ua",25],["rivne.media",25],["rivnenews.com.ua",25],["rusjev.net",25],["russianshowbiz.info",25],["rv.ua",25],["rvnews.rv.ua",25],["semobile.com.ua",25],["showdream.org",25],["sport-kr.com.ua",25],["strana.news",25],["strana.today",25],["sud.ua",25],["te.ua",25],["telekritika.ua",25],["theageoffootball.com",25],["treebuna.info",25],["tverigrad.ru",25],["tverisport.ru",25],["tvoymalysh.com.ua",25],["uainfo.org",25],["uanews.org.ua",25],["uatv.ua",25],["ukranews.com",25],["ukrrain.com",25],["unn.com.ua",25],["vchaspik.ua",25],["versii.if.ua",25],["viva.ua",25],["vlast.kz",25],["vnn24.ru",25],["volnorez.com.ua",25],["volyninfa.com.ua",25],["volyninfo.com",25],["volynpost.com",25],["volynua.com",25],["vsviti.com.ua",25],["westnews.info",25],["womo.ua",25],["wworld.com.ua",25],["zbirna.com",25],["zp.ua",25],["rutor.in",26],["karpatnews.in.ua",27],["kaztorka.org",27],["kg-portal.ru",27],["nnm-club.lib",27],["nnm-club.me",27],["nnmclub.ro",27],["nnmclub.to",27],["shanson320.ru",28],["vesti.ua",28],["lrepacks.net",29],["brigadtv.ru",31],["castle-serial.ru",31],["ehlita.ru",31],["gameout.ru",31],["itevonklass.ru",31],["izmailovtv.xyz",31],["karateltv.ru",31],["lyucifer.tv",31],["m-z.tv",31],["pokazuha.ru",31],["samomdele.tv",31],["saske.tv",31],["sorvigolovatv.ru",31],["taynyeistiny.ru",31],["transformator220.ru",31],["stalker-mods.clan.su",32],["stalker-mods.su",32],["2ip.ua",34],["gwss.ru",36],["hardwareluxx.ru",37],["marieclaire.ua",38],["24boxing.com.ua",39],["bilshe.com",39],["businessua.com",39],["f1analytic.com",39],["football-ukraine.com",39],["footballgazeta.com",39],["footballtransfer.com.ua",39],["glianec.com",39],["nashamama.com",39],["sportanalytic.com",39],["stravy.net",39],["zdorovia.com.ua",39],["livesport.ws",40],["dmod.cc",41],["draug.ru",41],["modsforwot.ru",41],["skam.online",42],["pornopuk.com",43],["huyamba.tv",43],["piratam.net",43],["piratca.net",43],["porn720.biz",43],["sexitorrent.com",43],["sextor.org",43],["domahatv.com",43],["torrent-pirat.com",43],["xtorrent.net",43],["rapidzona.tv",43],["xxxrip.net",43],["xxxtor.com",43],["hentai-share.one",43],["minigames.mail.ru",44],["mmminigames.mail.ru",45],["afisha.ru",46],["autorambler.ru",46],["championat.com",46],["eda.ru",46],["gazeta.ru",46],["lenta.ru",46],["letidor.ru",46],["moslenta.ru",46],["motor.ru",46],["passion.ru",46],["quto.ru",46],["rambler.ru",46],["wmj.ru",46]]);

/******************************************************************************/

// Issues to mind before changing anything:
//  https://github.com/uBlockOrigin/uBlock-issues/issues/2154

const scriptlet = (
    target = '',
    needle = '',
    context = ''
) => {
    if ( target === '' ) { return; }
    const reRegexEscape = /[.*+?^${}()|[\]\\]/g;
    const reNeedle = (( ) => {
        if ( needle === '' ) { return /^/; }
        if ( /^\/.+\/$/.test(needle) ) {
            return new RegExp(needle.slice(1,-1));
        }
        return new RegExp(needle.replace(reRegexEscape, '\\$&'));
    })();
    const reContext = (( ) => {
        if ( context === '' ) { return; }
        if ( /^\/.+\/$/.test(context) ) {
            return new RegExp(context.slice(1,-1));
        }
        return new RegExp(context.replace(reRegexEscape, '\\$&'));
    })();
    const chain = target.split('.');
    let owner = window;
    let prop;
    for (;;) {
        prop = chain.shift();
        if ( chain.length === 0 ) { break; }
        owner = owner[prop];
        if ( owner instanceof Object === false ) { return; }
    }
    let value;
    let desc = Object.getOwnPropertyDescriptor(owner, prop);
    if (
        desc instanceof Object === false ||
        desc.get instanceof Function === false
    ) {
        value = owner[prop];
        desc = undefined;
    }
    const magic = String.fromCharCode(Date.now() % 26 + 97) +
                  Math.floor(Math.random() * 982451653 + 982451653).toString(36);
    const scriptTexts = new WeakMap();
    const getScriptText = elem => {
        let text = elem.textContent;
        if ( text.trim() !== '' ) { return text; }
        if ( scriptTexts.has(elem) ) { return scriptTexts.get(elem); }
        const [ , mime, content ] =
            /^data:([^,]*),(.+)$/.exec(elem.src.trim()) ||
            [ '', '', '' ];
        try {
            switch ( true ) {
            case mime.endsWith(';base64'):
                text = self.atob(content);
                break;
            default:
                text = self.decodeURIComponent(content);
                break;
            }
        } catch(ex) {
        }
        scriptTexts.set(elem, text);
        return text;
    };
    const validate = ( ) => {
        const e = document.currentScript;
        if ( e instanceof HTMLScriptElement === false ) { return; }
        if ( reContext !== undefined && reContext.test(e.src) === false ) {
            return;
        }
        if ( reNeedle.test(getScriptText(e)) === false ) { return; }
        throw new ReferenceError(magic);
    };
    Object.defineProperty(owner, prop, {
        get: function() {
            validate();
            return desc instanceof Object
                ? desc.get.call(owner)
                : value;
        },
        set: function(a) {
            validate();
            if ( desc instanceof Object ) {
                desc.set.call(owner, a);
            } else {
                value = a;
            }
        }
    });
    const oe = window.onerror;
    window.onerror = function(msg) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe.apply(this, arguments);
        }
    }.bind();
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
