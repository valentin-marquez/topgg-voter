/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name set-constant
/// alias set

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_setConstant() {

/******************************************************************************/

// rus-0

const argsList = [{"a":["Object.prototype.changeVisible","noopFunc"]},{"a":["ADV_BLOCKED","false"]},{"a":["JSON.parse","noopFunc"]},{"a":["Object.prototype.AdvObject","noopFunc"]},{"a":["Object.prototype.AdvertisementManager","undefined"]},{"a":["Object.prototype.IS_CHECK_REGISTRATION","false"]},{"a":["Object.prototype.MediaReady","noopFunc"]},{"a":["Object.prototype.PLAYED","null"]},{"a":["Object.prototype.adUsageStorageVars","undefined"]},{"a":["Object.prototype.adblockSettings","undefined"]},{"a":["Object.prototype.advertObject","null"]},{"a":["Object.prototype.afg","true"]},{"a":["Object.prototype.autoPlay","false"]},{"a":["Object.prototype.autoPlay","null"]},{"a":["Object.prototype.autoplay","false"]},{"a":["Object.prototype.autoplay","null"],"n":["1yar.tv"]},{"a":["Object.prototype.autostart","noopFunc"]},{"a":["Object.prototype.compactMode","true"]},{"a":["Object.prototype.createBannerItem","null"]},{"a":["Object.prototype.detectAdblock","noopFunc"]},{"a":["Object.prototype.disableAutoplay","true"]},{"a":["Object.prototype.disablePaste","false"]},{"a":["Object.prototype.disableSeek","noopFunc"]},{"a":["Object.prototype.disableSelection","noopFunc"]},{"a":["Object.prototype.getAutoplay","noopFunc"]},{"a":["Object.prototype.hideab","undefined"]},{"a":["Object.prototype.livetv-state","true"]},{"a":["Object.prototype.manualAutoplay_","null"]},{"a":["Object.prototype.minPlayingVisibleHeight","noopFunc"]},{"a":["Object.prototype.openstatCb","undefined"]},{"a":["Object.prototype.playVideo","noopFunc"]},{"a":["Object.prototype.sendCHParams","noopFunc"]},{"a":["Object.prototype.videoAd","noopFunc"]},{"a":["String.fromCharCode","trueFunc"]},{"a":["accept18","true"]},{"a":["adBlock","false"]},{"a":["adBlockEnabled","false"]},{"a":["adblock","true"]},{"a":["app.book.external","null"]},{"a":["clicks","2"]},{"a":["g_GazetaNoExchange","true"]},{"a":["home.export.complex-feed","undefined"]},{"a":["isAdFree","noopFunc"]},{"a":["localStorage.localstorageGameData","''"]},{"a":["main_air_closed","true"]},{"a":["pl.getParams.isPlay","null"]},{"a":["player.options.scroll","false"]},{"a":["playerOptions.behaviour.autoPlay","false"]},{"a":["sectionConfig.adBlock","null"]},{"a":["timeEnd","1"]},{"a":["top100Counter","false"]},{"a":["window.EUMP.plugins.antiblock","noopFunc"]},{"a":["window.ab","false"]},{"a":["NO_ADV","1"]},{"a":["Object.prototype.ENABLE_SMOKESCREEN","undefined"]},{"a":["Object.prototype._Mimic","undefined"]},{"a":["Object.prototype.adblock","null"],"n":["3igames.mail.ru","auto.mail.ru","biz.mail.ru","bonus.mail.ru","calendar.mail.ru","calls.mail.ru","cloud.mail.ru","deti.mail.ru","dobro.mail.ru","e.mail.ru","esports.mail.ru","games.mail.ru","gibdd.mail.ru","go.mail.ru","health.mail.ru","help.mail.ru","hi-tech.mail.ru","horo.mail.ru","kino.mail.ru","lady.mail.ru","love.mail.ru","mailblog.mail.ru","mcs.mail.ru","minigames.mail.ru","my.mail.ru","news.mail.ru","octavius.mail.ru","okminigames.mail.ru","otvet.mail.ru","pets.mail.ru","player-smotri.mail.ru","pogoda.mail.ru","realty.mail.ru","top.mail.ru","touch.mail.ru","tv.mail.ru"]},{"a":["Object.prototype.adsRectangle","undefined"],"n":["3igames.mail.ru","auto.mail.ru","biz.mail.ru","bonus.mail.ru","calendar.mail.ru","calls.mail.ru","cloud.mail.ru","deti.mail.ru","dobro.mail.ru","e.mail.ru","esports.mail.ru","games.mail.ru","gibdd.mail.ru","go.mail.ru","health.mail.ru","help.mail.ru","hi-tech.mail.ru","horo.mail.ru","kino.mail.ru","lady.mail.ru","love.mail.ru","mailblog.mail.ru","mcs.mail.ru","minigames.mail.ru","my.mail.ru","news.mail.ru","octavius.mail.ru","okminigames.mail.ru","otvet.mail.ru","pets.mail.ru","player-smotri.mail.ru","pogoda.mail.ru","realty.mail.ru","top.mail.ru","touch.mail.ru","tv.mail.ru"]},{"a":["Object.prototype.autoPlayParams","false"]},{"a":["Object.prototype.autoplayScrollHandler","noopFunc"]},{"a":["Object.prototype.getAds","undefined"]},{"a":["Object.prototype.mimic","undefined"],"n":["calls.mail.ru","e.mail.ru","my.mail.ru","octavius.mail.ru","touch.mail.ru"]},{"a":["Object.prototype.onLinkClick","noopFunc"]},{"a":["Object.prototype.onLinkMouseDown","noopFunc"]},{"a":["Object.prototype.runMimic","noopFunc"]},{"a":["Object.prototype.useMimic","noopFunc"]},{"a":["document.title","null"],"n":["3igames.mail.ru","auto.mail.ru","biz.mail.ru","bonus.mail.ru","calendar.mail.ru","calls.mail.ru","cloud.mail.ru","deti.mail.ru","dobro.mail.ru","e.mail.ru","esports.mail.ru","games.mail.ru","gibdd.mail.ru","go.mail.ru","health.mail.ru","help.mail.ru","hi-tech.mail.ru","horo.mail.ru","kino.mail.ru","lady.mail.ru","love.mail.ru","mailblog.mail.ru","mcs.mail.ru","minigames.mail.ru","my.mail.ru","news.mail.ru","octavius.mail.ru","okminigames.mail.ru","otvet.mail.ru","pets.mail.ru","player-smotri.mail.ru","pogoda.mail.ru","realty.mail.ru","top.mail.ru","touch.mail.ru","tv.mail.ru"]},{"a":["String.prototype.charCodeAt","trueFunc"],"n":["passport.i.ua","pinformer.sinoptik.ua"]},{"a":["Object.prototype.AdvertisingManager","noopFunc"]}];

const hostnamesMap = new Map([["116.ru",0],["14.ru",0],["161.ru",0],["164.ru",0],["178.ru",0],["26.ru",0],["29.ru",0],["35.ru",0],["43.ru",0],["45.ru",0],["48.ru",0],["51.ru",0],["53.ru",0],["56.ru",0],["59.ru",0],["60.ru",0],["62.ru",0],["63.ru",0],["68.ru",0],["71.ru",0],["72.ru",0],["74.ru",0],["76.ru",0],["86.ru",0],["89.ru",0],["93.ru",0],["chita.ru",0],["e1.ru",0],["fontanka.ru",0],["ircity.ru",0],["mgorsk.ru",0],["msk1.ru",0],["ngs.ru",0],["ngs22.ru",0],["ngs24.ru",0],["ngs42.ru",0],["ngs55.ru",0],["ngs70.ru",0],["nn.ru",0],["proizhevsk.ru",0],["provoronezh.ru",0],["sochi1.ru",0],["sterlitamak1.ru",0],["tolyatty.ru",0],["ufa1.ru",0],["v1.ru",0],["7days.ru",0],["doctorpiter.ru",0],["dom.mail.ru",0],["kp.kg",0],["kp.kz",0],["kp.md",0],["kp.ru",0],["lady.mail.ru",0],["mk.ru",0],["radiokp.ru",0],["spletnik.ru",0],["wday.ru",0],["woman.ru",0],["peers.tv",1],["animelend.info",2],["ivi.ru",[3,10]],["changeua.com",4],["ictv.ua",4],["inter.ua",4],["k1.ua",4],["novy.tv",4],["ntn.ua",4],["starlight.digital",4],["stb.ua",4],["teleportal.ua",4],["player.vgtrk.com",5],["tv-gubernia.ru",[6,44]],["xsport.ua",7],["music.yandex.by",8],["music.yandex.kz",8],["music.yandex.ru",8],["music.yandex.uz",8],["api-video.khl.ru",9],["igroutka.ru",11],["cdnvideo.ru",12],["eda.ru",12],["mania.gcdn.co",12],["vp.rambler.ru",[12,28]],["www.rambler.ru",12],["afisha.ru",13],["iz.ru",14],["bonus-tv.ru",15],["eagleplatform.com",[15,46]],["embed.dugout.com",16],["tass.ru",17],["ati.su",18],["examenpdd.com",19],["embed.twitch.tv",20],["player.twitch.tv",20],["www.mos.ru",21],["1tv.ru",[22,51]],["kinokong.pro",23],["dzen.ru",24],["tortuga.wtf",25],["rbc.ru",26],["sportrbc.ru",26],["tenews.org.ua",27],["rg.ru",29],["3dnews.kz",30],["3dnews.ru",30],["vm.ru",30],["gismeteo.by",31],["gismeteo.kz",31],["gismeteo.lt",31],["gismeteo.lv",31],["gismeteo.md",31],["gismeteo.ru",31],["gismeteo.ua",[31,67]],["frontend.vh.yandex.ru",32],["widgets.kinopoisk.ru",32],["yastatic.net",32],["free-tor.info",33],["korsars.info",33],["vo-dela.su",34],["hentai-share.one",35],["libertycity.ru",36],["anidub.vip",37],["anidubonline.com",37],["loveanime.live",37],["gdz-putina.fun",38],["gdz.ninja",38],["gdz.ru",38],["gdzotputina.club",38],["gdzputina.net",38],["megaresheba.com",38],["megaresheba.ru",38],["resheba.me",38],["spishi.fun",38],["zoobrilka.net",38],["audioportal.su",39],["gazeta.ru",[40,42]],["ya.ru",41],["playground.ru",43],["player.smotrim.ru",45],["kinescope.io",47],["apollo.lv",48],["tvnet.lv",48],["softportal.com",49],["rambler.ru",50],["remont-aud.net",52],["okminigames.mail.ru",53],["e.mail.ru",[54,62,63]],["octavius.mail.ru",[54,62,63]],["otvet.mail.ru",55],["mail.ru",[56,57,61,66]],["player-smotri.mail.ru",58],["ok.ru",[59,60]],["sportmail.ru",[61,65]],["my.mail.ru",64],["news.mail.ru",65],["pogoda.mail.ru",65],["4mama.ua",67],["avtovod.com.ua",67],["beauty.ua",67],["bilshe.com",67],["buhgalter.com.ua",67],["buhgalter911.com",67],["dengi.ua",67],["ditey.com",67],["epravda.com.ua",67],["eurointegration.com.ua",67],["facenews.ua",67],["factor.ua",67],["football24.ua",67],["gorod.dp.ua",67],["hvylya.net",67],["inforesist.org",67],["internetua.com",67],["isport.ua",67],["ivona.ua",67],["kolobok.ua",67],["kriminal.tv",67],["kurs.com.ua",67],["mama.ua",67],["meteo.ua",67],["mport.ua",67],["nnovosti.info",67],["okino.ua",67],["orakul.com",67],["panno4ka.net",67],["pogodaua.com",67],["pravda.com.ua",67],["real-vin.com",67],["sinoptik.ua",67],["smak.ua",67],["stravy.net",67],["tochka.net",67],["tv.ua",67],["tvoymalysh.com.ua",67],["udoktora.net",67],["viva.ua",67],["vsetv.com",67],["www.bigmir.net",67],["mail.ukr.net",68]]);

/******************************************************************************/

const scriptlet = (
    chain = '',
    cValue = ''
) => {
    if ( chain === '' ) { return; }
    if ( cValue === 'undefined' ) {
        cValue = undefined;
    } else if ( cValue === 'false' ) {
        cValue = false;
    } else if ( cValue === 'true' ) {
        cValue = true;
    } else if ( cValue === 'null' ) {
        cValue = null;
    } else if ( cValue === "''" ) {
        cValue = '';
    } else if ( cValue === '[]' ) {
        cValue = [];
    } else if ( cValue === '{}' ) {
        cValue = {};
    } else if ( cValue === 'noopFunc' ) {
        cValue = function(){};
    } else if ( cValue === 'trueFunc' ) {
        cValue = function(){ return true; };
    } else if ( cValue === 'falseFunc' ) {
        cValue = function(){ return false; };
    } else if ( /^\d+$/.test(cValue) ) {
        cValue = parseFloat(cValue);
        if ( isNaN(cValue) ) { return; }
        if ( Math.abs(cValue) > 0x7FFF ) { return; }
    } else {
        return;
    }
    let aborted = false;
    const mustAbort = function(v) {
        if ( aborted ) { return true; }
        aborted =
            (v !== undefined && v !== null) &&
            (cValue !== undefined && cValue !== null) &&
            (typeof v !== typeof cValue);
        return aborted;
    };
    // https://github.com/uBlockOrigin/uBlock-issues/issues/156
    //   Support multiple trappers for the same property.
    const trapProp = function(owner, prop, configurable, handler) {
        if ( handler.init(owner[prop]) === false ) { return; }
        const odesc = Object.getOwnPropertyDescriptor(owner, prop);
        let prevGetter, prevSetter;
        if ( odesc instanceof Object ) {
            owner[prop] = cValue;
            if ( odesc.get instanceof Function ) {
                prevGetter = odesc.get;
            }
            if ( odesc.set instanceof Function ) {
                prevSetter = odesc.set;
            }
        }
        try {
            Object.defineProperty(owner, prop, {
                configurable,
                get() {
                    if ( prevGetter !== undefined ) {
                        prevGetter();
                    }
                    return handler.getter(); // cValue
                },
                set(a) {
                    if ( prevSetter !== undefined ) {
                        prevSetter(a);
                    }
                    handler.setter(a);
                }
            });
        } catch(ex) {
        }
    };
    const trapChain = function(owner, chain) {
        const pos = chain.indexOf('.');
        if ( pos === -1 ) {
            trapProp(owner, chain, false, {
                v: undefined,
                init: function(v) {
                    if ( mustAbort(v) ) { return false; }
                    this.v = v;
                    return true;
                },
                getter: function() {
                    return cValue;
                },
                setter: function(a) {
                    if ( mustAbort(a) === false ) { return; }
                    cValue = a;
                }
            });
            return;
        }
        const prop = chain.slice(0, pos);
        const v = owner[prop];
        chain = chain.slice(pos + 1);
        if ( v instanceof Object || typeof v === 'object' && v !== null ) {
            trapChain(v, chain);
            return;
        }
        trapProp(owner, prop, true, {
            v: undefined,
            init: function(v) {
                this.v = v;
                return true;
            },
            getter: function() {
                return this.v;
            },
            setter: function(a) {
                this.v = a;
                if ( a instanceof Object ) {
                    trapChain(a, chain);
                }
            }
        });
    };
    trapChain(window, chain);
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
