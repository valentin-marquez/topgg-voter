/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-fetch-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noFetchIf() {

/******************************************************************************/

// tur-0

const argsList = [{"a":["/assets/js/prebid"]},{"a":["www3.doubleclick.net"]},{"a":["pagead2.googlesyndication.com"]}];

const hostnamesMap = new Map([["sozcu.com.tr",0],["bikifi.com",1],["puhutv.com",[1,2]],["ogznet.com",2],["discordsunucu.com",2],["boxofficeturkiye.com",2],["nedir.org",2],["dizipal1.cloud",2],["dizipal2.cloud",2],["dizipal3.cloud",2],["dizipal4.cloud",2],["dizipal5.cloud",2],["dizipal6.cloud",2],["dizipal7.cloud",2],["dizipal8.cloud",2],["dizipal9.cloud",2],["dizipal10.cloud",2],["dizipal11.cloud",2],["dizipal12.cloud",2],["dizipal13.cloud",2],["dizipal14.cloud",2],["dizipal15.cloud",2],["dizipal16.cloud",2],["dizipal17.cloud",2],["dizipal18.cloud",2],["dizipal19.cloud",2],["dizipal20.cloud",2],["dizipal21.cloud",2],["dizipal22.cloud",2],["dizipal23.cloud",2],["dizipal24.cloud",2],["dizipal25.cloud",2],["dizipal26.cloud",2],["dizipal27.cloud",2],["dizipal28.cloud",2],["dizipal29.cloud",2],["dizipal30.cloud",2],["dizipal31.cloud",2],["dizipal32.cloud",2],["dizipal33.cloud",2],["dizipal34.cloud",2],["dizipal35.cloud",2],["dizipal36.cloud",2],["dizipal37.cloud",2],["dizipal38.cloud",2],["dizipal39.cloud",2],["dizipal40.cloud",2],["dizipal41.cloud",2],["dizipal42.cloud",2],["dizipal43.cloud",2],["dizipal44.cloud",2],["dizipal45.cloud",2],["dizipal46.cloud",2],["dizipal47.cloud",2],["dizipal48.cloud",2],["dizipal49.cloud",2],["dizipal50.cloud",2],["dizipal51.cloud",2],["dizipal52.cloud",2],["dizipal53.cloud",2],["dizipal54.cloud",2],["dizipal55.cloud",2],["dizipal56.cloud",2],["dizipal57.cloud",2],["dizipal58.cloud",2],["dizipal59.cloud",2],["dizipal60.cloud",2],["dizipal61.cloud",2],["dizipal62.cloud",2],["dizipal63.cloud",2],["dizipal64.cloud",2],["dizipal65.cloud",2],["dizipal66.cloud",2],["dizipal67.cloud",2],["dizipal68.cloud",2],["dizipal69.cloud",2],["dizipal70.cloud",2],["dizipal71.cloud",2],["dizipal72.cloud",2],["dizipal73.cloud",2],["dizipal74.cloud",2],["dizipal75.cloud",2],["dizipal76.cloud",2],["dizipal77.cloud",2],["dizipal78.cloud",2],["dizipal79.cloud",2],["dizipal80.cloud",2],["dizipal81.cloud",2],["dizipal82.cloud",2],["dizipal83.cloud",2],["dizipal84.cloud",2],["dizipal85.cloud",2],["dizipal86.cloud",2],["dizipal87.cloud",2],["dizipal88.cloud",2],["dizipal89.cloud",2],["dizipal90.cloud",2],["dizipal91.cloud",2],["dizipal92.cloud",2],["dizipal93.cloud",2],["dizipal94.cloud",2],["dizipal95.cloud",2],["dizipal96.cloud",2],["dizipal97.cloud",2],["dizipal98.cloud",2],["dizipal99.cloud",2],["dizipal100.cloud",2],["dizipal101.cloud",2],["dizipal102.cloud",2],["dizipal103.cloud",2],["dizipal104.cloud",2],["dizipal105.cloud",2],["dizipal106.cloud",2],["dizipal107.cloud",2],["dizipal108.cloud",2],["dizipal109.cloud",2],["dizipal110.cloud",2],["dizipal111.cloud",2],["dizipal112.cloud",2],["dizipal113.cloud",2],["dizipal114.cloud",2],["dizipal115.cloud",2],["dizipal116.cloud",2],["dizipal117.cloud",2],["dizipal118.cloud",2],["dizipal119.cloud",2],["dizipal120.cloud",2],["dizipal121.cloud",2],["dizipal122.cloud",2],["dizipal123.cloud",2],["dizipal124.cloud",2],["dizipal125.cloud",2],["dizipal126.cloud",2],["dizipal127.cloud",2],["dizipal128.cloud",2],["dizipal129.cloud",2],["dizipal130.cloud",2],["dizipal131.cloud",2],["dizipal132.cloud",2],["dizipal133.cloud",2],["dizipal134.cloud",2],["dizipal135.cloud",2],["dizipal136.cloud",2],["dizipal137.cloud",2],["dizipal138.cloud",2],["dizipal139.cloud",2],["dizipal140.cloud",2],["dizipal141.cloud",2],["dizipal142.cloud",2],["dizipal143.cloud",2],["dizipal144.cloud",2],["dizipal145.cloud",2],["dizipal146.cloud",2],["dizipal147.cloud",2],["dizipal148.cloud",2],["dizipal149.cloud",2],["dizipal150.cloud",2],["dizipal151.cloud",2],["dizipal152.cloud",2],["dizipal153.cloud",2],["dizipal154.cloud",2],["dizipal155.cloud",2],["dizipal156.cloud",2],["dizipal157.cloud",2],["dizipal158.cloud",2],["dizipal159.cloud",2],["dizipal160.cloud",2],["dizipal161.cloud",2],["dizipal162.cloud",2],["dizipal163.cloud",2],["dizipal164.cloud",2],["dizipal165.cloud",2],["dizipal166.cloud",2],["dizipal167.cloud",2],["dizipal168.cloud",2],["dizipal169.cloud",2],["dizipal170.cloud",2],["dizipal171.cloud",2],["dizipal172.cloud",2],["dizipal173.cloud",2],["dizipal174.cloud",2],["dizipal175.cloud",2],["dizipal176.cloud",2],["dizipal177.cloud",2],["dizipal178.cloud",2],["dizipal179.cloud",2],["dizipal180.cloud",2],["dizipal181.cloud",2],["dizipal182.cloud",2],["dizipal183.cloud",2],["dizipal184.cloud",2],["dizipal185.cloud",2],["dizipal186.cloud",2],["dizipal187.cloud",2],["dizipal188.cloud",2],["dizipal189.cloud",2],["dizipal190.cloud",2],["dizipal191.cloud",2],["dizipal192.cloud",2],["dizipal193.cloud",2],["dizipal194.cloud",2],["dizipal195.cloud",2],["dizipal196.cloud",2],["dizipal197.cloud",2],["dizipal198.cloud",2],["dizipal199.cloud",2],["dizipal200.cloud",2],["dizipal503.com",2],["dizipal504.com",2],["dizipal505.com",2],["dizipal506.com",2],["dizipal507.com",2],["dizipal508.com",2],["dizipal509.com",2],["dizipal510.com",2],["dizipal511.com",2],["dizipal512.com",2],["dizipal513.com",2],["dizipal514.com",2],["dizipal515.com",2],["dizipal516.com",2],["dizipal517.com",2],["dizipal518.com",2],["dizipal519.com",2],["dizipal520.com",2],["dizipal521.com",2],["dizipal522.com",2],["dizipal523.com",2],["dizipal524.com",2],["dizipal525.com",2],["dizipal526.com",2],["dizipal527.com",2],["dizipal528.com",2],["dizipal529.com",2],["dizipal530.com",2],["dizipal531.com",2],["dizipal532.com",2],["dizipal533.com",2],["dizipal534.com",2],["dizipal535.com",2],["dizipal536.com",2],["dizipal537.com",2],["dizipal538.com",2],["dizipal539.com",2],["dizipal540.com",2],["dizipal541.com",2],["dizipal542.com",2],["dizipal543.com",2],["dizipal544.com",2],["dizipal545.com",2],["dizipal546.com",2],["dizipal547.com",2],["dizipal548.com",2],["dizipal549.com",2],["dizipal550.com",2]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.fetch = new Proxy(self.fetch, {
        apply: function(target, thisArg, args) {
            let proceed = true;
            try {
                let details;
                if ( args[0] instanceof self.Request ) {
                    details = args[0];
                } else {
                    details = Object.assign({ url: args[0] }, args[1]);
                }
                const props = new Map();
                for ( const prop in details ) {
                    let v = details[prop];
                    if ( typeof v !== 'string' ) {
                        try { v = JSON.stringify(v); }
                        catch(ex) { }
                    }
                    if ( typeof v !== 'string' ) { continue; }
                    props.set(prop, v);
                }
                proceed = needles.length === 0;
                for ( const { key, re } of needles ) {
                    if (
                        props.has(key) === false ||
                        re.test(props.get(key)) === false
                    ) {
                        proceed = true;
                        break;
                    }
                }
            } catch(ex) {
            }
            return proceed
                ? Reflect.apply(target, thisArg, args)
                : Promise.resolve(new Response());
        }
    });
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

