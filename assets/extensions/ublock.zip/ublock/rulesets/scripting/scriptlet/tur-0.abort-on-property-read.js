/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-on-property-read
/// alias aopr

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortOnPropertyRead() {

/******************************************************************************/

// tur-0

const argsList = [{"a":["detectedAdBlock"]},{"a":["adblockmesaj"]},{"a":["detectAdBlock"]},{"a":["adsBlocked"]},{"a":["rTargets"]},{"a":["initPu"]},{"a":["initAd"]},{"a":["initPop"]},{"a":["oV1"]},{"a":["openpop"]},{"a":["initDizi"]},{"a":["wpsite_clickable_data"]}];

const hostnamesMap = new Map([["sozcu.com.tr",0],["mangawt.com",1],["hopena.net",1],["gsmturkey.net",1],["vidtekno.com",1],["telegramgruplari.com",2],["kanalmaras.com",3],["r10.net",4],["jetfilmizletv.com",5],["dizipall.org",5],["dizimax2.com",5],["dizimax3.com",5],["dizimax4.com",5],["dizimax5.com",5],["dizimax6.com",5],["dizimax7.com",5],["dizimax8.com",5],["dizimax9.com",5],["dizimax10.com",5],["dizimax11.com",5],["dizimax12.com",5],["dizimax13.com",5],["dizimax14.com",5],["dizimax15.com",5],["dizimax16.com",5],["dizimax17.com",5],["dizimax18.com",5],["yenierotikfilm.xyz",5],["breakingbadizle.com",5],["diziday1.com",5],["filmgezegeni.live",5],["zipfilmizle.com",5],["bamfilmizle.com",5],["sinemadafilm.com",5],["netflixcehennemi.com",5],["diziizles.com",5],["hdizlefilmleri.com",5],["filmmoduu.com",5],["abifilmizle.org",5],["hdfilmhit.com",5],["filmla.org",5],["trfilm.net",5],["dolufilm.org",5],["netflix-izle.com",5],["turkifsaalemi.com",5],["netfilmtvizle.com",5],["superfilmgeldi.net",6],["fullhdfilmizlett1.com",6],["fullhdfilmcibaba1.com",6],["dizirun1.com",6],["fullfilmcibaba1.com",6],["fullfilmcidayi1.com",6],["filmsezonu.com",6],["fullhdfilmizleabi.com",6],["hdfreeizle.com",6],["erotikfilmsitesi.net",6],["fullfilmcidayim.com",6],["hdrealfilmizle.com",6],["hdmixfilim.com",6],["fullhdfilmizlepala.com",6],["yabancidizici.net",7],["dizilla4.com",7],["dizimini.com",7],["filmizlehub.com",7],["roketdizi.pw",7],["1080hdfilmizle.com",7],["shirl.club",8],["altporno.xyz",8],["ovpvideo.com",8],["dizikorea.com",9],["diziyou.co",10],["technopat.net",11]]);

/******************************************************************************/

const ObjGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const ObjDefineProperty = Object.defineProperty;

const magic =
    String.fromCharCode(Date.now() % 26 + 97) +
    Math.floor(Math.random() * 982451653 + 982451653).toString(36);

const abort = function() {
    throw new ReferenceError(magic);
};

const makeProxy = function(owner, chain) {
    const pos = chain.indexOf('.');
    if ( pos === -1 ) {
        const desc = ObjGetOwnPropertyDescriptor(owner, chain);
        if ( !desc || desc.get !== abort ) {
            ObjDefineProperty(owner, chain, {
                get: abort,
                set: function(){}
            });
        }
        return;
    }

    const prop = chain.slice(0, pos);
    let v = owner[prop];
    chain = chain.slice(pos + 1);
    if ( v ) {
        makeProxy(v, chain);
        return;
    }

    const desc = ObjGetOwnPropertyDescriptor(owner, prop);
    if ( desc && desc.set !== undefined ) { return; }

    ObjDefineProperty(owner, prop, {
        get: function() { return v; },
        set: function(a) {
            v = a;
            if ( a instanceof Object ) {
                makeProxy(a, chain);
            }
        }
    });
};

const scriptlet = (
    chain = ''
) => {
    const owner = window;
    makeProxy(owner, chain);
    const oe = window.onerror;
    window.onerror = function(msg, src, line, col, error) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe(msg, src, line, col, error);
        }
    }.bind();
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

