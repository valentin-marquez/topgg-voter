/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-xhr-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noXhrIf() {

/******************************************************************************/

// default

const argsList = [{"a":["request=adb"]},{"a":["doubleclick"]},{"a":["adsbygoogle"]},{"a":["homad-global-configs"]},{"a":["/doubleclick|googlesyndication/"]},{"a":["ad_"]},{"a":["/\\/ad\\/g\\/1/"]},{"a":["ads"]},{"a":["svonm"]},{"a":["/\\/VisitorAPI\\.js|\\/AppMeasurement\\.js/"]},{"a":["googlesyndication"]},{"a":["damoh"]},{"a":["/youboranqs01|spotx/"]},{"a":["pop"]},{"a":["/^/"]},{"a":["/ad"]},{"a":["prebid"]},{"a":["securecheck"]},{"a":["securepubads"]},{"a":["wpadmngr"]},{"a":["/ads"]},{"a":["url:googlesyndication"]},{"a":["/js/prebid-"]},{"a":["/analytics|livestats/"]},{"a":["mahimeta"]},{"a":["notifier"]},{"a":["/ad-"]},{"a":["/coinzillatag|czilladx/"]},{"a":["czilladx"]},{"a":["/adsbygoogle|ad_status/"]},{"a":["php"]},{"a":["popunder"]},{"a":["adx"]},{"a":["cls_report?"]},{"a":["method:HEAD"]},{"a":["adswizz.com"]},{"a":["tag"]},{"a":["method:POST url:/logImpressions"]},{"a":["method:POST url:/^https:\\/\\/www\\.reddit\\.com$/"]},{"a":["method:POST"]},{"a":["utreon.com/pl/api/event method:POST"]},{"a":["log-sdk.ksapisrv.com/rest/wd/common/log/collect method:POST"]},{"a":["mobileanalytics"]},{"a":["cloudflare.com/cdn-cgi/trace"]},{"a":["amazonaws"]},{"a":["/recommendations."]},{"a":["/api/analytics"]},{"a":["api"]}];

const hostnamesMap = new Map([["handelsblatt.com",0],["moviepilot.de",1],["sbs.com.au",1],["minhaconexao.com.br",1],["videolyrics.in",1],["topsporter.net",1],["meteoetradar.com",1],["gala.fr",1],["pinsystem.co.uk",2],["texture-packs.com",2],["manyakan.com",2],["persianhive.com",2],["boainformacao.com.br",2],["privatenewz.com",2],["gcertificationcourse.com",2],["portaliz.site",2],["ghior.com",2],["tech-story.net",2],["visalist.io",2],["gyanitheme.com",2],["hipsonyc.com",2],["litecoin.host",2],["wetter.de",3],["gnomio.com",4],["frkn64modding.com",5],["channel4.com",6],["gearingcommander.com",7],["duplichecker.com",7],["novelmultiverse.com",7],["taming.io",7],["snlookup.com",7],["globfone.com",7],["chimicamo.org",7],["webforefront.com",7],["cinemakottaga.top",7],["apkmagic.com.ar",7],["reaperscans.id",7],["short1.site",7],["vox.de",8],["vip.de",8],["rtl.de",8],["fitforfun.de",8],["nationalgeographic.fr",9],["freegogpcgames.com",10],["informaxonline.com",[10,15]],["gaminplay.com",10],["blisseyhusband.in",10],["mhdtvworld.xyz",10],["routech.ro",10],["rontechtips.com",10],["homeairquality.org",10],["techtrim.tech",10],["pigeonburger.xyz",10],["freedownloadvideo.net",10],["askpaccosi.com",10],["crypto4tun.com",10],["fusedgt.com",10],["apkowner.org",10],["appsmodz.com",10],["bingotingo.com",10],["superpsx.com",10],["financeflix.in",10],["technoflip.in",10],["paidappstore.xyz",10],["stringreveals.com",10],["fox.com",10],["obutecodanet.ig.com.br",10],["firmwarex.net",10],["softwaretotal.net",10],["nawahi1.com",10],["freecodezilla.net",10],["movieslegacy.com",10],["iconmonstr.com",10],["rbxscripts.net",10],["adslink.pw",10],["comentariodetexto.com",10],["wordpredia.com",10],["karanpc.com",10],["livsavr.co",10],["gsmhamza.com",10],["autobild.de",11],["computerbild.de",11],["golem.de",11],["desired.de",11],["t-online.de",11],["stern.de",11],["familie.de",11],["kino.de",11],["spieletipps.de",11],["rakuten.tv",12],["zdam.xyz",13],["pasend.link",14],["freewp.io",14],["jetpunk.com",16],["falixnodes.net",[17,18]],["mcrypto.club",19],["coinsparty.com",19],["simplebits.io",20],["stardeos.com",21],["tvwish.com",22],["goduke.com",23],["1apple.xyz",24],["lavanguardia.com",25],["foodsdictionary.co.il",26],["freesolana.top",27],["faucetclub.net",28],["claim.fun",28],["faucetcrypto.net",28],["btc25.org",28],["doge25.in",28],["magicgameworld.com",29],["farescd.com",30],["freebinance.top",31],["freelitecoin.top",32],["freetron.top",32],["citi.com",33],["filmi7.com",34],["hotfm.audio",35],["luffytra.xyz",36],["docs.google.com",37],["reddit.com",38],["endbasic.dev",39],["jmmv.dev",39],["utreon.com",40],["zhihu.com",41],["viu.com",42],["myair2.resmed.com",43],["travelerdoor.com",43],["bestiefy.com",44],["azby.fmworld.net",45],["unrealengine.com",46],["wco.tv",47]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const xhrInstances = new WeakMap();
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.XMLHttpRequest = class extends self.XMLHttpRequest {
        open(...args) {
            const argNames = [ 'method', 'url' ];
            const haystack = new Map();
            for ( let i = 0; i < args.length && i < argNames.length; i++  ) {
                haystack.set(argNames[i], args[i]);
            }
            if ( haystack.size !== 0 ) {
                let matches = true;
                for ( const { key, re } of needles ) {
                    matches = re.test(haystack.get(key) || '');
                    if ( matches === false ) { break; }
                }
                if ( matches ) {
                    xhrInstances.set(this, haystack);
                }
            }
            return super.open(...args);
        }
        send(...args) {
            const haystack = xhrInstances.get(this);
            if ( haystack === undefined ) {
                return super.send(...args);
            }
            Object.defineProperties(this, {
                readyState: { value: 4, writable: false },
                response: { value: '', writable: false },
                responseText: { value: '', writable: false },
                responseURL: { value: haystack.get('url'), writable: false },
                responseXML: { value: '', writable: false },
                status: { value: 200, writable: false },
                statusText: { value: 'OK', writable: false },
            });
            this.dispatchEvent(new Event('readystatechange'));
            this.dispatchEvent(new Event('load'));
            this.dispatchEvent(new Event('loadend'));
        }
    };
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

