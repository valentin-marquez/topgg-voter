/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-on-property-write.entity
/// alias aopw.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortOnPropertyWriteEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["_pop"]},{"a":["Fingerprint2"],"n":["pingit.com","pingit.me"]},{"a":["Fingerprent2"]},{"a":["adcashMacros"]},{"a":["open"]},{"a":["smrtSB"]},{"a":["smrtSP"]},{"a":["IS_ADBLOCK"]},{"a":["ads_priv"]},{"a":["atOptions"]},{"a":["encodeURIComponent"]},{"a":["closeMyAd"]},{"a":["decodeURIComponent"]},{"a":["afStorage"]},{"a":["u_cfg"]},{"a":["hidekeep"]},{"a":["adBlockDetected"]},{"a":["popUpUrl"]},{"a":["adsHeight"]},{"a":["showImageAdBlocker"]},{"a":["I833"]},{"a":["decodeURI"]},{"a":["spot"]},{"a":["block_detected"]},{"a":["ab_cl"]},{"a":["document.dispatchEvent"]},{"a":["afScript"]},{"a":["installBtnvar"]},{"a":["DoodPop"]},{"a":["tmnramp"]},{"a":["__C"]},{"a":["puShown"]},{"a":["__aaZoneid"]},{"a":["p$00a"]},{"a":["akadb"]},{"a":["CoinNebula"]}];

const entitiesMap = new Map([["vidlox",0],["yourbittorrent",0],["torlock",0],["9anime",0],["f1stream",0],["fbstream",0],["mlbstream",0],["motogpstream",0],["nbastream",0],["nflstream",0],["nhlstream",0],["plylive",0],["plyvdo",0],["rugbystreams",0],["socceronline",0],["tennisstreams",0],["tvply",0],["ufcstream",0],["vipleague",0],["xmoviesforyou",0],["mkvcage",0],["pahe",0],["psarips",[0,1]],["yts",0],["ouo",0],["watch-series",0],["watchseries",0],["linkshorts",0],["imgsen",0],["imgsto",0],["streamcdn",0],["daddylive",[0,13]],["itdmusic",0],["divxtotal",0],["divxtotal1",0],["pelisplus",[0,3,5,6]],["strikeout",0],["plyjam",0],["vipbox",0],["grantorrent",[0,1]],["2ddl",0],["peliculas24",[0,5]],["rojadirectaenvivo",0],["torrentz2eu",0],["movies123",0],["piratebay",0],["elixx",[0,20]],["file4go",0],["starmusiq",0],["mirrorace",0],["viprow",0],["asianclub",0],["javmost",0],["mixdrop",0],["123movieshub",0],["movie8k",0],["thepiratebay",[0,22]],["mangovideo",0],["300mbfilms",0],["movierulzlink",0],["newmovierulz",0],["zooqle",0],["atomohd",0],["atomixhq",[0,3]],["pctfenix",[0,3]],["pctnew",[0,3]],["shortearn",0],["keepvid",0],["canalesportivo",0],["desiremovies",0],["uploadbuzz",0],["5movies",0],["fmovie",0],["xclusivejams",0],["tmearn",0],["leechall",0],["sports24",0],["beinmatch",0],["shorten",0],["projectfreetv",0],["safetxt",0],["streamz",0],["streamzz",0],["clicknupload",0],["linkviet",0],["remaxhd",0],["animesvision",0],["miniurl",0],["frkmusic",0],["dood",[0,28]],["thisav",0],["rnbxclusive0",0],["rnbxclusive1",0],["rnbxclusive",0],["skymovieshd",0],["adblockeronstape",0],["adblockstreamtape",0],["adblockstrtape",0],["adblockstrtech",0],["shavetape",0],["stapadblockuser",0],["stape",0],["stapewithadblock",0],["strcloud",0],["streamadblockplus",0],["streamta",0],["streamtape",0],["streamtapeadblockuser",0],["strtape",0],["strtapeadblock",0],["strtapeadblocker",0],["strtapewithadblock",0],["strtpe",0],["khatrimazafull",0],["aniplay",0],["animesanka",0],["racaty",[0,1]],["animepahe",[0,30]],["crackstreams",0],["shortzzy",0],["rojadirecta",[0,6,11]],["shorttey",[0,3]],["filmyzilla",0],["estrenosflix",[0,3]],["estrenosflux",[0,3]],["estrenosgo",[0,3]],["proxybit",0],["3hiidude",0],["hiidudemoviez",0],["vexmoviex",0],["adcorto",[0,9]],["moviessources",0],["streamsport",0],["tormalayalam",[0,3]],["vidclouds",0],["animixplay",0],["moviesmeta",0],["123movieshd",0],["findav",0],["findporn",0],["keralahd",0],["toonanime",0],["123moviesme",0],["moviezwaphd",0],["7hitmovies",0],["vipboxtv",0],["buffstreams",0],["movieplex",0],["mrunblock",0],["unblocknow",0],["ask4movie",0],["keeplinks",0],["1tamilmv",0],["usagoals",0],["ytmp3eu",0],["1stream",0],["gotxx",0],["flixmaza",0],["g3g",0],["9xmovie",0],["flizmovies",0],["hdmoviesfair",0],["hdmoviesflix",[0,33]],["moviesverse",0],["themoviesflix",0],["u4m",0],["softarchive",0],["123-movies",0],["4stream",0],["dvdplay",0],["yts-subs",0],["rintor",0],["alexsports",0],["enjoy4k",0],["nocensor",0],["adblockeronstreamtape",0],["sports-stream",0],["2umovies",0],["aagmaal",0],["bhaai",0],["mmsbee",0],["daddylivehd",[0,14]],["tutelehd",0],["adblocktape",0],["onmovies",1],["pirateproxy",1],["steamplay",[1,3,35]],["streamp1ay",[1,2,3]],["kimcartoon",1],["adshort",1],["flashx",1],["imgdew",1],["imgmaze",1],["imgoutlet",1],["imgtown",1],["imgview",1],["adsrt",1],["mp3guild",1],["mp3clan",1],["xmovies8",1],["pouvideo",[1,2,3]],["povvideo",[1,2,3]],["povw1deo",[1,2,3]],["povwideo",[1,2,3]],["powv1deo",[1,2,3]],["powvibeo",[1,2,3]],["powvideo",[1,2,3]],["powvldeo",[1,2,3]],["grantorrent1",1],["ddlvalley",1],["inkapelis",[1,5,6]],["pnd",1],["imgrock",1],["file-upload",1],["hdvid",[1,5,9]],["onvid",[1,5]],["ovid",[1,5]],["vidhd",[1,5]],["crohasit",1],["streamingworld",1],["putlocker9",1],["uploadproper",1],["kstreaming",1],["pingit",1],["yggtorrent",1],["movie123",1],["putlocker",[3,4]],["pelisplushd",3],["pelix",[3,5,6]],["fembed",3],["mavplay",3],["videobb",3],["bfstrms",3],["elitetorrent",3],["cine-calidad",3],["extratorrents",3],["hqq",[5,6]],["aquipelis",[5,6]],["anime-extremo",5],["cliver",5],["ciberdvd",5],["pelisgratis",5],["newpelis",[5,6]],["voirfilms",5],["pelisplay",[5,6]],["cinetux",5],["thevidhd",5],["allcalidad",5],["rojadirectatv",6],["tarjetarojatvonline",[6,11]],["tube8",7],["perfectgirls",8],["perfektdamen",8],["bitporno",9],["dbupload",10],["movies-300mb",10],["1movies",12],["foumovies",12],["downloadming",12],["extratorrent",13],["torrentstatus",13],["yts2",13],["y2mate",13],["extramovies",14],["livetvon",14],["al-arabiya-2-i3dadi",15],["yoututosjeff",16],["androidaba",16],["vidcloud",16],["descarga-animex",16],["telecharger-igli4",16],["mexa",[16,27]],["cuevana3",17],["vinaurl",18],["loptelink",19],["myegy",21],["mtsproducoes",23],["notebookcheck",24],["pornsexer",25],["akwam",26],["tomshardware",29],["hotscopes",31],["klmanga",32],["mangarawjp",32],["writedroid",34]]);

/******************************************************************************/

const magic =
    String.fromCharCode(Date.now() % 26 + 97) +
    Math.floor(Math.random() * 982451653 + 982451653).toString(36);

const abort = function() {
    throw new ReferenceError(magic);
};

const scriptlet = (
    prop = ''
) => {
    let owner = window;
    for (;;) {
        const pos = prop.indexOf('.');
        if ( pos === -1 ) { break; }
        owner = owner[prop.slice(0, pos)];
        if ( owner instanceof Object === false ) { return; }
        prop = prop.slice(pos + 1);
    }
    delete owner[prop];
    Object.defineProperty(owner, prop, {
        set: function() {
            abort();
        }
    });
    const oe = window.onerror;
    window.onerror = function(msg, src, line, col, error) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe(msg, src, line, col, error);
        }
    }.bind();
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
