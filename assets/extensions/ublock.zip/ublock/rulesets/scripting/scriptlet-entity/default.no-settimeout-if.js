/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-settimeout-if.entity
/// alias no-setTimeout-if.entity
/// alias nostif.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noSetTimeoutIfEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["push","500"]},{"a":[".call(null)","10"]},{"a":["nrWrapper"]},{"a":["show"]},{"a":["()","45000"]},{"a":["0x"]},{"a":["displayAdBlockedVideo"]},{"a":["_0x"]},{"a":["debugger"]},{"a":["\"admc\""]},{"a":["'0x"]},{"a":["Adb"]},{"a":["nextFunction","2000"]},{"a":["checkAdblockUser","1000"]},{"a":["nextFunction","250"]},{"a":["popup"]},{"a":["mdpDeBlocker"]},{"a":["test.remove","100"]},{"a":["innerText","2000"]},{"a":["KeepOpeningPops","1000"]},{"a":["appendChild"]},{"a":["AdBlocker"]},{"a":["ai_adb_detected"]},{"a":["ai_adb"]},{"a":["adFilled","2500"]},{"a":["readyplayer","2000"]},{"a":["trigger","0"]},{"a":["debug"]},{"a":["sadbl"]},{"a":["mdp"]},{"a":["offsetWidth"]},{"a":["0x","3000"]},{"a":["invoke"]},{"a":["ads"]},{"a":["/new|Bait|check|decoy|global|WinMsgHtml/"]},{"a":["AdBlock"]},{"a":["eval"]},{"a":["getComputedStyle","250"]},{"a":["blocked"]},{"a":["showModal"]},{"a":["blur"]},{"a":["magnificPopup"]},{"a":["UABP"]},{"a":["getBoundingClientRect"]},{"a":["(\"\")"]},{"a":["","100"]}];

const entitiesMap = new Map([["lablue",0],["truckscout24",1],["wieistmeineip",1],["transfermarkt",1],["gameswelt",1],["comunio",1],["heftig",1],["notebookcheck",1],["testedich",1],["tvtv",1],["wetter",1],["wetteronline",1],["finanzen",[1,2]],["sms24",3],["sushi-scan",3],["poplinks",3],["ahmedmode",3],["magesy",[3,21,45]],["kissasian",4],["rp5",5],["mma-core",6],["writedroid",7],["hydracdn",8],["m4ufree",8],["dood",8],["crackstreams",8],["yts",9],["720pstream",9],["1stream",9],["eztv",9],["thefmovies",10],["xhamsterdeutsch",11],["fxporn69",12],["aliancapes",12],["streamz",12],["streamzz",12],["urlcero",13],["totaldebrid",14],["sandrives",14],["oploverz",15],["bollyholic",16],["pouvideo",17],["povvideo",17],["povw1deo",17],["povwideo",17],["powv1deo",17],["powvibeo",17],["powvideo",17],["powvldeo",17],["tubsexer",18],["porno-tour",18],["lenkino",18],["pornomoll",18],["camsclips",18],["telerium",19],["lightnovelpub",[20,33,43,44]],["mlwbd",22],["shortzzy",23],["pandafreegames",24],["thoptv",25],["brainly",26],["waaw",27],["streameast",28],["thestreameast",28],["daddylivehd",28],["usnovels",29],["pornsexer",30],["solvetube",31],["hdfilme",32],["egybest",34],["wcofun",35],["wstream",36],["gotxx",37],["turkanime",38],["khatrimaza",39],["pogolinks",39],["popcornstream",40],["privatemoviez",41],["gmx",42]]);

/******************************************************************************/

const scriptlet = (
    needle = '',
    delay = ''
) => {
    const needleNot = needle.charAt(0) === '!';
    if ( needleNot ) { needle = needle.slice(1); }
    if ( delay === '' ) { delay = undefined; }
    let delayNot = false;
    if ( delay !== undefined ) {
        delayNot = delay.charAt(0) === '!';
        if ( delayNot ) { delay = delay.slice(1); }
        delay = parseInt(delay, 10);
    }
    if ( needle.startsWith('/') && needle.endsWith('/') ) {
        needle = needle.slice(1,-1);
    } else if ( needle !== '' ) {
        needle = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    const reNeedle = new RegExp(needle);
    const regexpTest = RegExp.prototype.test;
    self.setTimeout = new Proxy(self.setTimeout, {
        apply: function(target, thisArg, args) {
            const a = String(args[0]);
            const b = args[1];
            let defuse;
            if ( needle !== '' ) {
                defuse = regexpTest.call(reNeedle, a) !== needleNot;
            }
            if ( defuse !== false && delay !== undefined ) {
                defuse = (b === delay || isNaN(b) && isNaN(delay) ) !== delayNot;
            }
            if ( defuse ) {
                args[0] = function(){};
            }
            return target.apply(thisArg, args);
        }
    });
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
