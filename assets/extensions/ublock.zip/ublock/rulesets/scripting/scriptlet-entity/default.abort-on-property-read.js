/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-on-property-read.entity
/// alias aopr.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortOnPropertyReadEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["adBlockDetected"]},{"a":["open"],"n":["pingit.com","pingit.me"]},{"a":["__eiPb"]},{"a":["afScript"]},{"a":["AaDetector"],"n":["pingit.com","pingit.me"]},{"a":["_sp_._networkListenerData"]},{"a":["_pop"],"n":["pingit.com","pingit.me"]},{"a":["InstallTrigger"]},{"a":["LieDetector"]},{"a":["ExoLoader.serve"]},{"a":["mm"]},{"a":["Date.prototype.toUTCString"]},{"a":["_wm"]},{"a":["btoa"]},{"a":["console.clear"]},{"a":["jwplayer.utils.Timer"]},{"a":["decodeURI"]},{"a":["blockAdBlock"]},{"a":["__Y"]},{"a":["parcelRequire"]},{"a":["ExoLoader"]},{"a":["popjs.init"]},{"a":["PopAds"]},{"a":["runAdblock"]},{"a":["loadTool"]},{"a":["popns"]},{"a":["arrvast"]},{"a":["doSecondPop"]},{"a":["app_vars.force_disable_adblock"],"n":["pingit.com","pingit.me"]},{"a":["jQuery.adblock"]},{"a":["ads_block"]},{"a":["document.dispatchEvent"]},{"a":["eddOptions"]},{"a":["absda"]},{"a":["Math.floor"]},{"a":["XMLHttpRequest"]},{"a":["tabUnder"]},{"a":["ExoLoader.addZone"]},{"a":["exoNoExternalUI38djdkjDDJsio96"]},{"a":["CustomEvent"]},{"a":["exoJsPop101"]},{"a":["AdservingModule"]},{"a":["adblockDetector"]},{"a":["rmVideoPlay"],"n":["pingit.com","pingit.me"]},{"a":["require"]},{"a":["jwplayer.vast"]},{"a":["devtoolsDetector"]},{"a":["getUrlParameter"]},{"a":["S9tt"]},{"a":["capapubli"]},{"a":["__pop_debugX"]},{"a":["decodeURIComponent"]},{"a":["glxopen"]},{"a":["BetterJsPop"]},{"a":["encodeURIComponent"]},{"a":["FuckAdBlock"]},{"a":["promo"]},{"a":["atob"]},{"a":["popit"]},{"a":["rid"]},{"a":["localStorage"]},{"a":["__brn_private_mode"]},{"a":["String.fromCharCode"]},{"a":["NoAdBlock"]},{"a":["TID"]},{"a":["pace"]},{"a":["marker"]},{"a":["mdpDeBlocker"]},{"a":["pu"]},{"a":["adBlocked"]},{"a":["loadRunative"]},{"a":["_run"]},{"a":["doads"]},{"a":["document.onclick"]},{"a":["__aaZoneid"]},{"a":["__CF$cv$params"]},{"a":["popUp"]},{"a":["zfgformats"]},{"a":["zfgstorage"]},{"a":["k75k67"]},{"a":["disableDeveloperTools"]},{"a":["DoodPop"]},{"a":["Request"]},{"a":["FMPoopS"]},{"a":["ramp"]}];

const entitiesMap = new Map([["hqq",[0,26,27]],["yoututosjeff1",0],["dutchycorp",[0,28,63]],["lookmovie",[0,10]],["shrink",[0,1,28]],["waaws",0],["animepahe",[1,22]],["kwik",[1,22]],["1337x.unblocked",1],["1337x.unblockit",[1,13]],["pussyspace",1],["urlcero",1],["shrtfly",[1,28,36]],["linkshorts",[1,28]],["streamcdn",[1,4]],["cliver",1],["vinaurl",[1,28]],["komikcast",1],["bolly4u",[1,35]],["tugaflix",1],["hdfriday",1],["extramovies",[1,4]],["123movies",1],["shortearn",[1,4,28]],["pingit",[1,4,6,28,43]],["mstream",1],["urlty",[1,28]],["pornsexer",1],["watch4hd",1],["bluemediafiles",1],["oload",[1,4,6,16]],["streamhoe",[1,6]],["dailysport",[1,4]],["linkviet",[1,28]],["btdb",[1,14]],["link1s",[1,28]],["shorttey",[1,28]],["pureshort",[1,28]],["linksfire",1],["videoplayer",1],["movizland",1],["sitesunblocked",1],["1377x",1],["bcvc",1],["bluemediafile",[1,16]],["wetteronline",2],["1337x",[3,4]],["cricfree",3],["sportskart",3],["hydracdn",4],["vizcloud",4],["vizcloud2",4],["kinos",[4,32]],["kinox",[4,16,32]],["europixhd",[4,8]],["hdeuropix",[4,8]],["topeuropix",[4,8]],["ouo",4],["songs",4],["gogoanimetv",4],["daddylive",[4,44]],["pelisplus",4],["inkapelis",4],["ettv",4],["pelix",4],["pnd",[4,28]],["piratebay",4],["webbro",4],["javwide",4],["vidhd",4],["mirrorace",4],["asianclub",[4,15,18]],["thoptv",4],["streamingworld",4],["yesmovies",4],["solarmovie",4],["bdiptv",4],["cinemalibero",4],["300mbfilms",4],["pctfenix",[4,64]],["pctnew",[4,64]],["hdfilme",[4,14,32,69]],["watchgameofthrones",4],["tmearn",[4,28]],["kinoz",[4,16]],["wstream",4],["kastream",4],["shorten",[4,19,28]],["123animes",[4,52]],["openloadmovies",4],["gdriveplayer",4],["crichd",4],["vipracing",4],["skymovieshd",[4,75]],["123europix",[4,7,8]],["ilgeniodellostreaming",4],["123movies-org",4],["sflix",4],["primetubsub",4],["moviesland",[4,18]],["ohmymag",5],["gamestorrents",8],["gogoanimes",8],["limetorrents",8],["piratebayz",8],["proxyrarbg",8],["rarbg",8],["rarbgmirror",8],["rarbgproxied",8],["rarbgproxy",8],["rarbgunblock",8],["grantorrent",[8,47]],["moviescounter",8],["elixx",[8,41]],["telerium",8],["savelinks",8],["hentaisd",8],["mrpiracy",8],["animesvision",8],["prostoporno",9],["kissasian",10],["9anime",10],["m4ufree",[10,53]],["0123movies",10],["gomovies",10],["fembed",[10,18]],["mavplay",[10,15,18]],["videobb",[10,15,18,52]],["5movies",10],["123moviesc",10],["proxybit",10],["123movieshd",10],["fbgo",[10,18]],["sbchip",[10,18]],["sbflix",[10,18]],["sbplay",[10,18]],["sbplay2",[10,18]],["sbplay3",[10,18]],["sbrulz",[10,18]],["streamsb",[10,18,81]],["ask4movie",10],["1tamilmv",10],["buffstream",10],["tenies-online",10],["m4uhd",10],["hdhub4u",10],["watchseries9",10],["moviesjoy",10],["torrentstatus",10],["yts2",10],["y2mate",10],["alexsports",10],["gaobook",11],["biqle",11],["7starhd",[11,51]],["8xfilms",11],["extratorrent",11],["otakuindo",11],["new-gomovies",11],["thepiratebay",[12,21]],["tpbay",12],["camwhores",[12,24]],["camwhorestv",[12,24]],["filesamba",12],["theproxy",12],["steamplay",[13,14,15]],["streamp1ay",[14,15]],["nyafilmer",14],["topflix",14],["ustream",14],["imgkia",14],["moviessources",14],["sbvideo",[14,18]],["steanplay",15],["stemplay",15],["streanplay",15],["txxx",15],["xmoviesforyou",[16,21]],["cuevana3",[16,48]],["vidcloud",[16,18,53]],["pornid",16],["zbporn",[16,56]],["yomovies",16],["nonsensediamond",16],["xclusivejams",16],["sportlemon",16],["sportlemons",16],["sportlemonx",16],["remaxhd",[16,33]],["img4fap",16],["babeporn",16],["babytorrent",16],["123moviesme",16],["xxxhdvideo",16],["123link",[17,28,29,30]],["vidsrc",18],["kinoger",18],["iframejav",18],["mm9844",18],["netxwatch",18],["milfnut",18],["anxcinema",18],["videofilms",18],["prosongs",18],["animexstream",18],["ncdnstm",18],["sexvid",[20,68]],["imgmaze",[21,37,40]],["imgtown",[21,37,39,40]],["imgrock",[21,39]],["yts",23],["silkengirl",[24,37,38]],["rintor",24],["imgsen",[24,39]],["imgsto",[24,39]],["sxyprn",25],["uploadrar",25],["player.uwatchfree",[26,27,53]],["vapley",27],["younetu",27],["waaw",27],["adbull",28],["eg4link",28],["adshort",28],["adsrt",[28,43]],["loptelink",28],["adfloz",28],["123short",28],["neoskip",28],["tinylink",28],["megaurl",28],["sk-ip",28],["seulink",28],["megalink",28],["earnload",28],["miniurl",28],["pcprogramasymas",28],["earncash",28],["shortzzy",28],["lite-link",28],["adcorto",28],["dulinks",28],["dogecoin",28],["upfiles",28],["erogen",31],["pornhat",31],["porno-tour",31],["desivideos",31],["egydead",33],["govid",33],["khatrimazafull",33],["movies07",33],["pirlotvonlinehd",33],["latesthdmovies",33],["netpornix",33],["tarjetarojatvonline",33],["flixmaza",33],["movie4me",34],["imgdew",[37,39,40]],["imgview",[37,39,40]],["pandamovie",38],["speedporn",38],["watchpornfree",38],["imgoutlet",[39,40]],["anitube",40],["movisubmalay",[40,52]],["waploaded",40],["dirtyindianporn",40],["indianpornvideos",40],["kashtanka",40],["onlyindianporn",40],["porno18",40],["xxnx",40],["xxxindianporn",40],["stream2watch",41],["peliculas-dvdrip",41],["readcomiconline",42],["pouvideo",45],["povvideo",45],["povw1deo",45],["povwideo",45],["powv1deo",45],["powvibeo",45],["powvideo",45],["powvldeo",45],["animedao",46],["grantorrent1",47],["subtorrents",[47,49]],["subtorrents1",[47,49]],["filecrypt",50],["torrentz2eu",52],["afilmywap",52],["okhatrimaza",52],["123anime",52],["gomoviesfree",52],["player.tormalayalamhd",53],["depedlps",54],["videovard",55],["mixdrop",57],["asiansex",58],["japanfuck",58],["japanporn",58],["teensex",58],["vintagetube",58],["xxxmovies",58],["0l23movies",59],["cloudvideotv",60],["brainly",61],["movierulzlink",62],["newmovierulz",62],["3hiidude",62],["ispunlock",65],["tpb",65],["mu2-mobi",66],["frkmusic",67],["zone-annuaire",67],["rainanime",70],["bitporno",71],["web2.0calc",72],["semi168",73],["dood",74],["moviehdf",76],["bolly4umovies",77],["redecanais",77],["123movieshub",78],["animeunity",78],["cima-club",78],["hindilinks4u",78],["t7meel",78],["serien",79],["bollyholic",80],["katmoviefix",82],["filemoon",83],["lightnovelpub",84]]);

/******************************************************************************/

const ObjGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const ObjDefineProperty = Object.defineProperty;

const magic =
    String.fromCharCode(Date.now() % 26 + 97) +
    Math.floor(Math.random() * 982451653 + 982451653).toString(36);

const abort = function() {
    throw new ReferenceError(magic);
};

const makeProxy = function(owner, chain) {
    const pos = chain.indexOf('.');
    if ( pos === -1 ) {
        const desc = ObjGetOwnPropertyDescriptor(owner, chain);
        if ( !desc || desc.get !== abort ) {
            ObjDefineProperty(owner, chain, {
                get: abort,
                set: function(){}
            });
        }
        return;
    }

    const prop = chain.slice(0, pos);
    let v = owner[prop];
    chain = chain.slice(pos + 1);
    if ( v ) {
        makeProxy(v, chain);
        return;
    }

    const desc = ObjGetOwnPropertyDescriptor(owner, prop);
    if ( desc && desc.set !== undefined ) { return; }

    ObjDefineProperty(owner, prop, {
        get: function() { return v; },
        set: function(a) {
            v = a;
            if ( a instanceof Object ) {
                makeProxy(a, chain);
            }
        }
    });
};

const scriptlet = (
    chain = ''
) => {
    const owner = window;
    makeProxy(owner, chain);
    const oe = window.onerror;
    window.onerror = function(msg, src, line, col, error) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe(msg, src, line, col, error);
        }
    }.bind();
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
