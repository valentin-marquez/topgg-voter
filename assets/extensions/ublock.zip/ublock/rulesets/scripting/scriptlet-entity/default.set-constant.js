/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name set-constant.entity
/// alias set.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_setConstantEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["console.clear","trueFunc"]},{"a":["isAdBlockActive","false"]},{"a":["check_adblock","true"]},{"a":["xRds","false"]},{"a":["tRds","true"]},{"a":["console.clear","noopFunc"]},{"a":["console.log","noopFunc"]},{"a":["String.prototype.charCodeAt","trueFunc"]},{"a":["console.clear","undefined"]},{"a":["sadbl","false"]},{"a":["blurred","false"],"n":["pingit.com","pingit.me"]},{"a":["flashvars.adv_pre_src","''"]},{"a":["showPopunder","false"]},{"a":["page_params.holiday_promo","true"]},{"a":["adblock","1"]},{"a":["flashvars.adv_pre_vast","''"]},{"a":["flashvars.adv_pause_html","''"]},{"a":["String.fromCharCode","trueFunc"]},{"a":["isAdb","false"]},{"a":["clicked","true"]},{"a":["eClicked","true"]},{"a":["number","0"]},{"a":["sync","true"]},{"a":["attr","{}"]},{"a":["scriptSrc","''"]},{"a":["adblock","noopFunc"]},{"a":["path","''"]},{"a":["Ok","true"]},{"a":["safelink.adblock","false"]},{"a":["flashvars.adv_pre_url","''"]},{"a":["flashvars.protect_block","''"]},{"a":["flashvars.video_click_url","''"]},{"a":["ifmax","true"]},{"a":["btoa","null"]},{"a":["isAdblock","false"]},{"a":["atob","noopFunc"]},{"a":["flashvars.popunder_url","''"]},{"a":["time","0"]},{"a":["flashvars.adv_start_html","''"]},{"a":["adBlockDetected","noopFunc"]},{"a":["clientSide.adbDetect","noopFunc"]},{"a":["absda","noopFunc"]},{"a":["blogantiadblock","noopFunc"]},{"a":["MDCore.adblock","0"]},{"a":["awm","true"]},{"a":["openInNewTab","noopFunc"]},{"a":["decodeURIComponent","trueFunc"]},{"a":["document.bridCanRunAds","true"]},{"a":["flashvars.mlogo","''"]},{"a":["flashvars.related_src","''"]},{"a":["HTMLElement.prototype.attachShadow","null"]},{"a":["canRunAds","true"]},{"a":["load_pop_power","noopFunc"]},{"a":["Time_Start","0"]},{"a":["adblock","true"]},{"a":["ads_unblocked","true"]},{"a":["D4zz","noopFunc"]},{"a":["runAdblock","noopFunc"]},{"a":["p18","undefined"]},{"a":["adblock_use","false"]},{"a":["playerAdSettings.adLink","''"]},{"a":["playerAdSettings.waitTime","0"]},{"a":["adBlockDetectionResult","undefined"]}];

const entitiesMap = new Map([["vidsrc",0],["watch-series",0],["watchseries",0],["vev",0],["vidop",0],["vidup",0],["starmusiq",1],["wcofun",1],["kissasian",2],["gogoanime",[2,8]],["1movies",[2,7]],["xmovies8",2],["animeheaven",2],["0123movies",2],["gostream",2],["gomovies",2],["vidlox",[3,4]],["primewire",5],["streanplay",[5,6]],["sbplay",5],["milfnut",5],["fmovies",8],["9anime",8],["hqq",9],["123link",10],["adshort",10],["linkshorts",10],["adsrt",10],["vinaurl",10],["adfloz",10],["dutchycorp",10],["shortearn",10],["pingit",10],["urlty",10],["seulink",10],["shrink",10],["tmearn",10],["megalink",10],["linkviet",10],["miniurl",10],["pcprogramasymas",10],["link1s",10],["shortzzy",10],["shorttey",[10,51]],["lite-link",10],["pureshort",10],["adcorto",10],["dulinks",10],["zshort",10],["upfiles",10],["linkfly",10],["wplink",10],["camwhores",[11,15,29,30,31]],["tube8",[12,13]],["youporn",13],["redtube",13],["pornhub",[13,50]],["mangatail",14],["icdrama",14],["mangasail",14],["xtits",[16,38]],["uproxy",17],["pouvideo",18],["povvideo",18],["povw1deo",18],["povwideo",18],["powv1deo",18],["powvibeo",18],["powvideo",18],["powvldeo",18],["acortalo",[19,20,21,22]],["acortar",[19,20,21,22]],["plyjam",[23,24]],["fxporn69",25],["vipbox",26],["viprow",26],["desbloqueador",27],["xberuang",28],["teknorizen",28],["linkberuang",28],["pornsexer",[30,48,49]],["kickassanime",32],["subtorrents",33],["subtorrents1",33],["newpelis",33],["pelix",33],["allcalidad",33],["infomaniakos",33],["filecrypt",34],["tornadomovies",35],["sexwebvideo",36],["mangovideo",36],["file4go",37],["anitube",39],["asianclub",40],["sound-park",41],["soundpark",41],["soundpark-club",41],["striputopija",42],["mixdrop",43],["pickcrackpasswords",44],["uploadev",45],["ver-pelis-online",46],["ancient-origins",47],["lookcam",51],["lootlinks",51],["dpstream",52],["bluemediafiles",53],["streamz",54],["streamzz",54],["docer",55],["skymovieshd",56],["dvdplay",56],["crackstreams",57],["123movieshd",58],["animesa",59],["cinecalidad",[60,61]],["gmx",62]]);

/******************************************************************************/

const scriptlet = (
    chain = '',
    cValue = ''
) => {
    if ( chain === '' ) { return; }
    if ( cValue === 'undefined' ) {
        cValue = undefined;
    } else if ( cValue === 'false' ) {
        cValue = false;
    } else if ( cValue === 'true' ) {
        cValue = true;
    } else if ( cValue === 'null' ) {
        cValue = null;
    } else if ( cValue === "''" ) {
        cValue = '';
    } else if ( cValue === '[]' ) {
        cValue = [];
    } else if ( cValue === '{}' ) {
        cValue = {};
    } else if ( cValue === 'noopFunc' ) {
        cValue = function(){};
    } else if ( cValue === 'trueFunc' ) {
        cValue = function(){ return true; };
    } else if ( cValue === 'falseFunc' ) {
        cValue = function(){ return false; };
    } else if ( /^\d+$/.test(cValue) ) {
        cValue = parseFloat(cValue);
        if ( isNaN(cValue) ) { return; }
        if ( Math.abs(cValue) > 0x7FFF ) { return; }
    } else {
        return;
    }
    let aborted = false;
    const mustAbort = function(v) {
        if ( aborted ) { return true; }
        aborted =
            (v !== undefined && v !== null) &&
            (cValue !== undefined && cValue !== null) &&
            (typeof v !== typeof cValue);
        return aborted;
    };
    // https://github.com/uBlockOrigin/uBlock-issues/issues/156
    //   Support multiple trappers for the same property.
    const trapProp = function(owner, prop, configurable, handler) {
        if ( handler.init(owner[prop]) === false ) { return; }
        const odesc = Object.getOwnPropertyDescriptor(owner, prop);
        let prevGetter, prevSetter;
        if ( odesc instanceof Object ) {
            owner[prop] = cValue;
            if ( odesc.get instanceof Function ) {
                prevGetter = odesc.get;
            }
            if ( odesc.set instanceof Function ) {
                prevSetter = odesc.set;
            }
        }
        try {
            Object.defineProperty(owner, prop, {
                configurable,
                get() {
                    if ( prevGetter !== undefined ) {
                        prevGetter();
                    }
                    return handler.getter(); // cValue
                },
                set(a) {
                    if ( prevSetter !== undefined ) {
                        prevSetter(a);
                    }
                    handler.setter(a);
                }
            });
        } catch(ex) {
        }
    };
    const trapChain = function(owner, chain) {
        const pos = chain.indexOf('.');
        if ( pos === -1 ) {
            trapProp(owner, chain, false, {
                v: undefined,
                init: function(v) {
                    if ( mustAbort(v) ) { return false; }
                    this.v = v;
                    return true;
                },
                getter: function() {
                    return cValue;
                },
                setter: function(a) {
                    if ( mustAbort(a) === false ) { return; }
                    cValue = a;
                }
            });
            return;
        }
        const prop = chain.slice(0, pos);
        const v = owner[prop];
        chain = chain.slice(pos + 1);
        if ( v instanceof Object || typeof v === 'object' && v !== null ) {
            trapChain(v, chain);
            return;
        }
        trapProp(owner, prop, true, {
            v: undefined,
            init: function(v) {
                this.v = v;
                return true;
            },
            getter: function() {
                return this.v;
            },
            setter: function(a) {
                this.v = a;
                if ( a instanceof Object ) {
                    trapChain(a, chain);
                }
            }
        });
    };
    trapChain(window, chain);
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
