/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-windowopen-if.entity
/// alias no-windowOpen-if.entity
/// alias nowoif.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noWindowOpenIfEntity() {

/******************************************************************************/

// default

const argsList = [{"a":[]},{"a":["/^/","2"]},{"a":["/^/","1"]},{"a":["|"]},{"a":["given"]},{"a":["!atomtt"]},{"a":["!/download\\/|link/"]},{"a":["!api?call=","10","obj"],"n":["vidstream.pro"]},{"a":["!gdrivedownload"]},{"a":["!/prcf.fiyar|themes|pixsense|.jpg/"]},{"a":["!newdmn","1"]}];

const entitiesMap = new Map([["1337x",0],["x1337x",0],["wcostream",0],["xhamster13",0],["slreamplay",0],["steamplay",0],["steanplay",0],["stemplay",0],["streamp1ay",0],["streanplay",0],["streampiay",0],["fmovies",0],["9anime",0],["youtubedownloader",0],["plylive",0],["plyvdo",0],["putlockerc",0],["putlockertv",0],["vidsrc",0],["mylink",0],["my1ink",0],["myl1nk",0],["myli3k",0],["yts",0],["hqq",0],["adshort",0],["adsrt",0],["tube8",0],["europixhd",0],["topeuropix",0],["watch-series",0],["watchseries",0],["flashx",0],["gogoanime",0],["gogoanimes",0],["gogoanimetv",0],["imgdew",0],["imgmaze",0],["imgoutlet",0],["imgtown",0],["imgview",0],["dewimg",0],["imgrock",0],["imgviu",0],["mazpic",0],["outletpic",0],["picrok",0],["1movies",0],["jkanime",0],["pelisplus",0],["pelisplushd",0],["pouvideo",0],["povvideo",0],["povw1deo",0],["povwideo",0],["powv1deo",0],["powvibeo",0],["powvideo",0],["powvldeo",0],["arenavision",0],["ciberdvd",0],["pornfay",0],["camwhores",0],["camwhorestv",0],["redtube",0],["ettv",0],["ver-pelis",0],["newpelis",0],["pelix",0],["onlinevideoconverter",0],["adfloz",0],["movies123",0],["voirfilms",0],["vidcloud",0],["iframejav",0],["file-upload",0],["savemedia",0],["telerium",0],["9xbuddy",0],["asianclub",0],["vidmoly",0],["mixdrop",0],["mixdrp",0],["123moviesfree",0],["yesmovies",0],["solarmovie",0],["zeefiles",0],["mega4up",0],["bdiptv",0],["cinemalibero",0],["azsoft",0],["gomovies",0],["gomoviesc",0],["cloudvideotv",0],["123movierulz",0],["7movierulz1",0],["7moviesrulz",0],["movieruls",0],["movierulz",0],["movierulzfree",0],["movierulzs",0],["movierulzwatch",0],["movierulzz",0],["moviesrulz",0],["moviesrulzfree",0],["topflix",0],["waaw",0],["waaw1",0],["allfeeds",0],["daddylive",0],["sporting77",0],["teleriumtv",0],["uploadev",0],["thefmovies",0],["sk-ip",0],["keepvid",0],["ustream",0],["upvid",0],["ssrmovies",0],["moviflex",0],["fembed",0],["mavplay",0],["videobb",0],["123mkv",0],["pornhub",0],["megavideo",0],["pandamovie",0],["speedporn",0],["watchpornfree",0],["okanime",0],["linkshub",0],["tmearn",0],["filedown",0],["ffmovies",0],["beinmatch",0],["mrpiracy",0],["shorten",0],["ytmp3",0],["gnula",0],["streamz",0],["streamzz",0],["sobatkeren",0],["movieon21",0],["pelispedia24",0],["pelis28",0],["remaxhd",0],["nemenlake",0],["animeblix",0],["gosemut",0],["dropgalaxy",0],["zone-annuaire",0],["uploadhub",0],["mm9844",0],["adblockeronstape",0],["adblockstreamtape",0],["adblockstrtape",0],["adblockstrtech",0],["shavetape",0],["stapadblockuser",0],["stape",0],["strcloud",0],["streamadblockplus",0],["streamta",0],["streamtape",0],["streamtapeadblock",0],["streamtapeadblockuser",0],["strtape",0],["strtapeadblock",0],["strtapeadblocker",0],["strtapewithadblock",0],["strtpe",0],["vidop",0],["seriemega",0],["isohunt",0],["megaflix",0],["drtuber",0],["ilgeniodellostreaming",0],["vid4up",0],["gototub",0],["sportbar",0],["youtubetomp3",0],["9xmovies",0],["shortzzy",0],["rojadirecta",0],["movidy",0],["downloadhub",0],["hubstream",0],["proxybit",0],["openloadmov",0],["wawacity",0],["hubdrive",0],["dl-protect",0],["0gomovies",0],["player.msmini",0],["vapley",0],["moviehdf",0],["hd21",0],["iceporn",0],["nuvid",0],["tubeon",0],["vivatube",0],["winporn",0],["yeptube",0],["streamsport",0],["ytc",0],["shahid4u",0],["javembed",0],["sexy-games",0],["todaypk",0],["todaypktv",0],["1todaypk",0],["usagoals",0],["uproxy",0],["oyohd",0],["720pstream",0],["inextmovies",0],["mp4moviez",0],["buffstreams",0],["4movierulz1",0],["filmygod6",0],["watchmovierulz",0],["streamsb",0],["ofilmywap",0],["kannadamasti",0],["buyjiocoin",0],["filmygod13",0],["ucanwatch",0],["userload",0],["videovard",0],["milfnut",0],["moviemad",0],["mymp3song",0],["akoam",0],["9xmovie",0],["4stream",0],["teluguonlinemovies",0],["cricfree",0],["cricplay2",0],["primetubsub",0],["eztv",0],["theproxy",0],["onlinewatchmoviespk",0],["younetu",0],["hdmoviesmaza",0],["voe-unblock",0],["voe",0],["extratorrent",0],["torrentstatus",0],["yts2",0],["y2mate",0],["poscitech",0],["filemoon",0],["adblockeronstreamtape",0],["crichd",0],["movies2watch",0],["tirexo",0],["weloma",0],["filepress",0],["zone-telechargement",0],["welovemanga",0],["pobre",0],["8xmovies",0],["adblocktape",0],["hydracdn",1],["vev",2],["vidup",2],["wstream",2],["strikeout",3],["viprow",3],["vipboxtv",3],["desbloqueador",4],["atomohd",5],["atomixhq",6],["pctfenix",6],["pctnew",6],["egybest",7],["vidstream",7],["gdriveplayer",8],["imgkia",9],["newdmn",10]]);

/******************************************************************************/

const scriptlet = (
    needle = '',
    delay = '',
    options = ''
) => {
    const newSyntax = /^[01]?$/.test(needle) === false;
    let pattern = '';
    let targetResult = true;
    let autoRemoveAfter = -1;
    if ( newSyntax ) {
        pattern = needle;
        if ( pattern.startsWith('!') ) {
            targetResult = false;
            pattern = pattern.slice(1);
        }
        autoRemoveAfter = parseInt(delay);
        if ( isNaN(autoRemoveAfter) ) {
            autoRemoveAfter = -1;
        } 
    } else {
        pattern = delay;
        if ( needle === '0' ) {
            targetResult = false;
        }
    }
    if ( pattern === '' ) {
        pattern = '.?';
    } else if ( /^\/.+\/$/.test(pattern) ) {
        pattern = pattern.slice(1,-1);
    } else {
        pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    const rePattern = new RegExp(pattern);
    const createDecoy = function(tag, urlProp, url) {
        const decoy = document.createElement(tag);
        decoy[urlProp] = url;
        decoy.style.setProperty('height','1px', 'important');
        decoy.style.setProperty('position','fixed', 'important');
        decoy.style.setProperty('top','-1px', 'important');
        decoy.style.setProperty('width','1px', 'important');
        document.body.appendChild(decoy);
        setTimeout(( ) => decoy.remove(), autoRemoveAfter * 1000);
        return decoy;
    };
    window.open = new Proxy(window.open, {
        apply: function(target, thisArg, args) {
            const url = args[0];
            if ( rePattern.test(url) !== targetResult ) {
                return target.apply(thisArg, args);
            }
            if ( autoRemoveAfter < 0 ) { return null; }
            const decoy = /\bobj\b/.test(options)
                ? createDecoy('object', 'data', url)
                : createDecoy('iframe', 'src', url);
            let popup = decoy.contentWindow;
            if ( typeof popup === 'object' && popup !== null ) {
                Object.defineProperty(popup, 'closed', { value: false });
            } else {
                const noopFunc = (function(){}).bind(self);
                popup = new Proxy(self, {
                    get: function(target, prop) {
                        if ( prop === 'closed' ) { return false; }
                        const r = Reflect.get(...arguments);
                        if ( typeof r === 'function' ) { return noopFunc; }
                        return target[prop];
                    },
                    set: function() {
                        return Reflect.set(...arguments);
                    },
                });
            }
            return popup;
        }
    });
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
