/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-current-script.entity
/// alias acs.entity
/// alias abort-current-inline-script.entity
/// alias acis.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortCurrentScriptEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["atob"]},{"a":["setTimeout","admc"]},{"a":["decodeURI","decodeURIComponent"]},{"a":["document.createElement","admiral"]},{"a":["document.createElement","jsc.mgid.com"]},{"a":["document.querySelector","popupBlocked"]},{"a":["Math","/\\}\\s*\\(.*?\\b(self|this|window)\\b.*?\\)/"]},{"a":["eval","replace"]},{"a":["$","undefined"]},{"a":["document.querySelectorAll","popMagic"]},{"a":["Array.prototype.indexOf","popunder"]},{"a":["adcashMacros"]},{"a":["Promise"]},{"a":["setTimeout","String.fromCharCode"]},{"a":["window.open","Cookie"]},{"a":["Math","XMLHttpRequest"]},{"a":["Date","'shift'"]},{"a":["String.fromCharCode","decodeURIComponent"]},{"a":["$","adbWarn"]},{"a":["document.getElementById","adblockinfo"]},{"a":["JSON","break;case"]},{"a":["decodeURIComponent","'shift'"]},{"a":["String.fromCharCode","'shift'"]},{"a":["vast_urls"]},{"a":["$","test-block"]},{"a":["$","adi"]},{"a":["setTimeout","hommy.mutation.mutation"]},{"a":["adver"]},{"a":["ExoLoader"]},{"a":["puShown","/doOpen|popundr/"]},{"a":["document.createElement","'script'"]},{"a":["atob","decodeURIComponent"]},{"a":["document.createElement","/l\\.parentNode\\.insertBefore\\(s/"]},{"a":["atob","tabunder"]},{"a":["document.getElementById","undefined"]},{"a":["addEventListener","-0x"]},{"a":["stop","adblock"]},{"a":["document.documentElement","break;case $."]},{"a":["addEventListener","google_ad_client"]},{"a":["jQuery","'pp12'"]},{"a":["decodeURI","atob"]},{"a":["jQuery","btoa"]},{"a":["document.getElementsByTagName","onclick"]},{"a":["getCookie"]},{"a":["$","show"]},{"a":["Object.defineProperty","XMLHttpRequest"]},{"a":["onload","btoa"]},{"a":["decodeURI","getScriptFromCss"]},{"a":["$","onclick"]},{"a":["onload"]},{"a":["setTimeout","aadblock"]},{"a":["navigator","FingerprintJS"]},{"a":["Object.defineProperty","trafficjunky"]},{"a":["decodeURIComponent","replace"]},{"a":["parseInt","open"]},{"a":["blur"]},{"a":["$","open"]},{"a":["Object.defineProperty","document.body.appendChild"]},{"a":["Object.assign","popunder"]},{"a":["document.getElementById","ad_block"]},{"a":["onload","onclick"]},{"a":["document.getElementById","adpbtest"]},{"a":["Math","_0x"]},{"a":["document.createElement","Tool"]},{"a":["String.fromCharCode","atob"]},{"a":["$","String.fromCharCode"]},{"a":["JSON.parse","atob"]},{"a":["document.getElementById","style.display"]},{"a":["adBlockDetected"]},{"a":["RegExp","0x"]},{"a":["Math.random","banner"]},{"a":["document.oncontextmenu"]},{"a":["I833"]},{"a":["document.write","advnetwork"]},{"a":["jQuery","popunder"]},{"a":["document.createElement","script"]},{"a":["document.getElementById","xx4215"]},{"a":["document.createElement","console"]},{"a":["document.write","iframe"]},{"a":["$","getElementById"]},{"a":["globalThis","break;case"]},{"a":["String.fromCharCode","break;"]},{"a":["document.getElementById","deleted"]},{"a":["$","ads"]},{"a":["doOnce"]},{"a":["$","prompt"]},{"a":["$","friendlyduck"]},{"a":["Math","decodeURIComponent"]},{"a":["RegExp","_0x"]},{"a":["allclick_Public"]},{"a":["Math.imul"]},{"a":["document.addEventListener","adsbygoogle"]},{"a":["addEventListener","blocker"]},{"a":["document.addEventListener","google_ad_client"]},{"a":["String.fromCharCode","/'shift'|break;/"]},{"a":["String.fromCharCode",".join('')"]},{"a":["Math","zfgloaded"]},{"a":["JSON.parse","break;case $."]},{"a":["parseInt","break;case $."]},{"a":["Math","break;case $."]},{"a":["String.fromCharCode","/btoa|break/"]},{"a":["JSON.parse","Promise"]},{"a":["navigator","break;case $."]},{"a":["Promise","JSON.parse"]},{"a":["Promise","break;case $."]},{"a":["Object","XMLHttpRequest"]},{"a":["document.getElementById","adsBlocked"]},{"a":["decodeURIComponent","atob"]},{"a":["Math.floor","ExoLoader"]},{"a":["document.createElement","cookie"]},{"a":["document.createElement","\"script\""]},{"a":["$","/\\.fadeIn|\\.show\\(.?\\)/"]},{"a":["navigator","popunder"]}];

const entitiesMap = new Map([["stream2watch",[0,99]],["x1337x",1],["torlock",1],["torlock2",1],["atomohd",[1,98]],["topstreams",[1,83]],["pogolinks",1],["1stream",[1,110]],["daddylivehd",[1,37]],["tutelehd",1],["watchtvchh",1],["liveon",1],["vipleague",[1,20,97,98,99]],["strikeout",[1,22,98]],["viprow",1],["crackstreams",[1,37,51]],["buffstreams",[1,51]],["yts-subs",1],["poscitech",[1,98]],["f1livegp",1],["sportsembed",1],["sportsonline",1],["13377x",2],["biqle",2],["sxyprn",[2,9,23]],["grantorrent",[2,46]],["grantorrent1",2],["inkapelis",[2,50]],["loveroms",2],["ver-pelis",2],["torrentz2eu",[2,56]],["dfiles",2],["multiup",2],["dood",[2,11,30,37]],["thothub",2],["magesy",3],["watchcartoononline",[4,37]],["watchcartoonsonline",4],["wcostream",4],["transfermarkt",[5,6]],["world4ufree",[7,98]],["latesthdmovies",[7,30]],["mma-core",8],["123link",[8,24,25]],["palimas",9],["pornktube",9],["perfectgirls",[9,28]],["pixhost",9],["mywatchseries",[9,98]],["doujindesu",9],["pornhat",9],["pasend",9],["megadede",9],["pornhd8k",9],["toonanime",9],["cine-calidad",9],["asiaon",9],["watchseries1",[9,37]],["huyamba",9],["javhd",9],["nudevista",9],["pinkporno",9],["porn720",9],["sexy-games",9],["videos-xxx",9],["gotxx",9],["ahri8",9],["hentaisenpai",9],["hentai-senpai",9],["klmanga",9],["micmicidol",9],["nhentai",9],["onepunch",9],["pianmanga",9],["seriesyonkis",9],["solomax-levelnewbie",9],["solomaxlevelnewbie",9],["sousou-no-frieren",9],["spy-x-family",9],["thebeginningaftertheend",9],["hamsterix",10],["xhamster",10],["xhamster1",10],["xhamster10",10],["xhamster11",10],["xhamster12",10],["xhamster13",10],["xhamster14",10],["xhamster15",10],["xhamster16",10],["xhamster17",10],["xhamster18",10],["xhamster19",10],["xhamster2",10],["xhamster3",10],["xhamster4",10],["xhamster5",10],["xhamster7",10],["xhamster8",10],["torrentdownload",11],["torrentdownloads",11],["kinos",11],["kinox",11],["proxybit",11],["123unblock",[11,31]],["animeyt",12],["9anime",[13,14,99]],["watch-series",15],["watchseries",[15,97,98]],["flashx",[15,17,22,96]],["limetorrents",[15,58]],["vidcloud",[15,31]],["moviflex",15],["egybest",15],["movie123",15],["bmovies",[15,97]],["bolly4umovies",15],["putlocker",[15,37,96,98]],["serienstream",16],["pirateproxy",[17,57]],["kimcartoon",18],["mexa",19],["adblockeronstreamtape",20],["cloudvideotv",20],["mylink",[21,97]],["my1ink",[21,97]],["myl1nk",[21,97]],["myli3k",[21,97]],["animepahe",[22,97]],["kwik",[22,96]],["seehd",22],["tamilyogi",22],["hpaudiobooks",22],["txxx",26],["voyeurhit",27],["upornia",27],["thegay",27],["hdzog",27],["perfektdamen",28],["absoluporn",28],["khatrimaza",29],["anitube",[30,98]],["mangovideo",30],["gdtot",[30,37]],["gogoanime",[31,32]],["adsrt",31],["myvidmate",31],["voirfilms",31],["tamilmv",31],["streamingworld",[31,99]],["2umovies",31],["hdfull",32],["weloma",32],["moviesjoy",[32,98]],["moviegan",32],["nekopoi",33],["file-upload",34],["dewimg",35],["imgtown",35],["imgviu",35],["mazpic",35],["outletpic",35],["picrok",35],["hideout",36],["123movies",37],["123moviesfree",[37,98]],["123movieweb",37],["123movies-org",37],["1todaypk",37],["4movierulz",37],["5movies",37],["9kmovies",[37,98]],["a8ix",37],["animixplay",37],["asianhdplay",37],["atishmkv",37],["direct-cloud",37],["dvdplay",37],["faselhd",37],["gdflix",37],["gogohd",37],["iflixmovies",37],["kickassanime",37],["mkvcinemas",37],["moviesmeta",37],["mydownloadtube",37],["series2watch",37],["shahed4u",[37,98]],["shaheed4u",37],["streamonsport",37],["streamz",[37,98]],["strtapewithadblock",37],["uproxy",37],["vidcloud9",[37,99]],["videoplayer",37],["vidsrc",[37,97]],["watchomovies",[37,98]],["yesmovies4u",37],["itdmusic",38],["azsoft",[38,67]],["anoboy",38],["animeflv",[39,98]],["hyperdebrid",40],["divxtotal",41],["divxtotal1",41],["pelisplus2",42],["desiupload",43],["douploads",44],["vipracing",44],["okhatrimaza",45],["ddlvalley",47],["mangaku",48],["camwhores",49],["camwhorestv",49],["cambabe",49],["uploader",49],["uploadbaz",[49,90]],["soap2day",[51,97]],["miraculous",51],["vipboxtv",51],["redtube",52],["pornhub",52],["filecrypt",[53,54]],["peliculas24",55],["sound-park",[56,75]],["soundpark",[56,75]],["soundpark-club",[56,75]],["file4go",59],["milfnut",60],["situsberita2terbaru",61],["uploadrar",[62,98]],["gamecopyworld",63],["dailysport",64],["mixdrop",65],["mixdrp",65],["l23movies",66],["123moviess",66],["123movieshub",[66,98]],["estrenosflux",66],["userload",67],["moretvtime",68],["couchtuner",69],["easy-coin",70],["semi168",71],["pctfenix",[72,99]],["pctnew",[72,99]],["pelisplay",73],["nextorrent",74],["sk-ip",76],["desiremovies",77],["sexvid",78],["okanime",[79,98]],["asianclub",80],["mavplay",80],["ouo",[80,94]],["videobb",80],["ffmovies",81],["mrpiracy",82],["allcalidad",[84,96]],["evileaks",85],["extreme-down",[86,87,97]],["mkvcinema",88],["pelispedia",89],["katmoviehd",90],["hubdrive",90],["cinemakottaga",91],["akwam",[92,99]],["descargasok",93],["7starhd",94],["pcprogramasymas",95],["33sk",96],["3sk",96],["animesvision",96],["bmovie",96],["cinedetodo",96],["cinetux",96],["descargas2020",96],["fmovie",96],["hindilinks4u",96],["ironysub",96],["janjua",96],["kstreaming",96],["libertyvf",96],["popcornstream",96],["shorten",96],["solarmovie",96],["streamango",96],["turkanime",96],["uploadev",96],["xmovies08",96],["0123movie",97],["1111fullwise",97],["111watcho",97],["123-movies",97],["123moviesc",97],["123moviesla",97],["1kmovies",97],["2gomovies",97],["4filmyzilla",97],["69hoshudaana",97],["adshort",97],["akmcloud",97],["allmovieshub",97],["altadefinizione01",[97,98]],["animetak",97],["arenavision",97],["batmanstream",97],["bollymovies",97],["bollywoodfilma",97],["buffstream",97],["clampschoolholic",97],["crichd",97],["crictime",97],["dflinks",97],["downloadhub",97],["downloadming",97],["dramacool",97],["easylinks",97],["europix",97],["f1stream",[97,98,99]],["fbstream",[97,98,99]],["fffmovies",97],["filmisongs",97],["foumovies",97],["fsapi",97],["fullcinema",97],["fullreal",97],["fulltube",97],["gnula",97],["gogoplay",97],["gomovies",97],["hdmoviehubs",97],["hdpopcorns",97],["hdss-to",97],["jalshamoviezhd",97],["jkanime",97],["keepvid",97],["kiss-anime",97],["kissanime",[97,100]],["kissmanga",97],["libertestreamvf",[97,98]],["linkshere",97],["linkshub",97],["linksmore",97],["lodynet",97],["lookmovie",97],["lookmovie186",97],["losmovies",97],["megafilmeshd20",97],["mlbstream",[97,98,99]],["mlwbd",97],["mobilemovies",97],["motogpstream",[97,98,99]],["movierulzhd",[97,106]],["moviesbaba",97],["moviescounter",97],["mp4moviez",97],["myegy",97],["naasongs",97],["naasongsfree",97],["nbastream",[97,98,99]],["nflstream",[97,98,99]],["nhlstream",[97,98,99]],["nsw2u",97],["oceanofmovies",97],["onlinevideoconverter",97],["oploverz",97],["pagalworld",97],["playtamil",97],["plylive",[97,98]],["primewire",97],["project-free-tv",97],["projectfreetv",97],["putlocker9",97],["putlockers",[97,98]],["querofilmehd",97],["rugbystreams",[97,98,99]],["sdmoviespoint",97],["shortlinkto",97],["socceronline",[97,98,99]],["sportstreamtv",97],["ssoap2day",97],["tamilyogis",97],["tenies-online",97],["tennisstreams",[97,98,99]],["thelinkbox",97],["thesuperdownload",97],["tvply",[97,98]],["ufcstream",[97,98,99]],["uploadhub",97],["usagoals",97],["vedbom",97],["vidembed",97],["vkmp3",97],["watchmovieshd",97],["watchserieshd",97],["wawacity",97],["wildwap",97],["wmoviesfree",97],["xmovies8",97],["yesmovies",97],["ytsaver",97],["123movies4up",98],["123moviesme",98],["4hiidude",98],["4stream",98],["5xmovies",98],["720pstream",98],["7hitmovies",98],["9tsu",98],["9xmovie",98],["9xmovies",98],["9xupload",98],["anime4up",98],["animefreak",98],["animesanka",98],["animesup",98],["asianplay",98],["bdmusic23",98],["bflix",98],["cricstream",98],["daddylive",98],["dloader",98],["eplayvid",98],["fastilinks",98],["filma1",98],["filma24",98],["filmy",98],["filmyhit",98],["filmywap",[98,105]],["flixtor",98],["fmovies",98],["g3g",98],["gdplayer",98],["gofilmes",98],["gomoviz",98],["govid",98],["gowatchseries",98],["hds-streaming",98],["hhdmovies",98],["hindimovies",98],["hotmasti",98],["ilgeniodellostreaming",98],["isaidub",98],["isaidubhd",98],["jetanimes",98],["jiorockers",98],["joolinks",98],["katlinks",98],["linksfire",98],["linksme",98],["madrasdub",98],["manhuascan",98],["melodelaa",98],["mkvcage",98],["mkvpapa",98],["moviefreak",98],["movies123",[98,99]],["movies2k",98],["moviesda1",98],["moviesdaweb",98],["moviesland",98],["moviespapa",98],["moviesverse",98],["multicanais",98],["mycima",98],["myflixer",98],["ogario",98],["pahe",98],["plyvdo",98],["series9",98],["shadowrangers",98],["shrink",98],["southfreak",98],["ssrmovies",98],["stardima",98],["streamingcommunity",98],["streamsport",98],["streamzz",98],["t7meel",98],["tamilarasan",98],["tamilfreemp3songs",98],["tamilprint",98],["tamilprinthd",98],["topflix",98],["tubidy",98],["uptobhai",98],["upvid",98],["uwatchfree",98],["vanime",[98,101]],["vido",98],["watch4hd",98],["watchmovie",98],["world4ufree1",98],["yoyofilmeys",98],["yts",98],["01234movies",99],["1234movies",99],["123gostream",99],["123moviesgo",99],["1stkissmanga",99],["1tamilmv",[99,109]],["adcorto",99],["asianload",99],["bdiptv",99],["bollyshare",99],["cinen9",99],["cuevana3",99],["dogecoin",99],["dramanice",99],["earnload",99],["extramovies",99],["filmesonlinex",99],["filmy4wap1",99],["freeload",99],["fzmovies",99],["gdirect",99],["gogoanimes",99],["hdfilme",99],["hdmoviz",99],["hindimoviesonline",99],["inextmovies",99],["linkskat",99],["mega4up",99],["mkvhub",99],["mlsbd",99],["movies4me",99],["moviesmon",99],["moviesshub",99],["movizland",99],["nowmovies",99],["openload",99],["plusupload",99],["prmovies",99],["racaty",99],["rojadirecta",99],["rojadirectatv",99],["s2dfree",99],["seriesflv",99],["seriesly",99],["seuseriado",99],["shavetape",99],["strtapeadblock",[99,101]],["upfiles",99],["xmovies",99],["ymovies",99],["youwatch",99],["zone-annuaire",99],["0123movies",100],["bdupload",100],["dl-protect",100],["dl-protect1",100],["firstonetv",100],["hdmovieplus",100],["hdss",100],["hydracdn",100],["linkshorts",100],["mangamanga",100],["movieshub",100],["movs4u",100],["shortearn",100],["sports24",100],["ustream",100],["vexmovies",100],["vidlox",100],["yifysubtitles",100],["adblockstreamtape",101],["adblockstrtape",101],["adblockstrtech",101],["komikcast",101],["mavanimes",101],["stape",101],["strcloud",101],["streamadblockplus",101],["streamta",101],["streamtape",101],["streamtapeadblock",101],["strtape",101],["strtpe",101],["123moviesonline",102],["2embed",102],["adblockeronstape",102],["brbushare",102],["filmeseries",102],["hdmovies50",102],["skymovieshd",102],["stapewithadblock",102],["uplinkto",102],["vedbam",102],["egydead",103],["m4ufree",103],["arabseed",104],["seeeed",104],["mrunblock",107],["fapnado",108],["voe-unblock",111],["filemoon",112]]);

/******************************************************************************/

// Issues to mind before changing anything:
//  https://github.com/uBlockOrigin/uBlock-issues/issues/2154

const scriptlet = (
    target = '',
    needle = '',
    context = ''
) => {
    if ( target === '' ) { return; }
    const reRegexEscape = /[.*+?^${}()|[\]\\]/g;
    const reNeedle = (( ) => {
        if ( needle === '' ) { return /^/; }
        if ( /^\/.+\/$/.test(needle) ) {
            return new RegExp(needle.slice(1,-1));
        }
        return new RegExp(needle.replace(reRegexEscape, '\\$&'));
    })();
    const reContext = (( ) => {
        if ( context === '' ) { return; }
        if ( /^\/.+\/$/.test(context) ) {
            return new RegExp(context.slice(1,-1));
        }
        return new RegExp(context.replace(reRegexEscape, '\\$&'));
    })();
    const chain = target.split('.');
    let owner = window;
    let prop;
    for (;;) {
        prop = chain.shift();
        if ( chain.length === 0 ) { break; }
        owner = owner[prop];
        if ( owner instanceof Object === false ) { return; }
    }
    let value;
    let desc = Object.getOwnPropertyDescriptor(owner, prop);
    if (
        desc instanceof Object === false ||
        desc.get instanceof Function === false
    ) {
        value = owner[prop];
        desc = undefined;
    }
    const magic = String.fromCharCode(Date.now() % 26 + 97) +
                  Math.floor(Math.random() * 982451653 + 982451653).toString(36);
    const scriptTexts = new WeakMap();
    const getScriptText = elem => {
        let text = elem.textContent;
        if ( text.trim() !== '' ) { return text; }
        if ( scriptTexts.has(elem) ) { return scriptTexts.get(elem); }
        const [ , mime, content ] =
            /^data:([^,]*),(.+)$/.exec(elem.src.trim()) ||
            [ '', '', '' ];
        try {
            switch ( true ) {
            case mime.endsWith(';base64'):
                text = self.atob(content);
                break;
            default:
                text = self.decodeURIComponent(content);
                break;
            }
        } catch(ex) {
        }
        scriptTexts.set(elem, text);
        return text;
    };
    const validate = ( ) => {
        const e = document.currentScript;
        if ( e instanceof HTMLScriptElement === false ) { return; }
        if ( reContext !== undefined && reContext.test(e.src) === false ) {
            return;
        }
        if ( reNeedle.test(getScriptText(e)) === false ) { return; }
        throw new ReferenceError(magic);
    };
    Object.defineProperty(owner, prop, {
        get: function() {
            validate();
            return desc instanceof Object
                ? desc.get.call(owner)
                : value;
        },
        set: function(a) {
            validate();
            if ( desc instanceof Object ) {
                desc.set.call(owner, a);
            } else {
                value = a;
            }
        }
    });
    const oe = window.onerror;
    window.onerror = function(msg) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe.apply(this, arguments);
        }
    }.bind();
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
