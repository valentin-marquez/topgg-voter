/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-addeventlistener-if.entity
/// alias noaelif.entity
/// alias aeld.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noAddEventListenerIfEntity() {

/******************************************************************************/

// default

const argsList = [{"a":["mousedown","clientX"]},{"a":["/^(?:click|mousedown)$/","_0x"]},{"a":["load","onload"]},{"a":["","pop"]},{"a":["","BACK"]},{"a":["","0x"]},{"a":["load","getComputedStyle"]},{"a":["load","adsense"]},{"a":["","_0x"]},{"a":["load","nextFunction"]},{"a":["/^(?:click|mousedown)$/","bypassEventsInProxies"]},{"a":["click","pop.beforeOpen"]},{"a":["click","exopop"]},{"a":["","popMagic"]},{"a":["","_blank"]},{"a":["click","popMagic"]},{"a":["mousedown","preventDefault"]},{"a":["load","advertising"]},{"a":["click","preventDefault"]},{"a":["load","2000"]},{"a":["/^(?:click|mousedown|mousemove|touchstart|touchend|touchmove)$/","system.popunder"]},{"a":["DOMContentLoaded","shortener"]},{"a":["mousedown","trigger"]},{"a":["","Pop"]},{"a":["","adsense"]},{"a":["load","url"]},{"a":["","Date"]},{"a":["click","_0x"]},{"a":["click"]},{"a":["click","open"]},{"a":["load","download-wrapper"]},{"a":["popstate","noPop"]},{"a":["click","popunder"]},{"a":["/^(?:mousedown|mouseup)$/","0x"]},{"a":["keydown","keyCode"]},{"a":["mousedown","!!{});"]},{"a":["keydown"]},{"a":["/^/","0x"]},{"a":["/^(?:click|mousedown|mouseup)$/","di()"]},{"a":["popstate"]},{"a":["devtoolschange"]},{"a":["timeupdate"]},{"a":["DOMContentLoaded","btoa"]},{"a":["click","saveLastEvent"]},{"a":["","show"]},{"a":["DOMContentLoaded","adsBlocked"]},{"a":["","btoa"]},{"a":["click","0x"]},{"a":["","break;case $."]},{"a":["","/pop|_blank/"]},{"a":["click","allclick_Public"]},{"a":["contextmenu"]},{"a":["mouseup","catch"]},{"a":["","[native code]"]},{"a":["","adsbygoogle"]}];

const entitiesMap = new Map([["kisscartoon",0],["kissasian",1],["ganool",1],["pirate",1],["piratebay",1],["pirateproxy",1],["proxytpb",1],["thepiratebay",1],["limetorrents",[2,8]],["king-pes",2],["depedlps",2],["komikcast",2],["idedroidsafelink",2],["links-url",2],["eikaiwamastery",2],["kastream",2],["xhamster",3],["xhamster1",3],["xhamster5",3],["xhamster7",3],["movies07",3],["pornocomics",3],["streanplay",4],["steanplay",4],["serienstream",5],["newpelis",[5,25]],["pelix",[5,25]],["allcalidad",[5,15]],["khatrimaza",5],["serien",5],["liferayiseasy",[6,7]],["yts",8],["tube8",8],["topeuropix",8],["moviescounter",8],["torrent9",8],["desiremovies",8],["movs4u",8],["uwatchfree",8],["hydrax",8],["4movierulz",8],["projectfreetv",8],["arabseed",8],["semi168",8],["pahe",8],["btdb",[8,26]],["skymovieshd",8],["pagalmovies",8],["7starhd",[8,34]],["1jalshamoviez",8],["9xupload",8],["bdupload",8],["desiupload",8],["rdxhd1",8],["world4ufree",8],["streamsport",8],["rojadirectatvhd",8],["userload",8],["lordpremium",9],["todovieneok",9],["firmware277",9],["novablogitalia",9],["anisubindo",9],["adyou",10],["txxx",11],["fxporn69",12],["watchseries",13],["pornktube",13],["sexwebvideo",14],["pornomoll",14],["mejortorrent",15],["mejortorrento",15],["mejortorrents",15],["mejortorrents1",15],["mejortorrentt",15],["grantorrent",15],["gntai",15],["dulinks",15],["gsurl",16],["mimaletadepeliculas",17],["burningseries",18],["dz4soft",19],["yoututosjeff",19],["ebookmed",19],["lanjutkeun",19],["novelasesp",19],["singingdalong",19],["doujindesu",19],["xmovies8",20],["mega-dvdrip",21],["peliculas-dvdrip",21],["desbloqueador",22],["camwhores",23],["camwhorestv",23],["uproxy",23],["nekopoi",24],["mirrorace",27],["dbupload",28],["nuvid",29],["mixdrp",30],["asiansex",31],["japanfuck",31],["japanporn",31],["teensex",31],["vintagetube",31],["xxxmovies",31],["megalink",32],["zooqle",33],["hdfull",35],["mangamanga",36],["streameast",37],["thestreameast",37],["vev",38],["vidop",38],["zone-telechargement",39],["moviessources",40],["gmx",41],["mega1080p",42],["9hentai",43],["sms24",44],["gaypornhdfree",45],["cinemakottaga",45],["privatemoviez",45],["apkmaven",45],["popcornstream",46],["goload",[47,48]],["0gomovie",48],["0gomovies",48],["123moviefree",48],["1kmovies",48],["1madrasdub",48],["1primewire",48],["2embed",48],["2madrasdub",48],["2umovies",48],["4anime",48],["9xmovies",48],["altadefinizione01",48],["anitube",48],["atomixhq",48],["beinmatch",48],["brmovies",48],["cima4u",48],["clicknupload",48],["cmovies",48],["couchtuner",48],["cricfree",48],["crichd",48],["databasegdriveplayer",48],["dood",48],["f1stream",48],["faselhd",48],["fbstream",48],["file4go",48],["filemoon",48],["filepress",48],["filmlinks4u",48],["filmpertutti",48],["filmyzilla",48],["fmovies",48],["french-stream",48],["fsapi",48],["fzlink",48],["gdriveplayer",48],["gofilms4u",48],["gogoanime",48],["gomoviefree",48],["gomoviz",48],["gowatchseries",48],["hdmoviefair",48],["hdmovies4u",48],["hdmovies50",48],["hdmoviesfair",48],["hh3dhay",48],["hindilinks4u",48],["hotmasti",48],["hurawatch",48],["klmanga",48],["klubsports",48],["libertestreamvf",48],["livetvon",48],["manga1000",48],["manga1001",48],["mangaraw",48],["mangarawjp",48],["mlbstream",48],["motogpstream",48],["movierulz",48],["movies2watch",48],["moviesden",48],["moviezaddiction",48],["myflixer",48],["nbastream",48],["netcine",48],["nflstream",48],["nhlstream",48],["onlinewatchmoviespk",48],["pctfenix",48],["pctnew",48],["pksmovies",48],["plyjam",48],["plylive",48],["pogolinks",48],["poscitech",48],["prmovies",48],["rugbystreams",48],["shahed4u",48],["sflix",48],["sitesunblocked",48],["socceronline",48],["solarmovies",48],["sportcast",48],["sports-stream",48],["streaming-french",48],["streamers",48],["streamingcommunity",48],["strikeout",48],["t20cup",48],["tennisstreams",48],["toonanime",48],["tvply",48],["ufcstream",48],["uptomega",48],["uqload",48],["vudeo",48],["vidoo",48],["vipbox",48],["vipboxtv",48],["vipleague",48],["viprow",48],["yesmovies",48],["yomovies",48],["yomovies1",48],["yt2mp3s",48],["sportskart",48],["guardaserie",49],["cine-calidad",50],["milfnut",51],["videovard",52],["softonic",53],["magesy",54]]);

/******************************************************************************/

const regexpFromArg = arg => {
    if ( arg === '' ) { return /^/; }
    if ( /^\/.+\/$/.test(arg) ) { return new RegExp(arg.slice(1,-1)); }
    return new RegExp(arg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
};

/******************************************************************************/

const scriptlet = (
    needle1 = '',
    needle2 = ''
) => {
    const reNeedle1 = regexpFromArg(needle1);
    const reNeedle2 = regexpFromArg(needle2);
    self.EventTarget.prototype.addEventListener = new Proxy(
        self.EventTarget.prototype.addEventListener,
        {
            apply: function(target, thisArg, args) {
                let type, handler;
                try {
                    type = String(args[0]);
                    handler = String(args[1]);
                } catch(ex) {
                }
                if (
                    reNeedle1.test(type) === false ||
                    reNeedle2.test(handler) === false
                ) {
                    return target.apply(thisArg, args);
                }
            }
        }
    );
};

/******************************************************************************/

const hnparts = [];
try { hnparts.push(...document.location.hostname.split('.')); } catch(ex) { }
const hnpartslen = hnparts.length - 1;
for ( let i = 0; i < hnpartslen; i++ ) {
    for ( let j = hnpartslen; j > i; j-- ) {
        const hn = hnparts.slice(i).join('.');
        const en = hnparts.slice(i,j).join('.');
        let argsIndices = entitiesMap.get(en);
        if ( argsIndices === undefined ) { continue; }
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
}

argsList.length = 0;
entitiesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
