/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-declarative

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssDeclarativeImport() {

/******************************************************************************/

// cze-0

const argsList = [{"a":["{\"selector\":\"body\",\"action\":[\"style\",\"background-image: none !important; padding-top: 0 !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\"div.body\",\"action\":[\"style\",\"padding-top: 0 !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\".top_bg_content\",\"action\":[\"style\",\"top: 0px !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\"body\",\"action\":[\"style\",\"background:none !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\"div.jeg_topbar\",\"action\":[\"style\",\"margin-bottom: 0px !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\"#frs\",\"action\":[\"style\",\"margin-top: 100px !important;\"],\"cssable\":true}"]},{"a":["{\"selector\":\"div.l-wrapper\",\"action\":[\"style\",\"padding-top: 0px !important;\"],\"cssable\":true}"]}];

const hostnamesMap = new Map([["cdr.cz",0],["diit.cz",0],["csfd.cz",1],["csfd.sk",1],["kupi.cz",2],["uschovna.cz",3],["zing.cz",4],["kinema.sk",5],["sector.sk",5],["uloz.to",6]]);

self.declarativeImports = self.declarativeImports || [];
self.declarativeImports.push({ argsList, hostnamesMap });

/******************************************************************************/

})();

/******************************************************************************/
